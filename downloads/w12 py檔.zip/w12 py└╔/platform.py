﻿# NX 2027
# Journal created by Admin on Fri May 17 15:17:07 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    # ----------------------------------------------
    #   Menu: File->Open...
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: File->New...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    fileNew1 = theSession.Parts.FileNew()
    
    theSession.SetUndoMarkName(markId1, "New Dialog")
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    fileNew1.TemplateFileName = "model-plain-1-mm-template.prt"
    
    fileNew1.UseBlankTemplate = False
    
    fileNew1.ApplicationName = "ModelTemplate"
    
    fileNew1.Units = NXOpen.Part.Units.Millimeters
    
    fileNew1.RelationType = ""
    
    fileNew1.UsesMasterModel = "No"
    
    fileNew1.TemplateType = NXOpen.FileNewTemplateType.Item
    
    fileNew1.TemplatePresentationName = "Model"
    
    fileNew1.ItemType = ""
    
    fileNew1.Specialization = ""
    
    fileNew1.SetCanCreateAltrep(False)
    
    fileNew1.NewFileName = "F:\\yan1\\portable_2024\\portable_2024\\platform.prt"
    
    fileNew1.MasterFileName = ""
    
    fileNew1.MakeDisplayedPart = True
    
    fileNew1.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    
    nXObject1 = fileNew1.Commit()
    
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    theSession.DeleteUndoMark(markId3, None)
    
    fileNew1.Destroy()
    
    theSession.ApplicationSwitchImmediate("UG_APP_MODELING")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane1 = workPart.Planes.CreatePlane(origin1, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane1
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder1 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder1.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId6, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder1.UseWorkPartOrigin = False
    
    coordinates1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point1 = workPart.Points.CreatePoint(coordinates1)
    
    origin2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix1 = NXOpen.Matrix3x3()
    
    matrix1.Xx = 1.0
    matrix1.Xy = 0.0
    matrix1.Xz = 0.0
    matrix1.Yx = 0.0
    matrix1.Yy = 1.0
    matrix1.Yz = 0.0
    matrix1.Zx = 0.0
    matrix1.Zy = 0.0
    matrix1.Zz = 1.0
    plane2 = workPart.Planes.CreateFixedTypePlane(origin2, matrix1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2 = workPart.Points.CreatePoint(coordinates2)
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction1 = workPart.Directions.CreateDirection(origin3, vector1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector2 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction2 = workPart.Directions.CreateDirection(origin4, vector2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix2 = NXOpen.Matrix3x3()
    
    matrix2.Xx = 1.0
    matrix2.Xy = 0.0
    matrix2.Xz = 0.0
    matrix2.Yx = 0.0
    matrix2.Yy = 1.0
    matrix2.Yz = 0.0
    matrix2.Zx = 0.0
    matrix2.Zy = 0.0
    matrix2.Zz = 1.0
    plane3 = workPart.Planes.CreateFixedTypePlane(origin5, matrix2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane3, direction2, point2, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder1.CoordinateSystem = cartesianCoordinateSystem1
    
    datumAxis1 = workPart.Datums.FindObject("DATUM_CSYS(0) X axis")
    simpleSketchInPlaceBuilder1.HorizontalReference.Value = datumAxis1
    
    point3 = simpleSketchInPlaceBuilder1.SketchOrigin
    
    simpleSketchInPlaceBuilder1.SketchOrigin = point3
    
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId7, None)
    
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject2 = simpleSketchInPlaceBuilder1.Commit()
    
    sketch1 = nXObject2
    feature1 = sketch1.Feature
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId9)
    
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder1 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject3 = sketchFindMovableObjectsBuilder1.Commit()
    
    sketchFindMovableObjectsBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId8, None)
    
    theSession.SetUndoMarkName(markId6, "Create Sketch")
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    simpleSketchInPlaceBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane1.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId5, None, True)
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_000")
    
    scaleAboutPoint1 = NXOpen.Point3d(-187.52145236703171, 23.182597133286883, 0.0)
    viewCenter1 = NXOpen.Point3d(187.52145236703171, -23.182597133286883, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(-146.72008141244692, 7.8305661427991708, 0.0)
    viewCenter2 = NXOpen.Point3d(146.72008141244663, -7.8305661427991708, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(-117.37606512995752, 2.3079563368250424, 0.0)
    viewCenter3 = NXOpen.Point3d(117.3760651299573, -2.3079563368250424, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(59.083682222720014, 13.452088363208603, 0.0)
    viewCenter4 = NXOpen.Point3d(-59.083682222720192, -13.452088363208603, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(134.52088363208591, 8.2427012029464297, 0.0)
    viewCenter5 = NXOpen.Point3d(-134.5208836320862, -8.2427012029464848, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(189.58212766776802, 11.127646623977702, 0.0)
    viewCenter6 = NXOpen.Point3d(-189.5821276677683, -11.127646623977702, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint6, viewCenter6)
    
    scaleAboutPoint7 = NXOpen.Point3d(353.40581407632862, 41.72867483991638, 0.0)
    viewCenter7 = NXOpen.Point3d(-353.40581407632897, -41.72867483991638, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint7, viewCenter7)
    
    scaleAboutPoint8 = NXOpen.Point3d(440.4693455324504, 52.160843549895361, 0.0)
    viewCenter8 = NXOpen.Point3d(-440.46934553245086, -52.160843549895581, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(352.37547642596036, 41.728674839916295, 0.0)
    viewCenter9 = NXOpen.Point3d(-352.37547642596076, -41.728674839916472, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint9, viewCenter9)
    
    scaleAboutPoint10 = NXOpen.Point3d(282.72465126106289, 33.382939871933033, 0.0)
    viewCenter10 = NXOpen.Point3d(-282.72465126106317, -33.382939871933175, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint10, viewCenter10)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId12, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    endPoint1 = NXOpen.Point3d(165.0, 0.0, 0.0)
    line1 = workPart.Curves.CreateLine(startPoint1, endPoint1)
    
    startPoint2 = NXOpen.Point3d(165.0, 0.0, 0.0)
    endPoint2 = NXOpen.Point3d(165.0, 135.0, 0.0)
    line2 = workPart.Curves.CreateLine(startPoint2, endPoint2)
    
    startPoint3 = NXOpen.Point3d(165.0, 135.0, 0.0)
    endPoint3 = NXOpen.Point3d(0.0, 135.0, 0.0)
    line3 = workPart.Curves.CreateLine(startPoint3, endPoint3)
    
    startPoint4 = NXOpen.Point3d(0.0, 135.0, 0.0)
    endPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    line4 = workPart.Curves.CreateLine(startPoint4, endPoint4)
    
    theSession.ActiveSketch.AddGeometry(line1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_1.Geometry = line1
    conGeom1_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_1.SplineDefiningPointIndex = 0
    conGeom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_1.Geometry = line2
    conGeom2_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint1 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_1, conGeom2_1)
    
    conGeom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_2.Geometry = line2
    conGeom1_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_2.SplineDefiningPointIndex = 0
    conGeom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_2.Geometry = line3
    conGeom2_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint2 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_2, conGeom2_2)
    
    conGeom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_3.Geometry = line3
    conGeom1_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_3.SplineDefiningPointIndex = 0
    conGeom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_3.Geometry = line4
    conGeom2_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint3 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_3, conGeom2_3)
    
    conGeom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_4.Geometry = line4
    conGeom1_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_4.SplineDefiningPointIndex = 0
    conGeom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_4.Geometry = line1
    conGeom2_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint4 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_4, conGeom2_4)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms1 = [NXOpen.SmartObject.Null] * 4 
    geoms1[0] = line1
    geoms1[1] = line2
    geoms1[2] = line3
    geoms1[3] = line4
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms1)
    
    geoms2 = [NXOpen.SmartObject.Null] * 4 
    geoms2[0] = line1
    geoms2[1] = line2
    geoms2[2] = line3
    geoms2[3] = line4
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms2)
    
    objects1 = [NXOpen.NXObject.Null] * 4 
    objects1[0] = sketchGeometricConstraint1
    objects1[1] = sketchGeometricConstraint2
    objects1[2] = sketchGeometricConstraint3
    objects1[3] = sketchGeometricConstraint4
    errorList1 = theSession.ActiveSketch.DeleteObjects(objects1)
    
    errorList1.Dispose()
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.DeleteUndoMark(markId13, "Create Rectangle")
    
    sketchFindMovableObjectsBuilder2 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject4 = sketchFindMovableObjectsBuilder2.Commit()
    
    sketchFindMovableObjectsBuilder2.Destroy()
    
    scaleAboutPoint11 = NXOpen.Point3d(236.73037854862176, 98.582706387239455, 0.0)
    viewCenter11 = NXOpen.Point3d(-236.73037854862204, -98.582706387239568, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint11, viewCenter11)
    
    scaleAboutPoint12 = NXOpen.Point3d(295.91297318577716, 123.22838298404932, 0.0)
    viewCenter12 = NXOpen.Point3d(-295.91297318577745, -123.22838298404946, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(369.89121648222147, 154.03547873006164, 0.0)
    viewCenter13 = NXOpen.Point3d(-369.89121648222181, -154.03547873006181, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(462.36402060277698, 192.54434841257702, 0.0)
    viewCenter14 = NXOpen.Point3d(-462.36402060277709, -192.54434841257702, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(594.05405154047617, 280.92799998323335, 0.0)
    viewCenter15 = NXOpen.Point3d(-594.05405154047617, -280.92799998323335, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint15, viewCenter15)
    
    scaleAboutPoint16 = NXOpen.Point3d(480.39492948422253, 228.60616617546771, 0.0)
    viewCenter16 = NXOpen.Point3d(-480.39492948422242, -228.60616617546771, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint16, viewCenter16)
    
    scaleAboutPoint17 = NXOpen.Point3d(384.31594358737789, 183.91527059074252, 0.0)
    viewCenter17 = NXOpen.Point3d(-384.31594358737789, -183.91527059074252, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(308.27702499019699, 147.13221647259394, 0.0)
    viewCenter18 = NXOpen.Point3d(-308.27702499019671, -147.13221647259408, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(247.28103608839345, 117.70577317807512, 0.0)
    viewCenter19 = NXOpen.Point3d(-247.28103608839334, -117.70577317807533, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(198.35236174770327, 94.164618542460033, 0.0)
    viewCenter20 = NXOpen.Point3d(-198.35236174770318, -94.164618542460261, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint20, viewCenter20)
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder1 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects1 = [None] * 1 
    dragobjects1[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects1[0].Geometry = line3
    dragobjects1[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects1[0].PointIndex = 0
    sketchDragGeometryBuilder1.SetDragGeometry(dragobjects1)
    
    sketchDragGeometryBuilder1.SplineLinearScale = False
    
    foundrelations1 = sketchDragGeometryBuilder1.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects2 = [None] * 1 
    dragobjects2[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects2[0].Geometry = line3
    dragobjects2[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects2[0].PointIndex = 0
    sketchDragGeometryBuilder1.SetDragGeometry(dragobjects2)
    
    foundrelations2 = sketchDragGeometryBuilder1.FindRelations()
    
    sketchDragGeometryBuilder1.Destroy()
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences1 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences1 = dimensionPreferences1.GetNarrowDimensionPreferences()
    
    option1 = narrowDimensionPreferences1.DimensionDisplayOption
    
    sketchLinearDimensionBuilder1 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder1 = sketchLinearDimensionBuilder1.Driving
    
    drivingValueBuilder1.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject1 = sketchLinearDimensionBuilder1.FirstAssociativity
    
    selectNXObject2 = sketchLinearDimensionBuilder1.SecondAssociativity
    
    point1_3 = NXOpen.Point3d(165.0, 135.0, 0.0)
    point2_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject1.SetValue(NXOpen.InferSnapType.SnapType.Start, line3, NXOpen.View.Null, point1_3, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_3)
    
    point1_4 = NXOpen.Point3d(0.0, 135.0, 0.0)
    point2_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject2.SetValue(NXOpen.InferSnapType.SnapType.End, line3, NXOpen.View.Null, point1_4, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_4)
    
    dimensionMeasurementBuilder1 = sketchLinearDimensionBuilder1.Measurement
    
    dimensionMeasurementBuilder1.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder1 = sketchLinearDimensionBuilder1.Origin
    
    origin7 = NXOpen.Point3d(82.5, 149.35554033757879, 0.0)
    originBuilder1.OriginPoint = origin7
    
    originBuilder1.SetInferRelativeToGeometry(True)
    
    nXObject5 = sketchLinearDimensionBuilder1.Commit()
    
    horizontalDimension1 = nXObject5
    horizontalDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder1.Destroy()
    
    narrowDimensionPreferences1.Dispose()
    dimensionPreferences1.Dispose()
    sketchFindMovableObjectsBuilder3 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject6 = sketchFindMovableObjectsBuilder3.Commit()
    
    sketchFindMovableObjectsBuilder3.Destroy()
    
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder1 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension1)
    
    selectNXObjectList1 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    foundrelations3 = sketchEditDimensionValueBuilder1.FindRelations()
    
    sketchHelpedDimensionalConstraint1 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line3] StartVertex] [[Curve Line3] EndVertex]")
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId17, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId17, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId18, None)
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder1.DimValue = 120.0
    
    theSession.ActiveSketch.Scale(0.72727272727272729)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin8 = NXOpen.Point3d(60.0, 108.62221115460275, 0.0)
    horizontalDimension1.AnnotationOrigin = origin8
    
    sketchEditDimensionValueBuilder1.RestoreOperation()
    
    sketchEditDimensionValueBuilder1.LoadExtraGeometry()
    
    selectNXObjectList2 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    foundrelations4 = sketchEditDimensionValueBuilder1.FindRelations()
    
    nXObject7 = sketchEditDimensionValueBuilder1.Commit()
    
    theSession.SetUndoMarkName(markId19, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId19, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId17, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    selectNXObjectList3 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    objects2 = [NXOpen.NXObject.Null] * 1 
    objects2[0] = line4
    selectNXObjectList3.SetArray(objects2)
    
    sketchEditDimensionValueBuilder1.RestoreOperation()
    
    sketchEditDimensionValueBuilder1.LoadExtraGeometry()
    
    selectNXObjectList4 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    theSession.ActiveSketch.Update()
    
    theSession.SetUndoMarkName(markId20, "Edit Dimension Value - Selection")
    
    theSession.SetUndoMarkVisibility(markId20, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId17, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId22, None)
    
    theSession.SetUndoMarkName(markId17, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId21, None)
    
    theSession.SetUndoMarkVisibility(markId17, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId20, None)
    
    theSession.DeleteUndoMark(markId19, None)
    
    theSession.DeleteUndoMark(markId17, None)
    
    sketchFindMovableObjectsBuilder4 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject8 = sketchFindMovableObjectsBuilder4.Commit()
    
    sketchFindMovableObjectsBuilder4.Destroy()
    
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder2 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects3 = [None] * 1 
    dragobjects3[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects3[0].Geometry = line4
    dragobjects3[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects3[0].PointIndex = 0
    sketchDragGeometryBuilder2.SetDragGeometry(dragobjects3)
    
    sketchDragGeometryBuilder2.SplineLinearScale = False
    
    foundrelations5 = sketchDragGeometryBuilder2.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects4 = [None] * 1 
    dragobjects4[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects4[0].Geometry = line4
    dragobjects4[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects4[0].PointIndex = 0
    sketchDragGeometryBuilder2.SetDragGeometry(dragobjects4)
    
    foundrelations6 = sketchDragGeometryBuilder2.FindRelations()
    
    sketchDragGeometryBuilder2.Destroy()
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences2 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences2 = dimensionPreferences2.GetNarrowDimensionPreferences()
    
    option2 = narrowDimensionPreferences2.DimensionDisplayOption
    
    sketchLinearDimensionBuilder2 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder2 = sketchLinearDimensionBuilder2.Driving
    
    drivingValueBuilder2.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject3 = sketchLinearDimensionBuilder2.FirstAssociativity
    
    selectNXObject4 = sketchLinearDimensionBuilder2.SecondAssociativity
    
    point1_7 = NXOpen.Point3d(0.0, 98.181818181818187, 0.0)
    point2_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject3.SetValue(NXOpen.InferSnapType.SnapType.Start, line4, NXOpen.View.Null, point1_7, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_7)
    
    point1_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject4.SetValue(NXOpen.InferSnapType.SnapType.End, line4, NXOpen.View.Null, point1_8, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_8)
    
    dimensionMeasurementBuilder2 = sketchLinearDimensionBuilder2.Measurement
    
    dimensionMeasurementBuilder2.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder2 = sketchLinearDimensionBuilder2.Origin
    
    origin10 = NXOpen.Point3d(-10.440392972784579, 49.090909090909093, 0.0)
    originBuilder2.OriginPoint = origin10
    
    originBuilder2.SetInferRelativeToGeometry(True)
    
    nXObject9 = sketchLinearDimensionBuilder2.Commit()
    
    verticalDimension1 = nXObject9
    verticalDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder2.Destroy()
    
    narrowDimensionPreferences2.Dispose()
    dimensionPreferences2.Dispose()
    sketchFindMovableObjectsBuilder5 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject10 = sketchFindMovableObjectsBuilder5.Commit()
    
    sketchFindMovableObjectsBuilder5.Destroy()
    
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder2 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension1)
    
    selectNXObjectList5 = sketchEditDimensionValueBuilder2.ExtraGeometries
    
    foundrelations7 = sketchEditDimensionValueBuilder2.FindRelations()
    
    sketchHelpedDimensionalConstraint2 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line4] StartVertex] [[Curve Line4] EndVertex]")
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId26, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId26, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId27, None)
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder2.DimValue = 120.0
    
    nXObject11 = sketchEditDimensionValueBuilder2.Commit()
    
    theSession.SetUndoMarkName(markId28, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId28, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId26, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId30, None)
    
    theSession.SetUndoMarkName(markId26, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder2.Destroy()
    
    theSession.DeleteUndoMark(markId29, None)
    
    theSession.SetUndoMarkVisibility(markId26, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId28, None)
    
    theSession.DeleteUndoMark(markId26, None)
    
    sketchFindMovableObjectsBuilder6 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject12 = sketchFindMovableObjectsBuilder6.Commit()
    
    sketchFindMovableObjectsBuilder6.Destroy()
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder1 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder1.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject13 = sketchWorkRegionBuilder1.Commit()
    
    sketchWorkRegionBuilder1.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit2 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("2.8")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId32, "Extrude Dialog")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions1 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions1.SetSelectedFromInactive(False)
    
    curves1 = [NXOpen.ICurve.Null] * 4 
    curves1[0] = line1
    curves1[1] = line2
    curves1[2] = line3
    curves1[3] = line4
    seedPoint1 = NXOpen.Point3d(68.828759999999988, 68.828760000000003, 0.0)
    regionBoundaryRule1 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch1, curves1, seedPoint1, 0.01, selectionIntentRuleOptions1)
    
    selectionIntentRuleOptions1.Dispose()
    section1.AllowSelfIntersection(True)
    
    section1.AllowDegenerateCurves(False)
    
    rules1 = [None] * 1 
    rules1[0] = regionBoundaryRule1
    helpPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section1.AddToSection(rules1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId33, None)
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId35, None)
    
    direction3 = workPart.Directions.CreateDirection(sketch1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction3
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies2)
    
    targetBodies3 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies3)
    
    theSession.DeleteUndoMark(markId34, None)
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    targetBodies4[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies4)
    
    targetBodies5 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies5)
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    targetBodies6[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies6)
    
    targetBodies7 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies7)
    
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId36, None)
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    feature2 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId37, None)
    
    theSession.SetUndoMarkName(markId32, "Extrude")
    
    expression4 = extrudeBuilder1.Limits.StartExtend.Value
    expression5 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression3)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane4 = workPart.Planes.CreatePlane(origin11, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.PlaneReference = plane4
    
    expression6 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression7 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder2 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder2 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder2.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId40, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder2.UseWorkPartOrigin = False
    
    coordinates3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point4 = workPart.Points.CreatePoint(coordinates3)
    
    origin12 = NXOpen.Point3d(128.97597733423896, 128.97597733423896, 0.0)
    matrix3 = NXOpen.Matrix3x3()
    
    matrix3.Xx = 1.0
    matrix3.Xy = 0.0
    matrix3.Xz = 0.0
    matrix3.Yx = 0.0
    matrix3.Yy = 1.0
    matrix3.Yz = 0.0
    matrix3.Zx = 0.0
    matrix3.Zy = 0.0
    matrix3.Zz = 1.0
    plane5 = workPart.Planes.CreateFixedTypePlane(origin12, matrix3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point5 = workPart.Points.CreatePoint(coordinates4)
    
    origin13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction4 = workPart.Directions.CreateDirection(origin13, vector3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector4 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction5 = workPart.Directions.CreateDirection(origin14, vector4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix4 = NXOpen.Matrix3x3()
    
    matrix4.Xx = 1.0
    matrix4.Xy = 0.0
    matrix4.Xz = 0.0
    matrix4.Yx = 0.0
    matrix4.Yy = 1.0
    matrix4.Yz = 0.0
    matrix4.Zx = 0.0
    matrix4.Zy = 0.0
    matrix4.Zz = 1.0
    plane6 = workPart.Planes.CreateFixedTypePlane(origin15, matrix4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane6, direction5, point5, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder2.CoordinateSystem = cartesianCoordinateSystem2
    
    simpleSketchInPlaceBuilder2.HorizontalReference.Value = datumAxis1
    
    point6 = simpleSketchInPlaceBuilder2.SketchOrigin
    
    simpleSketchInPlaceBuilder2.SketchOrigin = point6
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId41, None)
    
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject14 = simpleSketchInPlaceBuilder2.Commit()
    
    sketch2 = nXObject14
    feature3 = sketch2.Feature
    
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId43)
    
    sketch2.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder7 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject15 = sketchFindMovableObjectsBuilder7.Commit()
    
    sketchFindMovableObjectsBuilder7.Destroy()
    
    theSession.DeleteUndoMark(markId42, None)
    
    theSession.SetUndoMarkName(markId40, "Create Sketch")
    
    sketchInPlaceBuilder2.Destroy()
    
    sketchAlongPathBuilder2.Destroy()
    
    simpleSketchInPlaceBuilder2.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression7)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression6)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane4.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId39, None, True)
    
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_001")
    
    scaleAboutPoint21 = NXOpen.Point3d(104.06410268719877, 78.820830253175401, 0.0)
    viewCenter21 = NXOpen.Point3d(-104.06410268719877, -78.820830253175401, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(128.79220629603816, 98.526037816469241, 0.0)
    viewCenter22 = NXOpen.Point3d(-128.79220629603816, -98.526037816469241, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(103.0337650368307, 78.820830253175316, 0.0)
    viewCenter23 = NXOpen.Point3d(-103.03376503683053, -78.820830253175487, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint23, viewCenter23)
    
    scaleAboutPoint24 = NXOpen.Point3d(82.427012029464549, 63.05666420254024, 0.0)
    viewCenter24 = NXOpen.Point3d(-82.427012029464279, -63.056664202540382, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(65.941609623571708, 50.445331362032192, 0.0)
    viewCenter25 = NXOpen.Point3d(-65.941609623571367, -50.445331362032306, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(51.170689067891644, 41.93886372059147, 0.0)
    viewCenter26 = NXOpen.Point3d(-51.170689067891374, -41.938863720591563, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(38.826419746359072, 33.973117278064016, 0.0)
    viewCenter27 = NXOpen.Point3d(-38.826419746358752, -33.973117278064123, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint27, viewCenter27)
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder2 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder2.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject16 = sketchWorkRegionBuilder2.Commit()
    
    sketchWorkRegionBuilder2.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder2.Section = section2
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    expression8 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder2.DistanceTolerance = 0.01
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    targetBodies8[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies8)
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies9 = [NXOpen.Body.Null] * 1 
    targetBodies9[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies9)
    
    extrudeBuilder2.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder2.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder2 = extrudeBuilder2.SmartVolumeProfile
    
    smartVolumeProfileBuilder2.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder2.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId46, "Extrude Dialog")
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId47, None)
    
    extrudeBuilder2.Destroy()
    
    section2.Destroy()
    
    workPart.Expressions.Delete(expression8)
    
    theSession.UndoToMark(markId46, None)
    
    theSession.DeleteUndoMark(markId46, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder3 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section3 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder3.Section = section3
    
    extrudeBuilder3.AllowSelfIntersectingSection(True)
    
    expression9 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder3.DistanceTolerance = 0.01
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies10 = [NXOpen.Body.Null] * 1 
    targetBodies10[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies10)
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies11 = [NXOpen.Body.Null] * 1 
    targetBodies11[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies11)
    
    extrudeBuilder3.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder3.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder3 = extrudeBuilder3.SmartVolumeProfile
    
    smartVolumeProfileBuilder3.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder3.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId48, "Extrude Dialog")
    
    section3.DistanceTolerance = 0.01
    
    section3.ChainingTolerance = 0.0094999999999999998
    
    section3.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder3.Destroy()
    
    section3.Destroy()
    
    workPart.Expressions.Delete(expression9)
    
    theSession.UndoToMark(markId48, None)
    
    theSession.DeleteUndoMark(markId48, None)
    
    scaleAboutPoint28 = NXOpen.Point3d(175.15740056261188, 40.698337189548099, 0.0)
    viewCenter28 = NXOpen.Point3d(-175.15740056261188, -40.698337189548099, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(215.0829845143837, 47.009155298054189, 0.0)
    viewCenter29 = NXOpen.Point3d(-215.0829845143837, -47.009155298053969, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint29, viewCenter29)
    
    scaleAboutPoint30 = NXOpen.Point3d(264.0240229068782, 53.931736386466035, 0.0)
    viewCenter30 = NXOpen.Point3d(-264.0240229068782, -53.931736386466035, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(293.807220612837, 77.476561599960561, 0.0)
    viewCenter31 = NXOpen.Point3d(-293.807220612837, -77.476561599960561, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(235.04577649026962, 61.981249279968452, 0.0)
    viewCenter32 = NXOpen.Point3d(-235.04577649026962, -61.981249279968452, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(188.03662119221568, 49.58499942397475, 0.0)
    viewCenter33 = NXOpen.Point3d(-188.03662119221568, -49.58499942397475, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(150.42929695377254, 38.637661888811472, 0.0)
    viewCenter34 = NXOpen.Point3d(-150.42929695377254, -38.63766188881138, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(115.39781684125015, 27.613049029870677, 0.0)
    viewCenter35 = NXOpen.Point3d(-115.39781684125015, -27.613049029870535, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(91.658837376764438, 19.452774838953687, 0.0)
    viewCenter36 = NXOpen.Point3d(-91.658837376764438, -19.452774838953577, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint36, viewCenter36)
    
    # ----------------------------------------------
    #   Menu: Insert->Datum->Datum Plane...
    # ----------------------------------------------
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    datumPlaneBuilder1 = workPart.Features.CreateDatumPlaneBuilder(NXOpen.Features.Feature.Null)
    
    plane7 = datumPlaneBuilder1.GetPlane()
    
    expression10 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression11 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    coordinates5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point7 = workPart.Points.CreatePoint(coordinates5)
    
    theSession.SetUndoMarkName(markId49, "Datum Plane Dialog")
    
    plane7.SetUpdateOption(NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane7.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
    
    geom1 = [NXOpen.NXObject.Null] * 1 
    extrude1 = feature2
    face1 = extrude1.FindObject("FACE 130 {(60,60,10) EXTRUDE(2)}")
    geom1[0] = face1
    plane7.SetGeometry(geom1)
    
    plane7.SetFlip(False)
    
    plane7.SetReverseSide(False)
    
    expression12 = plane7.Expression
    
    expression12.RightHandSide = "0"
    
    plane7.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane7.Evaluate()
    
    plane7.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
    
    geom2 = [NXOpen.NXObject.Null] * 1 
    geom2[0] = face1
    plane7.SetGeometry(geom2)
    
    plane7.SetFlip(False)
    
    plane7.SetReverseSide(False)
    
    expression13 = plane7.Expression
    
    expression13.RightHandSide = "0"
    
    plane7.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane7.Evaluate()
    
    coordinates6 = NXOpen.Point3d(60.0, 60.0, 10.0)
    point8 = workPart.Points.CreatePoint(coordinates6)
    
    workPart.Points.DeletePoint(point7)
    
    coordinates7 = NXOpen.Point3d(60.0, 60.0, 10.0)
    point9 = workPart.Points.CreatePoint(coordinates7)
    
    workPart.Points.DeletePoint(point8)
    
    coordinates8 = NXOpen.Point3d(60.0, 60.0, 10.0)
    point10 = workPart.Points.CreatePoint(coordinates8)
    
    workPart.Points.DeletePoint(point9)
    
    coordinates9 = NXOpen.Point3d(60.0, 60.0, 10.0)
    point11 = workPart.Points.CreatePoint(coordinates9)
    
    workPart.Points.DeletePoint(point10)
    
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Datum Plane")
    
    theSession.DeleteUndoMark(markId50, None)
    
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Datum Plane")
    
    plane7.RemoveOffsetData()
    
    plane7.Evaluate()
    
    corner1_1 = NXOpen.Point3d(-3.0, -3.0, 10.0)
    corner2_1 = NXOpen.Point3d(123.0, -3.0, 10.0)
    corner3_1 = NXOpen.Point3d(123.0, 123.0, 10.0)
    corner4_1 = NXOpen.Point3d(-3.0, 123.0, 10.0)
    datumPlaneBuilder1.SetCornerPoints(corner1_1, corner2_1, corner3_1, corner4_1)
    
    datumPlaneBuilder1.ResizeDuringUpdate = True
    
    feature4 = datumPlaneBuilder1.CommitFeature()
    
    datumPlaneFeature1 = feature4
    datumPlane1 = datumPlaneFeature1.DatumPlane
    
    datumPlane1.SetReverseSection(False)
    
    theSession.DeleteUndoMark(markId51, None)
    
    theSession.SetUndoMarkName(markId49, "Datum Plane")
    
    datumPlaneBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression11)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression10)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder3 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane8 = workPart.Planes.CreatePlane(origin16, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.PlaneReference = plane8
    
    expression14 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression15 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder3 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder3 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder3.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId54, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder3.UseWorkPartOrigin = False
    
    scalar1 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge1 = extrude1.FindObject("EDGE * 130 * 160 {(120,0,10)(120,60,10)(120,120,10) EXTRUDE(2)}")
    point12 = workPart.Points.CreatePoint(edge1, scalar1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge2 = extrude1.FindObject("EDGE * 130 * 140 {(0,120,10)(0,60,10)(0,0,10) EXTRUDE(2)}")
    direction6 = workPart.Directions.CreateDirection(edge2, NXOpen.Sense.Reverse, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform3 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction6, point12, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem3 = workPart.CoordinateSystems.CreateCoordinateSystem(xform3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder3.CoordinateSystem = cartesianCoordinateSystem3
    
    simpleSketchInPlaceBuilder3.HorizontalReference.Value = edge2
    
    point13 = simpleSketchInPlaceBuilder3.SketchOrigin
    
    simpleSketchInPlaceBuilder3.SketchOrigin = point13
    
    scalar2 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point14 = workPart.Points.CreatePoint(edge1, scalar2, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId55, None)
    
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject17 = simpleSketchInPlaceBuilder3.Commit()
    
    sketch3 = nXObject17
    feature5 = sketch3.Feature
    
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs3 = theSession.UpdateManager.DoUpdate(markId57)
    
    sketch3.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder8 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject18 = sketchFindMovableObjectsBuilder8.Commit()
    
    sketchFindMovableObjectsBuilder8.Destroy()
    
    theSession.DeleteUndoMark(markId56, None)
    
    theSession.SetUndoMarkName(markId54, "Create Sketch")
    
    sketchInPlaceBuilder3.Destroy()
    
    sketchAlongPathBuilder3.Destroy()
    
    simpleSketchInPlaceBuilder3.Destroy()
    
    workPart.Points.DeletePoint(point14)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression15)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression14)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane8.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId53, None, True)
    
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_002")
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder3 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder3.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject19 = sketchWorkRegionBuilder3.Commit()
    
    sketchWorkRegionBuilder3.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder4 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal4 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane9 = workPart.Planes.CreatePlane(origin17, normal4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.PlaneReference = plane9
    
    expression16 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression17 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder4 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder4 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder4.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId62, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder4.UseWorkPartOrigin = False
    
    scalar3 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point15 = workPart.Points.CreatePoint(edge1, scalar3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction7 = workPart.Directions.CreateDirection(edge2, NXOpen.Sense.Reverse, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform4 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction7, point15, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem4 = workPart.CoordinateSystems.CreateCoordinateSystem(xform4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder4.CoordinateSystem = cartesianCoordinateSystem4
    
    simpleSketchInPlaceBuilder4.HorizontalReference.Value = edge2
    
    point16 = simpleSketchInPlaceBuilder4.SketchOrigin
    
    simpleSketchInPlaceBuilder4.SketchOrigin = point16
    
    scalar4 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point17 = workPart.Points.CreatePoint(edge1, scalar4, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId63, None)
    
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject20 = simpleSketchInPlaceBuilder4.Commit()
    
    sketch4 = nXObject20
    feature6 = sketch4.Feature
    
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs4 = theSession.UpdateManager.DoUpdate(markId65)
    
    sketch4.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder9 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject21 = sketchFindMovableObjectsBuilder9.Commit()
    
    sketchFindMovableObjectsBuilder9.Destroy()
    
    theSession.DeleteUndoMark(markId64, None)
    
    theSession.SetUndoMarkName(markId62, "Create Sketch")
    
    sketchInPlaceBuilder4.Destroy()
    
    sketchAlongPathBuilder4.Destroy()
    
    simpleSketchInPlaceBuilder4.Destroy()
    
    workPart.Points.DeletePoint(point17)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression17)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression16)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane9.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId61, None, True)
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_003")
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    theSession.DeleteUndoMark(markId68, "Create Rectangle")
    
    sketchFindMovableObjectsBuilder10 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject22 = sketchFindMovableObjectsBuilder10.Commit()
    
    sketchFindMovableObjectsBuilder10.Destroy()
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId70, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint5 = NXOpen.Point3d(10.0, 15.0, 10.0)
    endPoint5 = NXOpen.Point3d(10.0, 105.0, 10.0)
    line5 = workPart.Curves.CreateLine(startPoint5, endPoint5)
    
    startPoint6 = NXOpen.Point3d(10.0, 105.0, 10.0)
    endPoint6 = NXOpen.Point3d(95.0, 105.0, 10.0)
    line6 = workPart.Curves.CreateLine(startPoint6, endPoint6)
    
    startPoint7 = NXOpen.Point3d(95.0, 105.0, 10.0)
    endPoint7 = NXOpen.Point3d(95.0, 15.0, 10.0)
    line7 = workPart.Curves.CreateLine(startPoint7, endPoint7)
    
    startPoint8 = NXOpen.Point3d(95.0, 15.0, 10.0)
    endPoint8 = NXOpen.Point3d(10.0, 15.0, 10.0)
    line8 = workPart.Curves.CreateLine(startPoint8, endPoint8)
    
    theSession.ActiveSketch.AddGeometry(line5, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line6, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line7, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line8, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_5.Geometry = line5
    conGeom1_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_5.SplineDefiningPointIndex = 0
    conGeom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_5.Geometry = line6
    conGeom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint5 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_5, conGeom2_5)
    
    conGeom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_6.Geometry = line6
    conGeom1_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_6.SplineDefiningPointIndex = 0
    conGeom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_6.Geometry = line7
    conGeom2_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint6 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_6, conGeom2_6)
    
    conGeom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_7.Geometry = line7
    conGeom1_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_7.SplineDefiningPointIndex = 0
    conGeom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_7.Geometry = line8
    conGeom2_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint7 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_7, conGeom2_7)
    
    conGeom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_8.Geometry = line8
    conGeom1_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_8.SplineDefiningPointIndex = 0
    conGeom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_8.Geometry = line5
    conGeom2_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint8 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_8, conGeom2_8)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms3 = [NXOpen.SmartObject.Null] * 4 
    geoms3[0] = line5
    geoms3[1] = line6
    geoms3[2] = line7
    geoms3[3] = line8
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms3)
    
    geoms4 = [NXOpen.SmartObject.Null] * 4 
    geoms4[0] = line5
    geoms4[1] = line6
    geoms4[2] = line7
    geoms4[3] = line8
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms4)
    
    objects3 = [NXOpen.NXObject.Null] * 4 
    objects3[0] = sketchGeometricConstraint5
    objects3[1] = sketchGeometricConstraint6
    objects3[2] = sketchGeometricConstraint7
    objects3[3] = sketchGeometricConstraint8
    errorList2 = theSession.ActiveSketch.DeleteObjects(objects3)
    
    errorList2.Dispose()
    sketchFindMovableObjectsBuilder11 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject23 = sketchFindMovableObjectsBuilder11.Commit()
    
    sketchFindMovableObjectsBuilder11.Destroy()
    
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder3 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects5 = [None] * 1 
    dragobjects5[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects5[0].Geometry = line5
    dragobjects5[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects5[0].PointIndex = 0
    sketchDragGeometryBuilder3.SetDragGeometry(dragobjects5)
    
    sketchDragGeometryBuilder3.SplineLinearScale = False
    
    foundrelations8 = sketchDragGeometryBuilder3.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects6 = [None] * 1 
    dragobjects6[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects6[0].Geometry = line5
    dragobjects6[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects6[0].PointIndex = 0
    sketchDragGeometryBuilder3.SetDragGeometry(dragobjects6)
    
    foundrelations9 = sketchDragGeometryBuilder3.FindRelations()
    
    sketchDragGeometryBuilder3.Destroy()
    
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences3 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences3 = dimensionPreferences3.GetNarrowDimensionPreferences()
    
    option3 = narrowDimensionPreferences3.DimensionDisplayOption
    
    sketchLinearDimensionBuilder3 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder3 = sketchLinearDimensionBuilder3.Driving
    
    drivingValueBuilder3.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject5 = sketchLinearDimensionBuilder3.FirstAssociativity
    
    selectNXObject6 = sketchLinearDimensionBuilder3.SecondAssociativity
    
    point1_11 = NXOpen.Point3d(10.0, 15.0, 10.0)
    point2_11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject5.SetValue(NXOpen.InferSnapType.SnapType.Start, line5, NXOpen.View.Null, point1_11, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_11)
    
    point1_12 = NXOpen.Point3d(10.0, 105.0, 10.0)
    point2_12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject6.SetValue(NXOpen.InferSnapType.SnapType.End, line5, NXOpen.View.Null, point1_12, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_12)
    
    dimensionMeasurementBuilder3 = sketchLinearDimensionBuilder3.Measurement
    
    dimensionMeasurementBuilder3.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder3 = sketchLinearDimensionBuilder3.Origin
    
    origin19 = NXOpen.Point3d(-7.9444254219734916, 60.0, 10.0)
    originBuilder3.OriginPoint = origin19
    
    originBuilder3.SetInferRelativeToGeometry(True)
    
    nXObject24 = sketchLinearDimensionBuilder3.Commit()
    
    horizontalDimension2 = nXObject24
    horizontalDimension2.IsOriginCentered = True
    
    sketchLinearDimensionBuilder3.Destroy()
    
    narrowDimensionPreferences3.Dispose()
    dimensionPreferences3.Dispose()
    sketchFindMovableObjectsBuilder12 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject25 = sketchFindMovableObjectsBuilder12.Commit()
    
    sketchFindMovableObjectsBuilder12.Destroy()
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder3 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension2)
    
    selectNXObjectList6 = sketchEditDimensionValueBuilder3.ExtraGeometries
    
    foundrelations10 = sketchEditDimensionValueBuilder3.FindRelations()
    
    sketchHelpedDimensionalConstraint3 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line5] StartVertex] [[Curve Line5] EndVertex]")
    sketchHelpedDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId74, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId74, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId75, None)
    
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder3.DimValue = 117.0
    
    theSession.ActiveSketch.Scale(1.3)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin20 = NXOpen.Point3d(-10.327753048565539, 78.0, 13.0)
    horizontalDimension2.AnnotationOrigin = origin20
    
    sketchEditDimensionValueBuilder3.RestoreOperation()
    
    sketchEditDimensionValueBuilder3.LoadExtraGeometry()
    
    selectNXObjectList7 = sketchEditDimensionValueBuilder3.ExtraGeometries
    
    foundrelations11 = sketchEditDimensionValueBuilder3.FindRelations()
    
    nXObject26 = sketchEditDimensionValueBuilder3.Commit()
    
    theSession.SetUndoMarkName(markId76, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId76, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId74, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    selectNXObjectList8 = sketchEditDimensionValueBuilder3.ExtraGeometries
    
    objects4 = [NXOpen.NXObject.Null] * 1 
    objects4[0] = line6
    selectNXObjectList8.SetArray(objects4)
    
    sketchEditDimensionValueBuilder3.RestoreOperation()
    
    sketchEditDimensionValueBuilder3.LoadExtraGeometry()
    
    selectNXObjectList9 = sketchEditDimensionValueBuilder3.ExtraGeometries
    
    theSession.ActiveSketch.Update()
    
    theSession.SetUndoMarkName(markId77, "Edit Dimension Value - Selection")
    
    theSession.SetUndoMarkVisibility(markId77, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId74, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId79, None)
    
    theSession.SetUndoMarkName(markId74, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder3.Destroy()
    
    theSession.DeleteUndoMark(markId78, None)
    
    theSession.SetUndoMarkVisibility(markId74, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId77, None)
    
    theSession.DeleteUndoMark(markId76, None)
    
    theSession.DeleteUndoMark(markId74, None)
    
    sketchFindMovableObjectsBuilder13 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject27 = sketchFindMovableObjectsBuilder13.Commit()
    
    sketchFindMovableObjectsBuilder13.Destroy()
    
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder4 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects7 = [None] * 1 
    dragobjects7[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects7[0].Geometry = line6
    dragobjects7[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects7[0].PointIndex = 0
    sketchDragGeometryBuilder4.SetDragGeometry(dragobjects7)
    
    sketchDragGeometryBuilder4.SplineLinearScale = False
    
    foundrelations12 = sketchDragGeometryBuilder4.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects8 = [None] * 1 
    dragobjects8[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects8[0].Geometry = line6
    dragobjects8[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects8[0].PointIndex = 0
    sketchDragGeometryBuilder4.SetDragGeometry(dragobjects8)
    
    foundrelations13 = sketchDragGeometryBuilder4.FindRelations()
    
    sketchDragGeometryBuilder4.Destroy()
    
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences4 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences4 = dimensionPreferences4.GetNarrowDimensionPreferences()
    
    option4 = narrowDimensionPreferences4.DimensionDisplayOption
    
    sketchLinearDimensionBuilder4 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder4 = sketchLinearDimensionBuilder4.Driving
    
    drivingValueBuilder4.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject7 = sketchLinearDimensionBuilder4.FirstAssociativity
    
    selectNXObject8 = sketchLinearDimensionBuilder4.SecondAssociativity
    
    point1_15 = NXOpen.Point3d(-23.0, 100.5, 10.0)
    point2_15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject7.SetValue(NXOpen.InferSnapType.SnapType.Start, line6, NXOpen.View.Null, point1_15, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_15)
    
    point1_16 = NXOpen.Point3d(87.5, 100.5, 10.0)
    point2_16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject8.SetValue(NXOpen.InferSnapType.SnapType.End, line6, NXOpen.View.Null, point1_16, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_16)
    
    dimensionMeasurementBuilder4 = sketchLinearDimensionBuilder4.Measurement
    
    dimensionMeasurementBuilder4.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder4 = sketchLinearDimensionBuilder4.Origin
    
    origin22 = NXOpen.Point3d(32.25, 123.82775304856554, 10.0)
    originBuilder4.OriginPoint = origin22
    
    originBuilder4.SetInferRelativeToGeometry(True)
    
    nXObject28 = sketchLinearDimensionBuilder4.Commit()
    
    verticalDimension2 = nXObject28
    verticalDimension2.IsOriginCentered = True
    
    sketchLinearDimensionBuilder4.Destroy()
    
    narrowDimensionPreferences4.Dispose()
    dimensionPreferences4.Dispose()
    sketchFindMovableObjectsBuilder14 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject29 = sketchFindMovableObjectsBuilder14.Commit()
    
    sketchFindMovableObjectsBuilder14.Destroy()
    
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder4 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension2)
    
    selectNXObjectList10 = sketchEditDimensionValueBuilder4.ExtraGeometries
    
    foundrelations14 = sketchEditDimensionValueBuilder4.FindRelations()
    
    sketchHelpedDimensionalConstraint4 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line6] StartVertex] [[Curve Line6] EndVertex]")
    sketchHelpedDimensionalConstraint4.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId83, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId83, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint4.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId84, None)
    
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder4.DimValue = 117.0
    
    nXObject30 = sketchEditDimensionValueBuilder4.Commit()
    
    theSession.SetUndoMarkName(markId85, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId85, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId83, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint4.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId87, None)
    
    theSession.SetUndoMarkName(markId83, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder4.Destroy()
    
    theSession.DeleteUndoMark(markId86, None)
    
    theSession.SetUndoMarkVisibility(markId83, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId85, None)
    
    theSession.DeleteUndoMark(markId83, None)
    
    sketchFindMovableObjectsBuilder15 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject31 = sketchFindMovableObjectsBuilder15.Commit()
    
    sketchFindMovableObjectsBuilder15.Destroy()
    
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder5 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects9 = [None] * 1 
    dragobjects9[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects9[0].Geometry = line6
    dragobjects9[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects9[0].PointIndex = 0
    sketchDragGeometryBuilder5.SetDragGeometry(dragobjects9)
    
    sketchDragGeometryBuilder5.SplineLinearScale = False
    
    foundrelations15 = sketchDragGeometryBuilder5.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    scaleAboutPoint37 = NXOpen.Point3d(2.1101315079542604, 98.912414435357462, 0.0)
    viewCenter37 = NXOpen.Point3d(-2.1101315079542604, -98.912414435357277, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint37, viewCenter37)
    
    scaleAboutPoint38 = NXOpen.Point3d(1.3188321924714692, 124.29993414043251, 0.0)
    viewCenter38 = NXOpen.Point3d(-1.3188321924713566, -124.2999341404324, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(10.715511563830473, 163.61761887848704, 0.0)
    viewCenter39 = NXOpen.Point3d(-10.715511563830193, -163.61761887848689, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint39, viewCenter39)
    
    scaleAboutPoint40 = NXOpen.Point3d(-5.2753287698855944, 133.53175948773242, 0.0)
    viewCenter40 = NXOpen.Point3d(5.2753287698859319, -133.53175948773242, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(-13.715854801702781, 109.46307197512881, 0.0)
    viewCenter41 = NXOpen.Point3d(13.715854801703051, -109.46307197512881, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint41, viewCenter41)
    
    scaleAboutPoint42 = NXOpen.Point3d(-12.660789047725562, 87.570457580103053, 0.0)
    viewCenter42 = NXOpen.Point3d(12.660789047725887, -87.570457580103053, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(-10.803873320725813, 70.056366064082454, 0.0)
    viewCenter43 = NXOpen.Point3d(10.80387332072616, -70.056366064082454, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint43, viewCenter43)
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = 0.0048005402080979979
    rotMatrix1.Xy = 0.999731461302512
    rotMatrix1.Xz = 0.022670688027811262
    rotMatrix1.Yx = -0.86410232043098956
    rotMatrix1.Yy = -0.0072631285268047307
    rotMatrix1.Yz = 0.5032637745653683
    rotMatrix1.Zx = 0.50329328888779057
    rotMatrix1.Zy = -0.022005732115678984
    rotMatrix1.Zz = 0.86383540857883523
    translation1 = NXOpen.Point3d(-113.13104738036532, 54.104509583301237, -33.088684921078467)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 0.97958695174909582)
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = 0.39049194651596769
    rotMatrix2.Xy = 0.92057996723455671
    rotMatrix2.Xz = -0.006968761194811865
    rotMatrix2.Yx = -0.70624731110824934
    rotMatrix2.Yy = 0.30441478673660277
    rotMatrix2.Yz = 0.63917632400494595
    rotMatrix2.Zx = 0.59053431336251472
    rotMatrix2.Zy = -0.24467153807202083
    rotMatrix2.Zz = 0.76902864914054558
    translation2 = NXOpen.Point3d(-127.24924036395871, 25.771913561148622, -22.859759561246673)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation2, 0.97958695174909582)
    
    dragobjects10 = [None] * 1 
    dragobjects10[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects10[0].Geometry = line6
    dragobjects10[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects10[0].PointIndex = 0
    sketchDragGeometryBuilder5.SetDragGeometry(dragobjects10)
    
    foundrelations16 = sketchDragGeometryBuilder5.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects11 = [None] * 1 
    dragobjects11[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects11[0].Geometry = line6
    dragobjects11[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects11[0].PointIndex = 0
    sketchDragGeometryBuilder5.SetDragGeometry(dragobjects11)
    
    foundrelations17 = sketchDragGeometryBuilder5.FindRelations()
    
    sketchDragGeometryBuilder5.Destroy()
    
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences5 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences5 = dimensionPreferences5.GetNarrowDimensionPreferences()
    
    option5 = narrowDimensionPreferences5.DimensionDisplayOption
    
    sketchLinearDimensionBuilder5 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder5 = sketchLinearDimensionBuilder5.Driving
    
    drivingValueBuilder5.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder5 = sketchLinearDimensionBuilder5.Measurement
    
    dimensionMeasurementBuilder5.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject9 = sketchLinearDimensionBuilder5.FirstAssociativity
    
    selectNXObject10 = sketchLinearDimensionBuilder5.SecondAssociativity
    
    infiniteLine2 = theSession.ActiveSketch.FindObject("YAxis")
    point1_19 = NXOpen.Point3d(-15.528761173241946, 120.0, 10.0)
    point2_19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject9.SetValue(NXOpen.InferSnapType.SnapType.NotSet, infiniteLine2, NXOpen.View.Null, point1_19, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_19)
    
    point1_20 = NXOpen.Point3d(-23.000000000000028, 100.5, 10.0)
    point2_20 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject10.SetValue(NXOpen.InferSnapType.SnapType.Start, line6, NXOpen.View.Null, point1_20, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_20)
    
    originBuilder5 = sketchLinearDimensionBuilder5.Origin
    
    origin24 = NXOpen.Point3d(22.670184195608712, 110.25, 10.0)
    originBuilder5.OriginPoint = origin24
    
    originBuilder5.SetInferRelativeToGeometry(True)
    
    nXObject32 = sketchLinearDimensionBuilder5.Commit()
    
    perpendicularDimension1 = nXObject32
    perpendicularDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder5.Destroy()
    
    narrowDimensionPreferences5.Dispose()
    dimensionPreferences5.Dispose()
    sketchFindMovableObjectsBuilder16 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject33 = sketchFindMovableObjectsBuilder16.Commit()
    
    sketchFindMovableObjectsBuilder16.Destroy()
    
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder5 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension1)
    
    selectNXObjectList11 = sketchEditDimensionValueBuilder5.ExtraGeometries
    
    foundrelations18 = sketchEditDimensionValueBuilder5.FindRelations()
    
    sketchHelpedDimensionalConstraint5 = theSession.ActiveSketch.FindObject("PerpendicularDim [YAxis] [[Curve Line6] StartVertex]")
    sketchHelpedDimensionalConstraint5.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId91, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId91, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint5.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId92, None)
    
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder5.DimValue = 1.5
    
    nXObject34 = sketchEditDimensionValueBuilder5.Commit()
    
    theSession.SetUndoMarkName(markId93, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId93, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId91, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    selectNXObjectList12 = sketchEditDimensionValueBuilder5.ExtraGeometries
    
    objects5 = [NXOpen.NXObject.Null] * 1 
    objects5[0] = line7
    selectNXObjectList12.SetArray(objects5)
    
    sketchEditDimensionValueBuilder5.RestoreOperation()
    
    sketchEditDimensionValueBuilder5.LoadExtraGeometry()
    
    selectNXObjectList13 = sketchEditDimensionValueBuilder5.ExtraGeometries
    
    theSession.ActiveSketch.Update()
    
    theSession.SetUndoMarkName(markId94, "Edit Dimension Value - Selection")
    
    theSession.SetUndoMarkVisibility(markId94, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId91, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint5.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId96, None)
    
    theSession.SetUndoMarkName(markId91, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder5.Destroy()
    
    theSession.DeleteUndoMark(markId95, None)
    
    theSession.SetUndoMarkVisibility(markId91, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId94, None)
    
    theSession.DeleteUndoMark(markId93, None)
    
    theSession.DeleteUndoMark(markId91, None)
    
    sketchFindMovableObjectsBuilder17 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject35 = sketchFindMovableObjectsBuilder17.Commit()
    
    sketchFindMovableObjectsBuilder17.Destroy()
    
    markId97 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder6 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects12 = [None] * 1 
    dragobjects12[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects12[0].Geometry = line8
    dragobjects12[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects12[0].PointIndex = 0
    sketchDragGeometryBuilder6.SetDragGeometry(dragobjects12)
    
    sketchDragGeometryBuilder6.SplineLinearScale = False
    
    foundrelations19 = sketchDragGeometryBuilder6.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects13 = [None] * 1 
    dragobjects13[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects13[0].Geometry = line8
    dragobjects13[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects13[0].PointIndex = 0
    sketchDragGeometryBuilder6.SetDragGeometry(dragobjects13)
    
    foundrelations20 = sketchDragGeometryBuilder6.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    rotMatrix3 = NXOpen.Matrix3x3()
    
    rotMatrix3.Xx = 0.48741427585111896
    rotMatrix3.Xy = 0.86324662367717009
    rotMatrix3.Xz = -0.13127296144481304
    rotMatrix3.Yx = -0.56476537462849452
    rotMatrix3.Yy = 0.42633443231465823
    rotMatrix3.Yz = 0.70659678986227581
    rotMatrix3.Zx = 0.66593347664557512
    rotMatrix3.Zy = -0.27026693940047491
    rotMatrix3.Zz = 0.69533329141486722
    translation3 = NXOpen.Point3d(-127.49700285714187, 9.1789046412730428, -24.552879971477438)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix3, translation3, 0.97958695174909582)
    
    sketchDragGeometryBuilder6.Destroy()
    
    markId98 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder7 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects14 = [None] * 1 
    dragobjects14[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects14[0].Geometry = line7
    dragobjects14[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects14[0].PointIndex = 0
    sketchDragGeometryBuilder7.SetDragGeometry(dragobjects14)
    
    sketchDragGeometryBuilder7.SplineLinearScale = False
    
    foundrelations21 = sketchDragGeometryBuilder7.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects15 = [None] * 1 
    dragobjects15[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects15[0].Geometry = line7
    dragobjects15[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects15[0].PointIndex = 0
    sketchDragGeometryBuilder7.SetDragGeometry(dragobjects15)
    
    foundrelations22 = sketchDragGeometryBuilder7.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects16 = [None] * 1 
    dragobjects16[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects16[0].Geometry = line7
    dragobjects16[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects16[0].PointIndex = 0
    sketchDragGeometryBuilder7.SetDragGeometry(dragobjects16)
    
    foundrelations23 = sketchDragGeometryBuilder7.FindRelations()
    
    sketchDragGeometryBuilder7.Destroy()
    
    markId99 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences6 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences6 = dimensionPreferences6.GetNarrowDimensionPreferences()
    
    option6 = narrowDimensionPreferences6.DimensionDisplayOption
    
    sketchLinearDimensionBuilder6 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder6 = sketchLinearDimensionBuilder6.Driving
    
    drivingValueBuilder6.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder6 = sketchLinearDimensionBuilder6.Measurement
    
    dimensionMeasurementBuilder6.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject11 = sketchLinearDimensionBuilder6.FirstAssociativity
    
    selectNXObject12 = sketchLinearDimensionBuilder6.SecondAssociativity
    
    infiniteLine4 = theSession.ActiveSketch.FindObject("XAxis")
    point1_29 = NXOpen.Point3d(120.0, 108.14367120343741, 10.0)
    point2_29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject11.SetValue(NXOpen.InferSnapType.SnapType.NotSet, infiniteLine4, NXOpen.View.Null, point1_29, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_29)
    
    point1_30 = NXOpen.Point3d(94.0, 118.5, 10.0)
    point2_30 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject12.SetValue(NXOpen.InferSnapType.SnapType.Start, line7, NXOpen.View.Null, point1_30, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_30)
    
    originBuilder6 = sketchLinearDimensionBuilder6.Origin
    
    origin29 = NXOpen.Point3d(106.99999999999986, 60.652266254859015, 10.0)
    originBuilder6.OriginPoint = origin29
    
    originBuilder6.SetInferRelativeToGeometry(True)
    
    nXObject36 = sketchLinearDimensionBuilder6.Commit()
    
    perpendicularDimension2 = nXObject36
    perpendicularDimension2.IsOriginCentered = True
    
    sketchLinearDimensionBuilder6.Destroy()
    
    narrowDimensionPreferences6.Dispose()
    dimensionPreferences6.Dispose()
    sketchFindMovableObjectsBuilder18 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject37 = sketchFindMovableObjectsBuilder18.Commit()
    
    sketchFindMovableObjectsBuilder18.Destroy()
    
    markId100 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId101 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder6 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension2)
    
    selectNXObjectList14 = sketchEditDimensionValueBuilder6.ExtraGeometries
    
    foundrelations24 = sketchEditDimensionValueBuilder6.FindRelations()
    
    sketchHelpedDimensionalConstraint6 = theSession.ActiveSketch.FindObject("PerpendicularDim [XAxis] [[Curve Line7] StartVertex]")
    sketchHelpedDimensionalConstraint6.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId101, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId101, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint6.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId102 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId102, None)
    
    markId103 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder6.DimValue = 1.5
    
    nXObject38 = sketchEditDimensionValueBuilder6.Commit()
    
    theSession.SetUndoMarkName(markId103, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId103, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId101, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId104 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    markId105 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint6.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId105, None)
    
    theSession.SetUndoMarkName(markId101, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder6.Destroy()
    
    theSession.DeleteUndoMark(markId104, None)
    
    theSession.SetUndoMarkVisibility(markId101, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId103, None)
    
    theSession.DeleteUndoMark(markId101, None)
    
    sketchFindMovableObjectsBuilder19 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject39 = sketchFindMovableObjectsBuilder19.Commit()
    
    sketchFindMovableObjectsBuilder19.Destroy()
    
    sketchWorkRegionBuilder4 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder4.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject40 = sketchWorkRegionBuilder4.Commit()
    
    sketchWorkRegionBuilder4.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId106 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    scaleAboutPoint44 = NXOpen.Point3d(113.41956855254305, 5.01156233139156, 0.0)
    viewCenter44 = NXOpen.Point3d(-113.41956855254305, -5.0115623313913797, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint44, viewCenter44)
    
    scaleAboutPoint45 = NXOpen.Point3d(141.11504459444328, -6.2644529142392251, 0.0)
    viewCenter45 = NXOpen.Point3d(-141.11504459444316, 6.2644529142393379, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint45, viewCenter45)
    
    scaleAboutPoint46 = NXOpen.Point3d(112.8920356755546, -6.0666280853685102, 0.0)
    viewCenter46 = NXOpen.Point3d(-112.89203567555442, 6.0666280853685999, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint46, viewCenter46)
    
    scaleAboutPoint47 = NXOpen.Point3d(90.31362854044373, -5.2753287698856433, 0.0)
    viewCenter47 = NXOpen.Point3d(-90.313628540443517, 5.2753287698857507, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint47, viewCenter47)
    
    scaleAboutPoint48 = NXOpen.Point3d(72.250902832354996, -6.9212313460899964, 0.0)
    viewCenter48 = NXOpen.Point3d(-72.250902832354768, 6.9212313460901109, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint48, viewCenter48)
    
    scaleAboutPoint49 = NXOpen.Point3d(57.53062543286584, -7.9678565740353386, 0.0)
    viewCenter49 = NXOpen.Point3d(-57.530625432865612, 7.9678565740354541, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint49, viewCenter49)
    
    scaleAboutPoint50 = NXOpen.Point3d(46.240577812707244, -7.0225176584718119, 0.0)
    viewCenter50 = NXOpen.Point3d(-46.240577812707023, 7.0225176584719229, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint50, viewCenter50)
    
    scaleAboutPoint51 = NXOpen.Point3d(37.683910142692312, -6.6551859655671288, 0.0)
    viewCenter51 = NXOpen.Point3d(-37.683910142692042, 6.655185965567247, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint51, viewCenter51)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId107 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder4 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section4 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder4.Section = section4
    
    extrudeBuilder4.AllowSelfIntersectingSection(True)
    
    expression18 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder4.DistanceTolerance = 0.01
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies12 = [NXOpen.Body.Null] * 1 
    targetBodies12[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies12)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies13 = [NXOpen.Body.Null] * 1 
    targetBodies13[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies13)
    
    extrudeBuilder4.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder4.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder4 = extrudeBuilder4.SmartVolumeProfile
    
    smartVolumeProfileBuilder4.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder4.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId107, "Extrude Dialog")
    
    section4.DistanceTolerance = 0.01
    
    section4.ChainingTolerance = 0.0094999999999999998
    
    section4.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId108 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions2 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions2.SetSelectedFromInactive(False)
    
    curves2 = [NXOpen.ICurve.Null] * 4 
    curves2[0] = line5
    curves2[1] = line6
    curves2[2] = line7
    curves2[3] = line8
    seedPoint2 = NXOpen.Point3d(68.608040999999986, 68.608041, 10.0)
    regionBoundaryRule2 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch4, curves2, seedPoint2, 0.01, selectionIntentRuleOptions2)
    
    selectionIntentRuleOptions2.Dispose()
    section4.AllowSelfIntersection(True)
    
    section4.AllowDegenerateCurves(False)
    
    rules2 = [None] * 1 
    rules2[0] = regionBoundaryRule2
    helpPoint2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section4.AddToSection(rules2, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint2, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId108, None)
    
    markId109 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId110 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId110, None)
    
    direction8 = workPart.Directions.CreateDirection(sketch4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder4.Direction = direction8
    
    targetBodies14 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(2)")
    targetBodies14[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies14)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies15 = [NXOpen.Body.Null] * 1 
    targetBodies15[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies15)
    
    theSession.DeleteUndoMark(markId109, None)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies16 = [NXOpen.Body.Null] * 1 
    targetBodies16[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies16)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Intersect
    
    targetBodies17 = [NXOpen.Body.Null] * 1 
    targetBodies17[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies17)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Intersect
    
    targetBodies18 = [NXOpen.Body.Null] * 1 
    targetBodies18[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies18)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies19 = [NXOpen.Body.Null] * 1 
    targetBodies19[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies19)
    
    scaleAboutPoint52 = NXOpen.Point3d(-52.550039832010981, 2.4200676238426806, 0.0)
    viewCenter52 = NXOpen.Point3d(52.550039832011279, -2.4200676238425629, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint52, viewCenter52)
    
    scaleAboutPoint53 = NXOpen.Point3d(-65.687549790013762, 3.0250845298033209, 0.0)
    viewCenter53 = NXOpen.Point3d(65.68754979001406, -3.0250845298032174, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint53, viewCenter53)
    
    scaleAboutPoint54 = NXOpen.Point3d(-82.325514703931717, 3.9974331286686762, 0.0)
    viewCenter54 = NXOpen.Point3d(82.325514703932043, -3.9974331286685656, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint54, viewCenter54)
    
    scaleAboutPoint55 = NXOpen.Point3d(-123.1641558562759, 23.633472889088129, 0.0)
    viewCenter55 = NXOpen.Point3d(123.16415585627618, -23.633472889088011, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint55, viewCenter55)
    
    scaleAboutPoint56 = NXOpen.Point3d(-98.531324685020707, 18.906778311270504, 0.0)
    viewCenter56 = NXOpen.Point3d(98.531324685020962, -18.906778311270394, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint56, viewCenter56)
    
    scaleAboutPoint57 = NXOpen.Point3d(-78.825059748016528, 15.125422649016416, 0.0)
    viewCenter57 = NXOpen.Point3d(78.825059748016798, -15.125422649016299, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint57, viewCenter57)
    
    scaleAboutPoint58 = NXOpen.Point3d(-63.060047798413201, 12.100338119213145, 0.0)
    viewCenter58 = NXOpen.Point3d(63.060047798413457, -12.100338119213028, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint58, viewCenter58)
    
    extrudeBuilder4.Destroy()
    
    section4.Destroy()
    
    workPart.Expressions.Delete(expression18)
    
    theSession.UndoToMark(markId107, None)
    
    theSession.DeleteUndoMark(markId107, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId111 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder5 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section5 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder5.Section = section5
    
    extrudeBuilder5.AllowSelfIntersectingSection(True)
    
    expression19 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder5.DistanceTolerance = 0.01
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies20 = [NXOpen.Body.Null] * 1 
    targetBodies20[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies20)
    
    extrudeBuilder5.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies21 = [NXOpen.Body.Null] * 1 
    targetBodies21[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies21)
    
    extrudeBuilder5.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder5.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder5 = extrudeBuilder5.SmartVolumeProfile
    
    smartVolumeProfileBuilder5.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder5.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId111, "Extrude Dialog")
    
    section5.DistanceTolerance = 0.01
    
    section5.ChainingTolerance = 0.0094999999999999998
    
    section5.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder5.Destroy()
    
    section5.Destroy()
    
    workPart.Expressions.Delete(expression19)
    
    theSession.UndoToMark(markId111, None)
    
    theSession.DeleteUndoMark(markId111, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId112 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder6 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section6 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder6.Section = section6
    
    extrudeBuilder6.AllowSelfIntersectingSection(True)
    
    expression20 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder6.DistanceTolerance = 0.01
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies22 = [NXOpen.Body.Null] * 1 
    targetBodies22[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies22)
    
    extrudeBuilder6.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies23 = [NXOpen.Body.Null] * 1 
    targetBodies23[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies23)
    
    extrudeBuilder6.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder6.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder6 = extrudeBuilder6.SmartVolumeProfile
    
    smartVolumeProfileBuilder6.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder6.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId112, "Extrude Dialog")
    
    section6.DistanceTolerance = 0.01
    
    section6.ChainingTolerance = 0.0094999999999999998
    
    section6.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder6.Destroy()
    
    section6.Destroy()
    
    workPart.Expressions.Delete(expression20)
    
    theSession.UndoToMark(markId112, None)
    
    theSession.DeleteUndoMark(markId112, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId113 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder7 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section7 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder7.Section = section7
    
    extrudeBuilder7.AllowSelfIntersectingSection(True)
    
    expression21 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder7.DistanceTolerance = 0.01
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies24 = [NXOpen.Body.Null] * 1 
    targetBodies24[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies24)
    
    extrudeBuilder7.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies25 = [NXOpen.Body.Null] * 1 
    targetBodies25[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies25)
    
    extrudeBuilder7.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder7.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder7 = extrudeBuilder7.SmartVolumeProfile
    
    smartVolumeProfileBuilder7.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder7.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId113, "Extrude Dialog")
    
    section7.DistanceTolerance = 0.01
    
    section7.ChainingTolerance = 0.0094999999999999998
    
    section7.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder7.Destroy()
    
    section7.Destroy()
    
    workPart.Expressions.Delete(expression21)
    
    theSession.UndoToMark(markId113, None)
    
    theSession.DeleteUndoMark(markId113, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId114 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder8 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section8 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder8.Section = section8
    
    extrudeBuilder8.AllowSelfIntersectingSection(True)
    
    expression22 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder8.DistanceTolerance = 0.01
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies26 = [NXOpen.Body.Null] * 1 
    targetBodies26[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies26)
    
    extrudeBuilder8.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies27 = [NXOpen.Body.Null] * 1 
    targetBodies27[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies27)
    
    extrudeBuilder8.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder8.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder8 = extrudeBuilder8.SmartVolumeProfile
    
    smartVolumeProfileBuilder8.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder8.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId114, "Extrude Dialog")
    
    section8.DistanceTolerance = 0.01
    
    section8.ChainingTolerance = 0.0094999999999999998
    
    section8.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId115 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions3 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions3.SetSelectedFromInactive(False)
    
    curves3 = [NXOpen.ICurve.Null] * 4 
    curves3[0] = line5
    curves3[1] = line6
    curves3[2] = line7
    curves3[3] = line8
    seedPoint3 = NXOpen.Point3d(68.608040999999986, 68.608041, 10.0)
    regionBoundaryRule3 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch4, curves3, seedPoint3, 0.01, selectionIntentRuleOptions3)
    
    selectionIntentRuleOptions3.Dispose()
    section8.AllowSelfIntersection(True)
    
    section8.AllowDegenerateCurves(False)
    
    rules3 = [None] * 1 
    rules3[0] = regionBoundaryRule3
    helpPoint3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section8.AddToSection(rules3, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint3, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId115, None)
    
    markId116 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId117 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId117, None)
    
    direction9 = workPart.Directions.CreateDirection(sketch4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder8.Direction = direction9
    
    targetBodies28 = [NXOpen.Body.Null] * 1 
    targetBodies28[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies28)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies29 = [NXOpen.Body.Null] * 1 
    targetBodies29[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies29)
    
    theSession.DeleteUndoMark(markId116, None)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies30 = [NXOpen.Body.Null] * 1 
    targetBodies30[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies30)
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("4")
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies31 = [NXOpen.Body.Null] * 1 
    targetBodies31[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies31)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Intersect
    
    targetBodies32 = [NXOpen.Body.Null] * 1 
    targetBodies32[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies32)
    
    extrudeBuilder8.Limits.StartExtend.Value.SetFormula("-20")
    
    extrudeBuilder8.Limits.StartExtend.Value.SetFormula("4")
    
    markId118 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId118, None)
    
    markId119 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder8.ParentFeatureInternal = False
    
    try:
        # Solid tool body is required for current Boolean option.
        # Change the body type to solid or change the Boolean option to None.
        #
        feature7 = extrudeBuilder8.CommitFeature()
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(671468)
        
    theSession.UndoToMarkWithStatus(markId119, None)
    
    theSession.DeleteUndoMark(markId119, None)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies33 = [NXOpen.Body.Null] * 1 
    targetBodies33[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies33)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies34 = [NXOpen.Body.Null] * 1 
    targetBodies34[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies34)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies35 = [NXOpen.Body.Null] * 1 
    targetBodies35[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies35)
    
    targetBodies36 = []
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies36)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies37 = [NXOpen.Body.Null] * 1 
    targetBodies37[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies37)
    
    targetBodies38 = []
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies38)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Intersect
    
    targetBodies39 = [NXOpen.Body.Null] * 1 
    targetBodies39[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies39)
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("-9")
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("-9")
    
    extrudeBuilder8.Limits.StartExtend.Value.SetFormula("-4")
    
    extrudeBuilder8.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("-4")
    
    markId120 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId120, None)
    
    markId121 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder8.ParentFeatureInternal = False
    
    feature8 = extrudeBuilder8.CommitFeature()
    
    theSession.DeleteUndoMark(markId121, None)
    
    theSession.SetUndoMarkName(markId114, "Extrude")
    
    expression23 = extrudeBuilder8.Limits.StartExtend.Value
    expression24 = extrudeBuilder8.Limits.EndExtend.Value
    extrudeBuilder8.Destroy()
    
    workPart.Expressions.Delete(expression22)
    
    scaleAboutPoint59 = NXOpen.Point3d(34.074552143704189, -13.663010356322832, 0.0)
    viewCenter59 = NXOpen.Point3d(-34.074552143703926, 13.663010356322944, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint59, viewCenter59)
    
    scaleAboutPoint60 = NXOpen.Point3d(27.259641714963358, -11.37293493627519, 0.0)
    viewCenter60 = NXOpen.Point3d(-27.259641714963124, 11.372934936275302, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint60, viewCenter60)
    
    scaleAboutPoint61 = NXOpen.Point3d(21.736909107775972, -9.6647820625778103, 0.0)
    viewCenter61 = NXOpen.Point3d(-21.736909107775745, 9.6647820625779239, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint61, viewCenter61)
    
    scaleAboutPoint62 = NXOpen.Point3d(26.905620393989786, -12.257988238709059, 0.0)
    viewCenter62 = NXOpen.Point3d(-26.905620393989562, 12.257988238709171, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint62, viewCenter62)
    
    scaleAboutPoint63 = NXOpen.Point3d(33.189498841270272, -15.543748623994794, 0.0)
    viewCenter63 = NXOpen.Point3d(-33.189498841270044, 15.543748623994908, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint63, viewCenter63)
    
    scaleAboutPoint64 = NXOpen.Point3d(41.348583973082512, -19.429685779993509, 0.0)
    viewCenter64 = NXOpen.Point3d(-41.348583973082306, 19.429685779993626, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint64, viewCenter64)
    
    scaleAboutPoint65 = NXOpen.Point3d(38.375358035218703, -32.238757989046199, 0.0)
    viewCenter65 = NXOpen.Point3d(-38.375358035218497, 32.23875798904632, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint65, viewCenter65)
    
    scaleAboutPoint66 = NXOpen.Point3d(42.135105950831338, -43.971764415354613, 0.0)
    viewCenter66 = NXOpen.Point3d(-42.135105950831175, 43.971764415354684, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint66, viewCenter66)
    
    scaleAboutPoint67 = NXOpen.Point3d(44.025783781958388, -64.418094674828524, 0.0)
    viewCenter67 = NXOpen.Point3d(-44.025783781958161, 64.418094674828566, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint67, viewCenter67)
    
    scaleAboutPoint68 = NXOpen.Point3d(35.220627025566749, -51.966630672691835, 0.0)
    viewCenter68 = NXOpen.Point3d(-35.22062702556655, 51.966630672691906, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint68, viewCenter68)
    
    scaleAboutPoint69 = NXOpen.Point3d(28.176501620453415, -41.746166511285082, 0.0)
    viewCenter69 = NXOpen.Point3d(-28.176501620453205, 41.746166511285139, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint69, viewCenter69)
    
    scaleAboutPoint70 = NXOpen.Point3d(22.817780453373324, -33.811801944543944, 0.0)
    viewCenter70 = NXOpen.Point3d(-22.817780453373135, 33.811801944544001, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint70, viewCenter70)
    
    scaleAboutPoint71 = NXOpen.Point3d(19.249909327936791, -23.066701694682724, 0.0)
    viewCenter71 = NXOpen.Point3d(-19.249909327936592, 23.066701694682781, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint71, viewCenter71)
    
    scaleAboutPoint72 = NXOpen.Point3d(24.062386659920961, -28.8333771183534, 0.0)
    viewCenter72 = NXOpen.Point3d(-24.062386659920783, 28.833377118353461, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint72, viewCenter72)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled1, undoUnavailable1 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId122 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder9 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section9 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder9.Section = section9
    
    extrudeBuilder9.AllowSelfIntersectingSection(True)
    
    expression25 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder9.DistanceTolerance = 0.01
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies40 = [NXOpen.Body.Null] * 1 
    targetBodies40[0] = NXOpen.Body.Null
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies40)
    
    extrudeBuilder9.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder9.Limits.EndExtend.Value.SetFormula("-4")
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Intersect
    
    targetBodies41 = [NXOpen.Body.Null] * 1 
    targetBodies41[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies41)
    
    extrudeBuilder9.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder9.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder9.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder9.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder9 = extrudeBuilder9.SmartVolumeProfile
    
    smartVolumeProfileBuilder9.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder9.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId122, "Extrude Dialog")
    
    section9.DistanceTolerance = 0.01
    
    section9.ChainingTolerance = 0.0094999999999999998
    
    section9.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId123 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId124 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions4 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions4.SetSelectedFromInactive(False)
    
    features1 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature1 = feature6
    features1[0] = sketchFeature1
    curveFeatureRule1 = workPart.ScRuleFactory.CreateRuleCurveFeature(features1, NXOpen.DisplayableObject.Null, selectionIntentRuleOptions4)
    
    selectionIntentRuleOptions4.Dispose()
    section9.AllowSelfIntersection(True)
    
    section9.AllowDegenerateCurves(False)
    
    rules4 = [None] * 1 
    rules4[0] = curveFeatureRule1
    helpPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section9.AddToSection(rules4, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint4, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId124, None)
    
    direction10 = workPart.Directions.CreateDirection(sketch4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder9.Direction = direction10
    
    theSession.DeleteUndoMark(markId123, None)
    
    extrudeBuilder9.Limits.EndExtend.Value.SetFormula("4")
    
    extrudeBuilder9.Destroy()
    
    section9.Destroy()
    
    workPart.Expressions.Delete(expression25)
    
    theSession.UndoToMark(markId122, None)
    
    theSession.DeleteUndoMark(markId122, None)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled2, undoUnavailable2 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled3, undoUnavailable3 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled4, undoUnavailable4 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId125 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId126 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId127 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder5 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin30 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal5 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane10 = workPart.Planes.CreatePlane(origin30, normal5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.PlaneReference = plane10
    
    expression26 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression27 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder5 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder5 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder5.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId127, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder5.UseWorkPartOrigin = False
    
    coordinates10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point18 = workPart.Points.CreatePoint(coordinates10)
    
    origin31 = NXOpen.Point3d(67.237728573197259, 67.237728573197259, 0.0)
    matrix5 = NXOpen.Matrix3x3()
    
    matrix5.Xx = 1.0
    matrix5.Xy = 0.0
    matrix5.Xz = 0.0
    matrix5.Yx = 0.0
    matrix5.Yy = 1.0
    matrix5.Yz = 0.0
    matrix5.Zx = 0.0
    matrix5.Zy = 0.0
    matrix5.Zz = 1.0
    plane11 = workPart.Planes.CreateFixedTypePlane(origin31, matrix5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point19 = workPart.Points.CreatePoint(coordinates11)
    
    origin32 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector5 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction11 = workPart.Directions.CreateDirection(origin32, vector5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin33 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector6 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction12 = workPart.Directions.CreateDirection(origin33, vector6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin34 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix6 = NXOpen.Matrix3x3()
    
    matrix6.Xx = 1.0
    matrix6.Xy = 0.0
    matrix6.Xz = 0.0
    matrix6.Yx = 0.0
    matrix6.Yy = 1.0
    matrix6.Yz = 0.0
    matrix6.Zx = 0.0
    matrix6.Zy = 0.0
    matrix6.Zz = 1.0
    plane12 = workPart.Planes.CreateFixedTypePlane(origin34, matrix6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform5 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane12, direction12, point19, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem5 = workPart.CoordinateSystems.CreateCoordinateSystem(xform5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder5.CoordinateSystem = cartesianCoordinateSystem5
    
    simpleSketchInPlaceBuilder5.HorizontalReference.Value = datumAxis1
    
    point20 = simpleSketchInPlaceBuilder5.SketchOrigin
    
    simpleSketchInPlaceBuilder5.SketchOrigin = point20
    
    markId128 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId128, None)
    
    markId129 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject41 = simpleSketchInPlaceBuilder5.Commit()
    
    sketch5 = nXObject41
    feature9 = sketch5.Feature
    
    markId130 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs5 = theSession.UpdateManager.DoUpdate(markId130)
    
    sketch5.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder20 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject42 = sketchFindMovableObjectsBuilder20.Commit()
    
    sketchFindMovableObjectsBuilder20.Destroy()
    
    theSession.DeleteUndoMark(markId129, None)
    
    theSession.SetUndoMarkName(markId127, "Create Sketch")
    
    sketchInPlaceBuilder5.Destroy()
    
    sketchAlongPathBuilder5.Destroy()
    
    simpleSketchInPlaceBuilder5.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression27)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression26)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane10.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId126, None, True)
    
    markId131 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_002")
    
    scaleAboutPoint73 = NXOpen.Point3d(44.079803148561986, 26.880036821966211, 0.0)
    viewCenter73 = NXOpen.Point3d(-44.079803148561808, -26.88003682196614, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint73, viewCenter73)
    
    scaleAboutPoint74 = NXOpen.Point3d(36.923317460913125, 21.504029457572987, 0.0)
    viewCenter74 = NXOpen.Point3d(-36.923317460912962, -21.504029457572916, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint74, viewCenter74)
    
    scaleAboutPoint75 = NXOpen.Point3d(30.755602259577056, 16.981960240449926, 0.0)
    viewCenter75 = NXOpen.Point3d(-30.755602259576907, -16.981960240449851, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint75, viewCenter75)
    
    scaleAboutPoint76 = NXOpen.Point3d(24.692987137905067, 13.497062862116564, 0.0)
    viewCenter76 = NXOpen.Point3d(-24.692987137904904, -13.49706286211649, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint76, viewCenter76)
    
    scaleAboutPoint77 = NXOpen.Point3d(20.74564940905001, 10.939258818082671, 0.0)
    viewCenter77 = NXOpen.Point3d(-20.745649409049836, -10.93925881808261, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint77, viewCenter77)
    
    scaleAboutPoint78 = NXOpen.Point3d(25.932061761312475, 13.674073522603329, 0.0)
    viewCenter78 = NXOpen.Point3d(-25.932061761312312, -13.674073522603269, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint78, viewCenter78)
    
    scaleAboutPoint79 = NXOpen.Point3d(32.415077201640564, 17.09259190325416, 0.0)
    viewCenter79 = NXOpen.Point3d(-32.415077201640393, -17.092591903254082, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint79, viewCenter79)
    
    scaleAboutPoint80 = NXOpen.Point3d(43.284638072156532, 26.344164705258208, 0.0)
    viewCenter80 = NXOpen.Point3d(-43.28463807215639, -26.344164705258137, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint80, viewCenter80)
    
    scaleAboutPoint81 = NXOpen.Point3d(55.142969428985317, 33.967377720362428, 0.0)
    viewCenter81 = NXOpen.Point3d(-55.142969428985197, -33.967377720362357, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint81, viewCenter81)
    
    scaleAboutPoint82 = NXOpen.Point3d(71.305563916791343, 43.755686948940159, 0.0)
    viewCenter82 = NXOpen.Point3d(-71.305563916791243, -43.755686948940067, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint82, viewCenter82)
    
    scaleAboutPoint83 = NXOpen.Point3d(90.482439061079901, 55.774996018247769, 0.0)
    viewCenter83 = NXOpen.Point3d(-90.482439061079717, -55.774996018247677, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint83, viewCenter83)
    
    scaleAboutPoint84 = NXOpen.Point3d(115.12877507398599, 71.069229187900461, 0.0)
    viewCenter84 = NXOpen.Point3d(-115.12877507398576, -71.069229187900348, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint84, viewCenter84)
    
    scaleAboutPoint85 = NXOpen.Point3d(207.63694038270199, 145.81008719964134, 0.0)
    viewCenter85 = NXOpen.Point3d(-207.63694038270177, -145.8100871996412, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint85, viewCenter85)
    
    scaleAboutPoint86 = NXOpen.Point3d(167.12241542997967, 117.9985539248038, 0.0)
    viewCenter86 = NXOpen.Point3d(-167.12241542997944, -117.99855392480366, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint86, viewCenter86)
    
    scaleAboutPoint87 = NXOpen.Point3d(133.69793234398372, 94.398843139843038, 0.0)
    viewCenter87 = NXOpen.Point3d(-133.69793234398355, -94.398843139842924, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint87, viewCenter87)
    
    scaleAboutPoint88 = NXOpen.Point3d(106.95834587518698, 75.519074511874464, 0.0)
    viewCenter88 = NXOpen.Point3d(-106.95834587518688, -75.519074511874322, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint88, viewCenter88)
    
    scaleAboutPoint89 = NXOpen.Point3d(85.739538673281203, 59.723811716973152, 0.0)
    viewCenter89 = NXOpen.Point3d(-85.739538673281075, -59.723811716972989, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint89, viewCenter89)
    
    scaleAboutPoint90 = NXOpen.Point3d(106.95834587518698, 73.790454780558321, 0.0)
    viewCenter90 = NXOpen.Point3d(-106.95834587518691, -73.79045478055815, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint90, viewCenter90)
    
    scaleAboutPoint91 = NXOpen.Point3d(133.42783551096556, 91.697874809661627, 0.0)
    viewCenter91 = NXOpen.Point3d(-133.42783551096551, -91.697874809661442, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint91, viewCenter91)
    
    scaleAboutPoint92 = NXOpen.Point3d(166.44717334743416, 114.62234351207698, 0.0)
    viewCenter92 = NXOpen.Point3d(-166.44717334743416, -114.6223435120768, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint92, viewCenter92)
    
    scaleAboutPoint93 = NXOpen.Point3d(208.05896668429264, 142.85590308850539, 0.0)
    viewCenter93 = NXOpen.Point3d(-208.05896668429278, -142.85590308850516, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint93, viewCenter93)
    
    scaleAboutPoint94 = NXOpen.Point3d(260.0737083553658, 178.56987886063169, 0.0)
    viewCenter94 = NXOpen.Point3d(-260.07370835536591, -178.56987886063155, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint94, viewCenter94)
    
    scaleAboutPoint95 = NXOpen.Point3d(325.09213544420743, 239.69775098168239, 0.0)
    viewCenter95 = NXOpen.Point3d(-325.09213544420743, -239.69775098168228, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint95, viewCenter95)
    
    scaleAboutPoint96 = NXOpen.Point3d(406.36516930525914, 300.44645884739759, 0.0)
    viewCenter96 = NXOpen.Point3d(-406.36516930525914, -300.44645884739748, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint96, viewCenter96)
    
    scaleAboutPoint97 = NXOpen.Point3d(507.95646163157392, 377.61874885998344, 0.0)
    viewCenter97 = NXOpen.Point3d(-507.95646163157375, -377.61874885998338, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint97, viewCenter97)
    
    scaleAboutPoint98 = NXOpen.Point3d(636.2334991024278, 475.88720226386056, 0.0)
    viewCenter98 = NXOpen.Point3d(-636.23349910242757, -475.88720226386033, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint98, viewCenter98)
    
    scaleAboutPoint99 = NXOpen.Point3d(837.1493409242471, 619.00754151033277, 0.0)
    viewCenter99 = NXOpen.Point3d(-837.14934092424676, -619.00754151033243, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint99, viewCenter99)
    
    scaleAboutPoint100 = NXOpen.Point3d(674.87116099123932, 495.20603320826609, 0.0)
    viewCenter100 = NXOpen.Point3d(-674.87116099123864, -495.20603320826609, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint100, viewCenter100)
    
    scaleAboutPoint101 = NXOpen.Point3d(540.92726644335994, 396.16482656661287, 0.0)
    viewCenter101 = NXOpen.Point3d(-540.92726644335937, -396.16482656661287, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint101, viewCenter101)
    
    scaleAboutPoint102 = NXOpen.Point3d(434.39035339527715, 316.93186125329032, 0.0)
    viewCenter102 = NXOpen.Point3d(-434.39035339527669, -316.93186125329032, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint102, viewCenter102)
    
    scaleAboutPoint103 = NXOpen.Point3d(350.14994710116468, 253.54548900263228, 0.0)
    viewCenter103 = NXOpen.Point3d(-350.14994710116434, -253.54548900263228, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint103, viewCenter103)
    
    scaleAboutPoint104 = NXOpen.Point3d(280.11995768093192, 202.8363912021058, 0.0)
    viewCenter104 = NXOpen.Point3d(-280.11995768093146, -202.83639120210583, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint104, viewCenter104)
    
    scaleAboutPoint105 = NXOpen.Point3d(224.09596614474549, 161.84708666009382, 0.0)
    viewCenter105 = NXOpen.Point3d(-224.09596614474506, -161.84708666009382, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint105, viewCenter105)
    
    scaleAboutPoint106 = NXOpen.Point3d(178.93915187452376, 129.47766932807505, 0.0)
    viewCenter106 = NXOpen.Point3d(-178.93915187452328, -129.47766932807505, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint106, viewCenter106)
    
    scaleAboutPoint107 = NXOpen.Point3d(142.61112783358283, 103.31203862944196, 0.0)
    viewCenter107 = NXOpen.Point3d(-142.61112783358243, -103.31203862944189, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint107, viewCenter107)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId132 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId133 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId133, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint9 = NXOpen.Point3d(8.0, 6.0, 0.0)
    endPoint9 = NXOpen.Point3d(107.0, 6.0, 0.0)
    line9 = workPart.Curves.CreateLine(startPoint9, endPoint9)
    
    startPoint10 = NXOpen.Point3d(107.0, 6.0, 0.0)
    endPoint10 = NXOpen.Point3d(107.0, 107.0, 0.0)
    line10 = workPart.Curves.CreateLine(startPoint10, endPoint10)
    
    startPoint11 = NXOpen.Point3d(107.0, 107.0, 0.0)
    endPoint11 = NXOpen.Point3d(8.0, 107.0, 0.0)
    line11 = workPart.Curves.CreateLine(startPoint11, endPoint11)
    
    startPoint12 = NXOpen.Point3d(8.0, 107.0, 0.0)
    endPoint12 = NXOpen.Point3d(8.0, 6.0, 0.0)
    line12 = workPart.Curves.CreateLine(startPoint12, endPoint12)
    
    theSession.ActiveSketch.AddGeometry(line9, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line10, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line11, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line12, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_9.Geometry = line9
    conGeom1_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_9.SplineDefiningPointIndex = 0
    conGeom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_9.Geometry = line10
    conGeom2_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint9 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_9, conGeom2_9)
    
    conGeom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_10.Geometry = line10
    conGeom1_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_10.SplineDefiningPointIndex = 0
    conGeom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_10.Geometry = line11
    conGeom2_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint10 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_10, conGeom2_10)
    
    conGeom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_11.Geometry = line11
    conGeom1_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_11.SplineDefiningPointIndex = 0
    conGeom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_11.Geometry = line12
    conGeom2_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint11 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_11, conGeom2_11)
    
    conGeom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_12.Geometry = line12
    conGeom1_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_12.SplineDefiningPointIndex = 0
    conGeom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_12.Geometry = line9
    conGeom2_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint12 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_12, conGeom2_12)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms5 = [NXOpen.SmartObject.Null] * 4 
    geoms5[0] = line9
    geoms5[1] = line10
    geoms5[2] = line11
    geoms5[3] = line12
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms5)
    
    geoms6 = [NXOpen.SmartObject.Null] * 4 
    geoms6[0] = line9
    geoms6[1] = line10
    geoms6[2] = line11
    geoms6[3] = line12
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms6)
    
    objects6 = [NXOpen.NXObject.Null] * 4 
    objects6[0] = sketchGeometricConstraint9
    objects6[1] = sketchGeometricConstraint10
    objects6[2] = sketchGeometricConstraint11
    objects6[3] = sketchGeometricConstraint12
    errorList3 = theSession.ActiveSketch.DeleteObjects(objects6)
    
    errorList3.Dispose()
    sketchFindMovableObjectsBuilder21 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject43 = sketchFindMovableObjectsBuilder21.Commit()
    
    sketchFindMovableObjectsBuilder21.Destroy()
    
    markId134 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder8 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects17 = [None] * 1 
    dragobjects17[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects17[0].Geometry = line11
    dragobjects17[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects17[0].PointIndex = 0
    sketchDragGeometryBuilder8.SetDragGeometry(dragobjects17)
    
    sketchDragGeometryBuilder8.SplineLinearScale = False
    
    foundrelations25 = sketchDragGeometryBuilder8.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects18 = [None] * 1 
    dragobjects18[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects18[0].Geometry = line11
    dragobjects18[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects18[0].PointIndex = 0
    sketchDragGeometryBuilder8.SetDragGeometry(dragobjects18)
    
    foundrelations26 = sketchDragGeometryBuilder8.FindRelations()
    
    sketchDragGeometryBuilder8.Destroy()
    
    markId135 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences7 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences7 = dimensionPreferences7.GetNarrowDimensionPreferences()
    
    option7 = narrowDimensionPreferences7.DimensionDisplayOption
    
    sketchLinearDimensionBuilder7 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder7 = sketchLinearDimensionBuilder7.Driving
    
    drivingValueBuilder7.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject13 = sketchLinearDimensionBuilder7.FirstAssociativity
    
    selectNXObject14 = sketchLinearDimensionBuilder7.SecondAssociativity
    
    point1_33 = NXOpen.Point3d(107.0, 107.0, 0.0)
    point2_33 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject13.SetValue(NXOpen.InferSnapType.SnapType.Start, line11, NXOpen.View.Null, point1_33, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_33)
    
    point1_34 = NXOpen.Point3d(8.0, 107.0, 0.0)
    point2_34 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject14.SetValue(NXOpen.InferSnapType.SnapType.End, line11, NXOpen.View.Null, point1_34, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_34)
    
    dimensionMeasurementBuilder7 = sketchLinearDimensionBuilder7.Measurement
    
    dimensionMeasurementBuilder7.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder7 = sketchLinearDimensionBuilder7.Origin
    
    origin36 = NXOpen.Point3d(57.5, 114.35003665284033, 0.0)
    originBuilder7.OriginPoint = origin36
    
    originBuilder7.SetInferRelativeToGeometry(True)
    
    nXObject44 = sketchLinearDimensionBuilder7.Commit()
    
    horizontalDimension3 = nXObject44
    horizontalDimension3.IsOriginCentered = True
    
    sketchLinearDimensionBuilder7.Destroy()
    
    narrowDimensionPreferences7.Dispose()
    dimensionPreferences7.Dispose()
    sketchFindMovableObjectsBuilder22 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject45 = sketchFindMovableObjectsBuilder22.Commit()
    
    sketchFindMovableObjectsBuilder22.Destroy()
    
    markId136 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId137 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder7 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension3)
    
    selectNXObjectList15 = sketchEditDimensionValueBuilder7.ExtraGeometries
    
    foundrelations27 = sketchEditDimensionValueBuilder7.FindRelations()
    
    sketchHelpedDimensionalConstraint7 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line7] StartVertex] [[Curve Line7] EndVertex]")
    sketchHelpedDimensionalConstraint7.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId137, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId137, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint7.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId138 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId138, None)
    
    markId139 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder7.DimValue = 117.0
    
    theSession.ActiveSketch.Scale(1.1818181818181819)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin37 = NXOpen.Point3d(67.954545454545453, 135.1409524079022, 0.0)
    horizontalDimension3.AnnotationOrigin = origin37
    
    sketchEditDimensionValueBuilder7.RestoreOperation()
    
    sketchEditDimensionValueBuilder7.LoadExtraGeometry()
    
    selectNXObjectList16 = sketchEditDimensionValueBuilder7.ExtraGeometries
    
    foundrelations28 = sketchEditDimensionValueBuilder7.FindRelations()
    
    nXObject46 = sketchEditDimensionValueBuilder7.Commit()
    
    theSession.SetUndoMarkName(markId139, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId139, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId137, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId140 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    selectNXObjectList17 = sketchEditDimensionValueBuilder7.ExtraGeometries
    
    objects7 = [NXOpen.NXObject.Null] * 1 
    objects7[0] = line12
    selectNXObjectList17.SetArray(objects7)
    
    sketchEditDimensionValueBuilder7.RestoreOperation()
    
    sketchEditDimensionValueBuilder7.LoadExtraGeometry()
    
    selectNXObjectList18 = sketchEditDimensionValueBuilder7.ExtraGeometries
    
    theSession.ActiveSketch.Update()
    
    theSession.SetUndoMarkName(markId140, "Edit Dimension Value - Selection")
    
    theSession.SetUndoMarkVisibility(markId140, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId137, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId141 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    nXObject47 = sketchEditDimensionValueBuilder7.Commit()
    
    theSession.SetUndoMarkName(markId141, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId141, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId137, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId142 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId143 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint7.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId143, None)
    
    theSession.SetUndoMarkName(markId137, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder7.Destroy()
    
    theSession.DeleteUndoMark(markId142, None)
    
    theSession.SetUndoMarkVisibility(markId137, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId141, None)
    
    theSession.DeleteUndoMark(markId140, None)
    
    theSession.DeleteUndoMark(markId139, None)
    
    theSession.DeleteUndoMark(markId137, None)
    
    sketchFindMovableObjectsBuilder23 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject48 = sketchFindMovableObjectsBuilder23.Commit()
    
    sketchFindMovableObjectsBuilder23.Destroy()
    
    markId144 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder9 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects19 = [None] * 1 
    dragobjects19[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects19[0].Geometry = line12
    dragobjects19[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects19[0].PointIndex = 0
    sketchDragGeometryBuilder9.SetDragGeometry(dragobjects19)
    
    sketchDragGeometryBuilder9.SplineLinearScale = False
    
    foundrelations29 = sketchDragGeometryBuilder9.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects20 = [None] * 1 
    dragobjects20[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects20[0].Geometry = line12
    dragobjects20[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects20[0].PointIndex = 0
    sketchDragGeometryBuilder9.SetDragGeometry(dragobjects20)
    
    foundrelations30 = sketchDragGeometryBuilder9.FindRelations()
    
    sketchDragGeometryBuilder9.Destroy()
    
    markId145 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences8 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences8 = dimensionPreferences8.GetNarrowDimensionPreferences()
    
    option8 = narrowDimensionPreferences8.DimensionDisplayOption
    
    sketchLinearDimensionBuilder8 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder8 = sketchLinearDimensionBuilder8.Driving
    
    drivingValueBuilder8.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject15 = sketchLinearDimensionBuilder8.FirstAssociativity
    
    selectNXObject16 = sketchLinearDimensionBuilder8.SecondAssociativity
    
    point1_37 = NXOpen.Point3d(9.454545454545455, 126.45454545454547, 0.0)
    point2_37 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject15.SetValue(NXOpen.InferSnapType.SnapType.Start, line12, NXOpen.View.Null, point1_37, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_37)
    
    point1_38 = NXOpen.Point3d(9.454545454545455, 7.0909090909090935, 0.0)
    point2_38 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject16.SetValue(NXOpen.InferSnapType.SnapType.End, line12, NXOpen.View.Null, point1_38, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_38)
    
    dimensionMeasurementBuilder8 = sketchLinearDimensionBuilder8.Measurement
    
    dimensionMeasurementBuilder8.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder8 = sketchLinearDimensionBuilder8.Origin
    
    origin39 = NXOpen.Point3d(0.76813850118870342, 66.77272727272728, 0.0)
    originBuilder8.OriginPoint = origin39
    
    originBuilder8.SetInferRelativeToGeometry(True)
    
    nXObject49 = sketchLinearDimensionBuilder8.Commit()
    
    verticalDimension3 = nXObject49
    verticalDimension3.IsOriginCentered = True
    
    sketchLinearDimensionBuilder8.Destroy()
    
    narrowDimensionPreferences8.Dispose()
    dimensionPreferences8.Dispose()
    sketchFindMovableObjectsBuilder24 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject50 = sketchFindMovableObjectsBuilder24.Commit()
    
    sketchFindMovableObjectsBuilder24.Destroy()
    
    markId146 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId147 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder8 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension3)
    
    selectNXObjectList19 = sketchEditDimensionValueBuilder8.ExtraGeometries
    
    foundrelations31 = sketchEditDimensionValueBuilder8.FindRelations()
    
    sketchHelpedDimensionalConstraint8 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line8] StartVertex] [[Curve Line8] EndVertex]")
    sketchHelpedDimensionalConstraint8.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId147, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId147, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint8.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId148 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId148, None)
    
    markId149 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder8.DimValue = 117.0
    
    nXObject51 = sketchEditDimensionValueBuilder8.Commit()
    
    theSession.SetUndoMarkName(markId149, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId149, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId147, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId150 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId151 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint8.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId151, None)
    
    theSession.SetUndoMarkName(markId147, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder8.Destroy()
    
    theSession.DeleteUndoMark(markId150, None)
    
    theSession.SetUndoMarkVisibility(markId147, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId149, None)
    
    theSession.DeleteUndoMark(markId147, None)
    
    sketchFindMovableObjectsBuilder25 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject52 = sketchFindMovableObjectsBuilder25.Commit()
    
    sketchFindMovableObjectsBuilder25.Destroy()
    
    markId152 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder10 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects21 = [None] * 1 
    dragobjects21[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects21[0].Geometry = line9
    dragobjects21[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects21[0].PointIndex = 0
    sketchDragGeometryBuilder10.SetDragGeometry(dragobjects21)
    
    sketchDragGeometryBuilder10.SplineLinearScale = False
    
    foundrelations32 = sketchDragGeometryBuilder10.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    sketchDragGeometryBuilder10.Destroy()
    
    markId153 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder11 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects22 = [None] * 1 
    dragobjects22[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects22[0].Geometry = line9
    dragobjects22[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects22[0].PointIndex = 0
    sketchDragGeometryBuilder11.SetDragGeometry(dragobjects22)
    
    sketchDragGeometryBuilder11.SplineLinearScale = False
    
    foundrelations33 = sketchDragGeometryBuilder11.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects23 = [None] * 1 
    dragobjects23[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects23[0].Geometry = line9
    dragobjects23[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects23[0].PointIndex = 0
    sketchDragGeometryBuilder11.SetDragGeometry(dragobjects23)
    
    foundrelations34 = sketchDragGeometryBuilder11.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects24 = [None] * 1 
    dragobjects24[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects24[0].Geometry = line9
    dragobjects24[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects24[0].PointIndex = 0
    sketchDragGeometryBuilder11.SetDragGeometry(dragobjects24)
    
    foundrelations35 = sketchDragGeometryBuilder11.FindRelations()
    
    sketchDragGeometryBuilder11.Destroy()
    
    markId154 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences9 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences9 = dimensionPreferences9.GetNarrowDimensionPreferences()
    
    option9 = narrowDimensionPreferences9.DimensionDisplayOption
    
    sketchLinearDimensionBuilder9 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder9 = sketchLinearDimensionBuilder9.Driving
    
    drivingValueBuilder9.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder9 = sketchLinearDimensionBuilder9.Measurement
    
    dimensionMeasurementBuilder9.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject17 = sketchLinearDimensionBuilder9.FirstAssociativity
    
    selectNXObject18 = sketchLinearDimensionBuilder9.SecondAssociativity
    
    point1_45 = NXOpen.Point3d(56.221349459951149, 9.454545454545455, 0.0)
    point2_45 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject17.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line9, NXOpen.View.Null, point1_45, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_45)
    
    point1_46 = NXOpen.Point3d(120.0, 0.0, 0.0)
    point2_46 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject18.SetValue(NXOpen.InferSnapType.SnapType.End, line1, NXOpen.View.Null, point1_46, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_46)
    
    originBuilder9 = sketchLinearDimensionBuilder9.Origin
    
    origin43 = NXOpen.Point3d(60.110743855412494, 4.7272727272727275, 0.0)
    originBuilder9.OriginPoint = origin43
    
    originBuilder9.SetInferRelativeToGeometry(True)
    
    nXObject53 = sketchLinearDimensionBuilder9.Commit()
    
    perpendicularDimension3 = nXObject53
    perpendicularDimension3.IsOriginCentered = True
    
    sketchLinearDimensionBuilder9.Destroy()
    
    narrowDimensionPreferences9.Dispose()
    dimensionPreferences9.Dispose()
    sketchFindMovableObjectsBuilder26 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject54 = sketchFindMovableObjectsBuilder26.Commit()
    
    sketchFindMovableObjectsBuilder26.Destroy()
    
    markId155 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId156 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder9 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension3)
    
    selectNXObjectList20 = sketchEditDimensionValueBuilder9.ExtraGeometries
    
    foundrelations36 = sketchEditDimensionValueBuilder9.FindRelations()
    
    sketchHelpedDimensionalConstraint9 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line5] [[WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line1] EndVertex]")
    sketchHelpedDimensionalConstraint9.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId156, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId156, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint9.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId157 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId157, None)
    
    markId158 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder9.DimValue = 1.5
    
    nXObject55 = sketchEditDimensionValueBuilder9.Commit()
    
    theSession.SetUndoMarkName(markId158, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId158, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId156, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId159 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId160 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint9.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId160, None)
    
    theSession.SetUndoMarkName(markId156, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder9.Destroy()
    
    theSession.DeleteUndoMark(markId159, None)
    
    theSession.SetUndoMarkVisibility(markId156, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId158, None)
    
    theSession.DeleteUndoMark(markId156, None)
    
    sketchFindMovableObjectsBuilder27 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject56 = sketchFindMovableObjectsBuilder27.Commit()
    
    sketchFindMovableObjectsBuilder27.Destroy()
    
    markId161 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder12 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects25 = [None] * 1 
    dragobjects25[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects25[0].Geometry = line12
    dragobjects25[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects25[0].PointIndex = 0
    sketchDragGeometryBuilder12.SetDragGeometry(dragobjects25)
    
    sketchDragGeometryBuilder12.SplineLinearScale = False
    
    foundrelations37 = sketchDragGeometryBuilder12.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects26 = [None] * 1 
    dragobjects26[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects26[0].Geometry = line12
    dragobjects26[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects26[0].PointIndex = 0
    sketchDragGeometryBuilder12.SetDragGeometry(dragobjects26)
    
    foundrelations38 = sketchDragGeometryBuilder12.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects27 = [None] * 1 
    dragobjects27[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects27[0].Geometry = line12
    dragobjects27[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects27[0].PointIndex = 0
    sketchDragGeometryBuilder12.SetDragGeometry(dragobjects27)
    
    foundrelations39 = sketchDragGeometryBuilder12.FindRelations()
    
    sketchDragGeometryBuilder12.Destroy()
    
    markId162 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences10 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences10 = dimensionPreferences10.GetNarrowDimensionPreferences()
    
    option10 = narrowDimensionPreferences10.DimensionDisplayOption
    
    sketchLinearDimensionBuilder10 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder10 = sketchLinearDimensionBuilder10.Driving
    
    drivingValueBuilder10.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder10 = sketchLinearDimensionBuilder10.Measurement
    
    dimensionMeasurementBuilder10.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject19 = sketchLinearDimensionBuilder10.FirstAssociativity
    
    selectNXObject20 = sketchLinearDimensionBuilder10.SecondAssociativity
    
    point1_49 = NXOpen.Point3d(9.454545454545455, 95.951980554393501, 0.0)
    point2_49 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject19.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line12, NXOpen.View.Null, point1_49, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_49)
    
    point1_50 = NXOpen.Point3d(0.0, 120.0, 0.0)
    point2_50 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject20.SetValue(NXOpen.InferSnapType.SnapType.Start, line4, NXOpen.View.Null, point1_50, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_50)
    
    originBuilder10 = sketchLinearDimensionBuilder10.Origin
    
    origin45 = NXOpen.Point3d(4.7272727272727275, 95.951980554393501, 0.0)
    originBuilder10.OriginPoint = origin45
    
    originBuilder10.SetInferRelativeToGeometry(True)
    
    nXObject57 = sketchLinearDimensionBuilder10.Commit()
    
    perpendicularDimension4 = nXObject57
    perpendicularDimension4.IsOriginCentered = True
    
    sketchLinearDimensionBuilder10.Destroy()
    
    narrowDimensionPreferences10.Dispose()
    dimensionPreferences10.Dispose()
    sketchFindMovableObjectsBuilder28 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject58 = sketchFindMovableObjectsBuilder28.Commit()
    
    sketchFindMovableObjectsBuilder28.Destroy()
    
    markId163 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId164 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder10 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension4)
    
    selectNXObjectList21 = sketchEditDimensionValueBuilder10.ExtraGeometries
    
    foundrelations40 = sketchEditDimensionValueBuilder10.FindRelations()
    
    sketchHelpedDimensionalConstraint10 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line8] [[WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line4] StartVertex]")
    sketchHelpedDimensionalConstraint10.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId164, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId164, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint10.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId165 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId165, None)
    
    markId166 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder10.DimValue = 5.0
    
    nXObject59 = sketchEditDimensionValueBuilder10.Commit()
    
    theSession.SetUndoMarkName(markId166, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId166, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId164, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId167 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder10.DimValue = 1.5
    
    nXObject60 = sketchEditDimensionValueBuilder10.Commit()
    
    theSession.SetUndoMarkName(markId167, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId167, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId164, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId168 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId169 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint10.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId169, None)
    
    theSession.SetUndoMarkName(markId164, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder10.Destroy()
    
    theSession.DeleteUndoMark(markId168, None)
    
    theSession.SetUndoMarkVisibility(markId164, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId167, None)
    
    theSession.DeleteUndoMark(markId166, None)
    
    theSession.DeleteUndoMark(markId164, None)
    
    sketchFindMovableObjectsBuilder29 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject61 = sketchFindMovableObjectsBuilder29.Commit()
    
    sketchFindMovableObjectsBuilder29.Destroy()
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder5 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder5.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject62 = sketchWorkRegionBuilder5.Commit()
    
    sketchWorkRegionBuilder5.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId170 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId171 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder10 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section10 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder10.Section = section10
    
    extrudeBuilder10.AllowSelfIntersectingSection(True)
    
    expression28 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder10.DistanceTolerance = 0.01
    
    extrudeBuilder10.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies42 = [NXOpen.Body.Null] * 1 
    targetBodies42[0] = NXOpen.Body.Null
    extrudeBuilder10.BooleanOperation.SetTargetBodies(targetBodies42)
    
    extrudeBuilder10.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder10.Limits.EndExtend.Value.SetFormula("-4")
    
    extrudeBuilder10.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Intersect
    
    targetBodies43 = [NXOpen.Body.Null] * 1 
    targetBodies43[0] = body1
    extrudeBuilder10.BooleanOperation.SetTargetBodies(targetBodies43)
    
    extrudeBuilder10.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder10.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder10.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder10.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder10 = extrudeBuilder10.SmartVolumeProfile
    
    smartVolumeProfileBuilder10.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder10.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId171, "Extrude Dialog")
    
    section10.DistanceTolerance = 0.01
    
    section10.ChainingTolerance = 0.0094999999999999998
    
    section10.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId172 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions5 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions5.SetSelectedFromInactive(False)
    
    curves4 = [NXOpen.ICurve.Null] * 4 
    curves4[0] = line9
    curves4[1] = line10
    curves4[2] = line11
    curves4[3] = line12
    seedPoint4 = NXOpen.Point3d(68.608041000000014, 68.608041000000014, 0.0)
    regionBoundaryRule4 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch5, curves4, seedPoint4, 0.01, selectionIntentRuleOptions5)
    
    selectionIntentRuleOptions5.Dispose()
    section10.AllowSelfIntersection(True)
    
    section10.AllowDegenerateCurves(False)
    
    rules5 = [None] * 1 
    rules5[0] = regionBoundaryRule4
    helpPoint5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section10.AddToSection(rules5, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint5, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId172, None)
    
    markId173 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId174 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId174, None)
    
    direction13 = workPart.Directions.CreateDirection(sketch5, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder10.Direction = direction13
    
    theSession.DeleteUndoMark(markId173, None)
    
    extrudeBuilder10.Limits.StartExtend.Value.SetFormula("6")
    
    extrudeBuilder10.Limits.EndExtend.Value.SetFormula("4")
    
    extrudeBuilder10.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder10.Limits.EndExtend.Value.SetFormula("100")
    
    extrudeBuilder10.Limits.EndExtend.Value.SetFormula("10")
    
    markId175 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId175, None)
    
    markId176 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder10.ParentFeatureInternal = False
    
    feature10 = extrudeBuilder10.CommitFeature()
    
    theSession.DeleteUndoMark(markId176, None)
    
    theSession.SetUndoMarkName(markId171, "Extrude")
    
    expression29 = extrudeBuilder10.Limits.StartExtend.Value
    expression30 = extrudeBuilder10.Limits.EndExtend.Value
    extrudeBuilder10.Destroy()
    
    workPart.Expressions.Delete(expression28)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled5, undoUnavailable5 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId177 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder11 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section11 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder11.Section = section11
    
    extrudeBuilder11.AllowSelfIntersectingSection(True)
    
    expression31 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder11.DistanceTolerance = 0.01
    
    extrudeBuilder11.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies44 = [NXOpen.Body.Null] * 1 
    targetBodies44[0] = NXOpen.Body.Null
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies44)
    
    extrudeBuilder11.Limits.StartExtend.Value.SetFormula("6")
    
    extrudeBuilder11.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder11.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Intersect
    
    targetBodies45 = [NXOpen.Body.Null] * 1 
    targetBodies45[0] = body1
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies45)
    
    extrudeBuilder11.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder11.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder11.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder11.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder11 = extrudeBuilder11.SmartVolumeProfile
    
    smartVolumeProfileBuilder11.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder11.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId177, "Extrude Dialog")
    
    section11.DistanceTolerance = 0.01
    
    section11.ChainingTolerance = 0.0094999999999999998
    
    section11.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId178 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions6 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions6.SetSelectedFromInactive(False)
    
    curves5 = [NXOpen.ICurve.Null] * 4 
    curves5[0] = line9
    curves5[1] = line10
    curves5[2] = line11
    curves5[3] = line12
    seedPoint5 = NXOpen.Point3d(68.608041000000014, 68.608041000000014, 0.0)
    regionBoundaryRule5 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch5, curves5, seedPoint5, 0.01, selectionIntentRuleOptions6)
    
    selectionIntentRuleOptions6.Dispose()
    section11.AllowSelfIntersection(True)
    
    section11.AllowDegenerateCurves(False)
    
    rules6 = [None] * 1 
    rules6[0] = regionBoundaryRule5
    helpPoint6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section11.AddToSection(rules6, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint6, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId178, None)
    
    markId179 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId180 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId180, None)
    
    direction14 = workPart.Directions.CreateDirection(sketch5, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder11.Direction = direction14
    
    theSession.DeleteUndoMark(markId179, None)
    
    extrudeBuilder11.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies46 = [NXOpen.Body.Null] * 1 
    targetBodies46[0] = body1
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies46)
    
    extrudeBuilder11.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies47 = [NXOpen.Body.Null] * 1 
    targetBodies47[0] = body1
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies47)
    
    markId181 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId181, None)
    
    markId182 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder11.ParentFeatureInternal = False
    
    feature11 = extrudeBuilder11.CommitFeature()
    
    theSession.DeleteUndoMark(markId182, None)
    
    theSession.SetUndoMarkName(markId177, "Extrude")
    
    expression32 = extrudeBuilder11.Limits.StartExtend.Value
    expression33 = extrudeBuilder11.Limits.EndExtend.Value
    extrudeBuilder11.Destroy()
    
    workPart.Expressions.Delete(expression31)
    
    rotMatrix4 = NXOpen.Matrix3x3()
    
    rotMatrix4.Xx = 0.87365063879881899
    rotMatrix4.Xy = 0.48633606519609207
    rotMatrix4.Xz = -0.014553110182956826
    rotMatrix4.Yx = -0.28406472072493744
    rotMatrix4.Yy = 0.53411899573535648
    rotMatrix4.Yz = 0.7962563235755914
    rotMatrix4.Zx = 0.39502125989100617
    rotMatrix4.Zy = -0.6915158205596138
    rotMatrix4.Zz = 0.60478432035717122
    translation4 = NXOpen.Point3d(-85.665274502427508, -41.103020009812738, 24.672316986911873)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix4, translation4, 1.5306046121079639)
    
    rotMatrix5 = NXOpen.Matrix3x3()
    
    rotMatrix5.Xx = 0.93976010441110402
    rotMatrix5.Xy = 0.3251175981376937
    rotMatrix5.Xz = -0.10559116221733131
    rotMatrix5.Yx = 0.19617301155756572
    rotMatrix5.Yy = -0.25997153285034241
    rotMatrix5.Yz = 0.94547921798624313
    rotMatrix5.Zx = 0.27994123614370336
    rotMatrix5.Zy = -0.90923778489931861
    rotMatrix5.Zz = -0.30809017319238652
    translation5 = NXOpen.Point3d(-79.503544155488825, -23.017966703674272, 49.204808739880129)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix5, translation5, 1.5306046121079639)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId183 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId184 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId185 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder6 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin46 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal6 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane13 = workPart.Planes.CreatePlane(origin46, normal6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder6.PlaneReference = plane13
    
    expression34 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression35 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder6 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder6 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder6.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId185, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder6.UseWorkPartOrigin = False
    
    coordinates12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point21 = workPart.Points.CreatePoint(coordinates12)
    
    nErrs6 = theSession.UpdateManager.AddToDeleteList(point21)
    
    coordinates13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point22 = workPart.Points.CreatePoint(coordinates13)
    
    origin47 = NXOpen.Point3d(67.237728573197259, 67.237728573197259, 0.0)
    matrix7 = NXOpen.Matrix3x3()
    
    matrix7.Xx = 1.0
    matrix7.Xy = 0.0
    matrix7.Xz = 0.0
    matrix7.Yx = 0.0
    matrix7.Yy = 1.0
    matrix7.Yz = 0.0
    matrix7.Zx = 0.0
    matrix7.Zy = 0.0
    matrix7.Zz = 1.0
    plane14 = workPart.Planes.CreateFixedTypePlane(origin47, matrix7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point23 = workPart.Points.CreatePoint(coordinates14)
    
    origin48 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector7 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction15 = workPart.Directions.CreateDirection(origin48, vector7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin49 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector8 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction16 = workPart.Directions.CreateDirection(origin49, vector8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin50 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix8 = NXOpen.Matrix3x3()
    
    matrix8.Xx = 1.0
    matrix8.Xy = 0.0
    matrix8.Xz = 0.0
    matrix8.Yx = 0.0
    matrix8.Yy = 1.0
    matrix8.Yz = 0.0
    matrix8.Zx = 0.0
    matrix8.Zy = 0.0
    matrix8.Zz = 1.0
    plane15 = workPart.Planes.CreateFixedTypePlane(origin50, matrix8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform6 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane15, direction16, point23, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem6 = workPart.CoordinateSystems.CreateCoordinateSystem(xform6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder6.CoordinateSystem = cartesianCoordinateSystem6
    
    simpleSketchInPlaceBuilder6.HorizontalReference.Value = datumAxis1
    
    point24 = simpleSketchInPlaceBuilder6.SketchOrigin
    
    simpleSketchInPlaceBuilder6.SketchOrigin = point24
    
    markId186 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId186, None)
    
    markId187 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject63 = simpleSketchInPlaceBuilder6.Commit()
    
    sketch6 = nXObject63
    feature12 = sketch6.Feature
    
    markId188 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs7 = theSession.UpdateManager.DoUpdate(markId188)
    
    sketch6.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder30 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject64 = sketchFindMovableObjectsBuilder30.Commit()
    
    sketchFindMovableObjectsBuilder30.Destroy()
    
    theSession.DeleteUndoMark(markId187, None)
    
    theSession.SetUndoMarkName(markId185, "Create Sketch")
    
    sketchInPlaceBuilder6.Destroy()
    
    sketchAlongPathBuilder6.Destroy()
    
    simpleSketchInPlaceBuilder6.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression35)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression34)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane13.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId184, None, True)
    
    markId189 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_003")
    
    rotMatrix6 = NXOpen.Matrix3x3()
    
    rotMatrix6.Xx = 0.93252817503349816
    rotMatrix6.Xy = 0.35904545816443512
    rotMatrix6.Xz = 0.038439065287580294
    rotMatrix6.Yx = -0.11231169727229787
    rotMatrix6.Yy = 0.18722442072623191
    rotMatrix6.Yz = 0.97587555504764034
    rotMatrix6.Zx = 0.34318695404182764
    rotMatrix6.Zy = -0.91434860707238796
    rotMatrix6.Zz = 0.21491705218589413
    translation6 = NXOpen.Point3d(-17.686613318313896, 50.625858817525767, 38.195113920904163)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix6, translation6, 1.5306046121079639)
    
    scaleAboutPoint108 = NXOpen.Point3d(63.094620193039653, 40.017546779968974, 0.0)
    viewCenter108 = NXOpen.Point3d(-63.094620193039475, -40.017546779968896, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint108, viewCenter108)
    
    scaleAboutPoint109 = NXOpen.Point3d(50.613985732937024, 32.014037423975189, 0.0)
    viewCenter109 = NXOpen.Point3d(-50.613985732936861, -32.014037423975118, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint109, viewCenter109)
    
    scaleAboutPoint110 = NXOpen.Point3d(40.601820249153867, 25.721861601984394, 0.0)
    viewCenter110 = NXOpen.Point3d(-40.601820249153704, -25.721861601984319, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint110, viewCenter110)
    
    scaleAboutPoint111 = NXOpen.Point3d(32.658466859809934, 21.462542584021396, 0.0)
    viewCenter111 = NXOpen.Point3d(-32.658466859809749, -21.462542584021328, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint111, viewCenter111)
    
    scaleAboutPoint112 = NXOpen.Point3d(26.126773487847952, 19.294161993058417, 0.0)
    viewCenter112 = NXOpen.Point3d(-26.126773487847778, -19.294161993058346, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint112, viewCenter112)
    
    scaleAboutPoint113 = NXOpen.Point3d(32.658466859809877, 24.471723812296553, 0.0)
    viewCenter113 = NXOpen.Point3d(-32.658466859809742, -24.471723812296474, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint113, viewCenter113)
    
    scaleAboutPoint114 = NXOpen.Point3d(40.823083574762343, 30.589654765370682, 0.0)
    viewCenter114 = NXOpen.Point3d(-40.823083574762173, -30.589654765370607, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint114, viewCenter114)
    
    scaleAboutPoint115 = NXOpen.Point3d(50.890564889947605, 38.651937192229212, 0.0)
    viewCenter115 = NXOpen.Point3d(-50.890564889947449, -38.651937192229141, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint115, viewCenter115)
    
    scaleAboutPoint116 = NXOpen.Point3d(63.44034413930288, 48.660645436549743, 0.0)
    viewCenter116 = NXOpen.Point3d(-63.440344139302702, -48.660645436549672, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint116, viewCenter116)
    
    scaleAboutPoint117 = NXOpen.Point3d(79.084352707714061, 61.257961728516186, 0.0)
    viewCenter117 = NXOpen.Point3d(-79.08435270771389, -61.257961728516129, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint117, viewCenter117)
    
    scaleAboutPoint118 = NXOpen.Point3d(97.775053552569858, 78.463129991772263, 0.0)
    viewCenter118 = NXOpen.Point3d(-97.775053552569759, -78.463129991772192, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint118, viewCenter118)
    
    scaleAboutPoint119 = NXOpen.Point3d(121.54357485816698, 103.48084915007826, 0.0)
    viewCenter119 = NXOpen.Point3d(-121.54357485816686, -103.4808491500782, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint119, viewCenter119)
    
    scaleAboutPoint120 = NXOpen.Point3d(151.92946857270869, 130.19511404077949, 0.0)
    viewCenter120 = NXOpen.Point3d(-151.9294685727086, -130.19511404077949, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint120, viewCenter120)
    
    scaleAboutPoint121 = NXOpen.Point3d(189.91183571588587, 165.38155693591722, 0.0)
    viewCenter121 = NXOpen.Point3d(-189.91183571588579, -165.38155693591722, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint121, viewCenter121)
    
    scaleAboutPoint122 = NXOpen.Point3d(237.3897946448574, 210.68344274731083, 0.0)
    viewCenter122 = NXOpen.Point3d(-237.38979464485718, -210.68344274731083, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint122, viewCenter122)
    
    scaleAboutPoint123 = NXOpen.Point3d(313.22264571196433, 292.20375764445106, 0.0)
    viewCenter123 = NXOpen.Point3d(-313.22264571196433, -292.20375764445106, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint123, viewCenter123)
    
    scaleAboutPoint124 = NXOpen.Point3d(429.65080020358289, 408.52887837103253, 0.0)
    viewCenter124 = NXOpen.Point3d(-429.65080020358289, -408.52887837103253, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint124, viewCenter124)
    
    scaleAboutPoint125 = NXOpen.Point3d(344.54491028316085, 327.64737281712064, 0.0)
    viewCenter125 = NXOpen.Point3d(-344.54491028316085, -327.64737281712064, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint125, viewCenter125)
    
    scaleAboutPoint126 = NXOpen.Point3d(276.29534432276449, 262.11789825369658, 0.0)
    viewCenter126 = NXOpen.Point3d(-276.29534432276449, -262.11789825369658, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint126, viewCenter126)
    
    scaleAboutPoint127 = NXOpen.Point3d(221.56380833520006, 209.6943186029572, 0.0)
    viewCenter127 = NXOpen.Point3d(-221.56380833520006, -209.6943186029572, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint127, viewCenter127)
    
    scaleAboutPoint128 = NXOpen.Point3d(177.25104666816011, 166.48937597759326, 0.0)
    viewCenter128 = NXOpen.Point3d(-177.25104666816011, -166.48937597759326, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint128, viewCenter128)
    
    scaleAboutPoint129 = NXOpen.Point3d(130.99696401380214, 113.94710142953151, 0.0)
    viewCenter129 = NXOpen.Point3d(-130.99696401380214, -113.94710142953151, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint129, viewCenter129)
    
    scaleAboutPoint130 = NXOpen.Point3d(104.52747437802363, 88.1866159804256, 0.0)
    viewCenter130 = NXOpen.Point3d(-104.52747437802367, -88.186615980425586, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint130, viewCenter130)
    
    scaleAboutPoint131 = NXOpen.Point3d(83.405902036004306, 68.60459558660979, 0.0)
    viewCenter131 = NXOpen.Point3d(-83.405902036004392, -68.604595586609776, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint131, viewCenter131)
    
    scaleAboutPoint132 = NXOpen.Point3d(42.869769336640481, 14.433974756489869, 0.0)
    viewCenter132 = NXOpen.Point3d(-42.869769336640537, -14.433974756489855, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint132, viewCenter132)
    
    rotMatrix7 = NXOpen.Matrix3x3()
    
    rotMatrix7.Xx = 0.99401073851681088
    rotMatrix7.Xy = 0.10089881651608054
    rotMatrix7.Xz = 0.041977143053293441
    rotMatrix7.Yx = -0.01451815870073953
    rotMatrix7.Yy = -0.25878770564155967
    rotMatrix7.Yz = 0.96582511174472729
    rotMatrix7.Zx = 0.10831377927670348
    rotMatrix7.Zy = -0.96064996342810993
    rotMatrix7.Zz = -0.25577289337294107
    translation7 = NXOpen.Point3d(-54.320451860811716, 16.629486128315314, 57.419035515949105)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix7, translation7, 1.9132557651349562)
    
    rotMatrix8 = NXOpen.Matrix3x3()
    
    rotMatrix8.Xx = 0.99358138619905267
    rotMatrix8.Xy = 0.10874585539698171
    rotMatrix8.Xz = 0.031150729249019318
    rotMatrix8.Yx = 0.073365615523193997
    rotMatrix8.Yy = -0.8290955448240851
    rotMatrix8.Yz = 0.55427255390444263
    rotMatrix8.Zx = 0.086101773835791429
    rotMatrix8.Zy = -0.5484295000151147
    rotMatrix8.Zz = -0.83175210733457083
    translation8 = NXOpen.Point3d(-54.711380985578927, 47.63269281503225, 36.898424107432263)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix8, translation8, 1.9132557651349562)
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder6 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder6.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject65 = sketchWorkRegionBuilder6.Commit()
    
    sketchWorkRegionBuilder6.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId190 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId191 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId192 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId193 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder7 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin51 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal7 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane16 = workPart.Planes.CreatePlane(origin51, normal7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder7.PlaneReference = plane16
    
    expression36 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression37 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder7 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder7 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder7.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId193, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder7.UseWorkPartOrigin = False
    
    coordinates15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point25 = workPart.Points.CreatePoint(coordinates15)
    
    origin52 = NXOpen.Point3d(67.237728573197259, 67.237728573197259, 0.0)
    matrix9 = NXOpen.Matrix3x3()
    
    matrix9.Xx = 1.0
    matrix9.Xy = 0.0
    matrix9.Xz = 0.0
    matrix9.Yx = 0.0
    matrix9.Yy = 1.0
    matrix9.Yz = 0.0
    matrix9.Zx = 0.0
    matrix9.Zy = 0.0
    matrix9.Zz = 1.0
    plane17 = workPart.Planes.CreateFixedTypePlane(origin52, matrix9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point26 = workPart.Points.CreatePoint(coordinates16)
    
    origin53 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector9 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction17 = workPart.Directions.CreateDirection(origin53, vector9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin54 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector10 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction18 = workPart.Directions.CreateDirection(origin54, vector10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin55 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix10 = NXOpen.Matrix3x3()
    
    matrix10.Xx = 1.0
    matrix10.Xy = 0.0
    matrix10.Xz = 0.0
    matrix10.Yx = 0.0
    matrix10.Yy = 1.0
    matrix10.Yz = 0.0
    matrix10.Zx = 0.0
    matrix10.Zy = 0.0
    matrix10.Zz = 1.0
    plane18 = workPart.Planes.CreateFixedTypePlane(origin55, matrix10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform7 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane18, direction18, point26, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem7 = workPart.CoordinateSystems.CreateCoordinateSystem(xform7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder7.CoordinateSystem = cartesianCoordinateSystem7
    
    simpleSketchInPlaceBuilder7.HorizontalReference.Value = datumAxis1
    
    point27 = simpleSketchInPlaceBuilder7.SketchOrigin
    
    simpleSketchInPlaceBuilder7.SketchOrigin = point27
    
    markId194 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId194, None)
    
    markId195 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject66 = simpleSketchInPlaceBuilder7.Commit()
    
    sketch7 = nXObject66
    feature13 = sketch7.Feature
    
    markId196 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs8 = theSession.UpdateManager.DoUpdate(markId196)
    
    sketch7.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder31 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject67 = sketchFindMovableObjectsBuilder31.Commit()
    
    sketchFindMovableObjectsBuilder31.Destroy()
    
    theSession.DeleteUndoMark(markId195, None)
    
    theSession.SetUndoMarkName(markId193, "Create Sketch")
    
    sketchInPlaceBuilder7.Destroy()
    
    sketchAlongPathBuilder7.Destroy()
    
    simpleSketchInPlaceBuilder7.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression37)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression36)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane16.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId192, None, True)
    
    markId197 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_004")
    
    scaleAboutPoint133 = NXOpen.Point3d(68.107617413856502, 15.12542264901637, 0.0)
    viewCenter133 = NXOpen.Point3d(-68.107617413856332, -15.125422649016297, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint133, viewCenter133)
    
    scaleAboutPoint134 = NXOpen.Point3d(54.62438350959053, 12.100338119213099, 0.0)
    viewCenter134 = NXOpen.Point3d(-54.624383509590366, -12.100338119213038, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint134, viewCenter134)
    
    scaleAboutPoint135 = NXOpen.Point3d(43.810138470476659, 9.6802704953704861, 0.0)
    viewCenter135 = NXOpen.Point3d(-43.810138470476467, -9.6802704953704293, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint135, viewCenter135)
    
    scaleAboutPoint136 = NXOpen.Point3d(35.313626767111543, 10.133860312867849, 0.0)
    viewCenter136 = NXOpen.Point3d(-35.313626767111366, -10.133860312867791, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint136, viewCenter136)
    
    scaleAboutPoint137 = NXOpen.Point3d(44.142033458889358, 12.999220379497501, 0.0)
    viewCenter137 = NXOpen.Point3d(-44.142033458889188, -12.999220379497444, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint137, viewCenter137)
    
    scaleAboutPoint138 = NXOpen.Point3d(55.315831402116999, 16.663894209887754, 0.0)
    viewCenter138 = NXOpen.Point3d(-55.315831402116835, -16.663894209887694, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint138, viewCenter138)
    
    scaleAboutPoint139 = NXOpen.Point3d(69.317651225777809, 21.002729735491304, 0.0)
    viewCenter139 = NXOpen.Point3d(-69.317651225777624, -21.002729735491215, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint139, viewCenter139)
    
    scaleAboutPoint140 = NXOpen.Point3d(87.079218965051268, 27.117722035022211, 0.0)
    viewCenter140 = NXOpen.Point3d(-87.079218965051112, -27.117722035022119, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint140, viewCenter140)
    
    scaleAboutPoint141 = NXOpen.Point3d(110.19950787140479, 36.057927207922916, 0.0)
    viewCenter141 = NXOpen.Point3d(-110.19950787140465, -36.057927207922823, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint141, viewCenter141)
    
    scaleAboutPoint142 = NXOpen.Point3d(152.26708961398143, 70.393987105355095, 0.0)
    viewCenter142 = NXOpen.Point3d(-152.26708961398131, -70.393987105354981, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint142, viewCenter142)
    
    scaleAboutPoint143 = NXOpen.Point3d(190.3338620174768, 90.946667992829887, 0.0)
    viewCenter143 = NXOpen.Point3d(-190.33386201747666, -90.946667992829745, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint143, viewCenter143)
    
    scaleAboutPoint144 = NXOpen.Point3d(238.97239327582315, 120.54126239188874, 0.0)
    viewCenter144 = NXOpen.Point3d(-238.97239327582304, -120.54126239188865, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint144, viewCenter144)
    
    scaleAboutPoint145 = NXOpen.Point3d(299.37490769101458, 157.27073895221807, 0.0)
    viewCenter145 = NXOpen.Point3d(-299.37490769101447, -157.27073895221801, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint145, viewCenter145)
    
    scaleAboutPoint146 = NXOpen.Point3d(406.36516930525943, 265.82711379502257, 0.0)
    viewCenter146 = NXOpen.Point3d(-406.36516930525914, -265.82711379502257, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint146, viewCenter146)
    
    scaleAboutPoint147 = NXOpen.Point3d(325.7515515404433, 212.66169103601811, 0.0)
    viewCenter147 = NXOpen.Point3d(-325.75155154044319, -212.66169103601811, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint147, viewCenter147)
    
    scaleAboutPoint148 = NXOpen.Point3d(263.23890561729741, 168.54675419784877, 0.0)
    viewCenter148 = NXOpen.Point3d(-263.23890561729741, -168.5467541978488, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint148, viewCenter148)
    
    scaleAboutPoint149 = NXOpen.Point3d(211.43517709701968, 131.46119294555214, 0.0)
    viewCenter149 = NXOpen.Point3d(-211.43517709701968, -131.4611929455522, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint149, viewCenter149)
    
    scaleAboutPoint150 = NXOpen.Point3d(170.16100480143379, 100.7798808198968, 0.0)
    viewCenter150 = NXOpen.Point3d(-170.16100480143379, -100.7798808198968, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint150, viewCenter150)
    
    scaleAboutPoint151 = NXOpen.Point3d(136.66899750718329, 74.681774329518191, 0.0)
    viewCenter151 = NXOpen.Point3d(-136.66899750718329, -74.681774329518149, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint151, viewCenter151)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId198 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId199 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId199, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint13 = NXOpen.Point3d(51.0, 5.0, 0.0)
    endPoint13 = NXOpen.Point3d(54.0, 5.0, 0.0)
    line13 = workPart.Curves.CreateLine(startPoint13, endPoint13)
    
    startPoint14 = NXOpen.Point3d(54.0, 5.0, 0.0)
    endPoint14 = NXOpen.Point3d(54.0, 14.0, 0.0)
    line14 = workPart.Curves.CreateLine(startPoint14, endPoint14)
    
    startPoint15 = NXOpen.Point3d(54.0, 14.0, 0.0)
    endPoint15 = NXOpen.Point3d(51.0, 14.0, 0.0)
    line15 = workPart.Curves.CreateLine(startPoint15, endPoint15)
    
    startPoint16 = NXOpen.Point3d(51.0, 14.0, 0.0)
    endPoint16 = NXOpen.Point3d(51.0, 5.0, 0.0)
    line16 = workPart.Curves.CreateLine(startPoint16, endPoint16)
    
    theSession.ActiveSketch.AddGeometry(line13, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line14, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line15, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line16, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_13.Geometry = line13
    conGeom1_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_13.SplineDefiningPointIndex = 0
    conGeom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_13.Geometry = line14
    conGeom2_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint13 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_13, conGeom2_13)
    
    conGeom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_14.Geometry = line14
    conGeom1_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_14.SplineDefiningPointIndex = 0
    conGeom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_14.Geometry = line15
    conGeom2_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint14 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_14, conGeom2_14)
    
    conGeom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_15.Geometry = line15
    conGeom1_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_15.SplineDefiningPointIndex = 0
    conGeom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_15.Geometry = line16
    conGeom2_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint15 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_15, conGeom2_15)
    
    conGeom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_16.Geometry = line16
    conGeom1_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_16.SplineDefiningPointIndex = 0
    conGeom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_16.Geometry = line13
    conGeom2_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint16 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_16, conGeom2_16)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms7 = [NXOpen.SmartObject.Null] * 4 
    geoms7[0] = line13
    geoms7[1] = line14
    geoms7[2] = line15
    geoms7[3] = line16
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms7)
    
    geoms8 = [NXOpen.SmartObject.Null] * 4 
    geoms8[0] = line13
    geoms8[1] = line14
    geoms8[2] = line15
    geoms8[3] = line16
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms8)
    
    objects8 = [NXOpen.NXObject.Null] * 4 
    objects8[0] = sketchGeometricConstraint13
    objects8[1] = sketchGeometricConstraint14
    objects8[2] = sketchGeometricConstraint15
    objects8[3] = sketchGeometricConstraint16
    errorList4 = theSession.ActiveSketch.DeleteObjects(objects8)
    
    errorList4.Dispose()
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    sketchFindMovableObjectsBuilder32 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject68 = sketchFindMovableObjectsBuilder32.Commit()
    
    sketchFindMovableObjectsBuilder32.Destroy()
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId200 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId201 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId201, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint17 = NXOpen.Point3d(61.0, 5.0, 0.0)
    endPoint17 = NXOpen.Point3d(66.0, 5.0, 0.0)
    line17 = workPart.Curves.CreateLine(startPoint17, endPoint17)
    
    startPoint18 = NXOpen.Point3d(66.0, 5.0, 0.0)
    endPoint18 = NXOpen.Point3d(66.0, 14.0, 0.0)
    line18 = workPart.Curves.CreateLine(startPoint18, endPoint18)
    
    startPoint19 = NXOpen.Point3d(66.0, 14.0, 0.0)
    endPoint19 = NXOpen.Point3d(61.0, 14.0, 0.0)
    line19 = workPart.Curves.CreateLine(startPoint19, endPoint19)
    
    startPoint20 = NXOpen.Point3d(61.0, 14.0, 0.0)
    endPoint20 = NXOpen.Point3d(61.0, 5.0, 0.0)
    line20 = workPart.Curves.CreateLine(startPoint20, endPoint20)
    
    theSession.ActiveSketch.AddGeometry(line17, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line18, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line19, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line20, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_17 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_17.Geometry = line17
    conGeom1_17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_17.SplineDefiningPointIndex = 0
    conGeom2_17 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_17.Geometry = line18
    conGeom2_17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint17 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_17, conGeom2_17)
    
    conGeom1_18 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_18.Geometry = line18
    conGeom1_18.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_18.SplineDefiningPointIndex = 0
    conGeom2_18 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_18.Geometry = line19
    conGeom2_18.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_18.SplineDefiningPointIndex = 0
    sketchGeometricConstraint18 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_18, conGeom2_18)
    
    conGeom1_19 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_19.Geometry = line19
    conGeom1_19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_19.SplineDefiningPointIndex = 0
    conGeom2_19 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_19.Geometry = line20
    conGeom2_19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint19 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_19, conGeom2_19)
    
    conGeom1_20 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_20.Geometry = line20
    conGeom1_20.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_20.SplineDefiningPointIndex = 0
    conGeom2_20 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_20.Geometry = line17
    conGeom2_20.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint20 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_20, conGeom2_20)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms9 = [NXOpen.SmartObject.Null] * 4 
    geoms9[0] = line17
    geoms9[1] = line18
    geoms9[2] = line19
    geoms9[3] = line20
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms9)
    
    geoms10 = [NXOpen.SmartObject.Null] * 4 
    geoms10[0] = line17
    geoms10[1] = line18
    geoms10[2] = line19
    geoms10[3] = line20
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms10)
    
    objects9 = [NXOpen.NXObject.Null] * 4 
    objects9[0] = sketchGeometricConstraint17
    objects9[1] = sketchGeometricConstraint18
    objects9[2] = sketchGeometricConstraint19
    objects9[3] = sketchGeometricConstraint20
    errorList5 = theSession.ActiveSketch.DeleteObjects(objects9)
    
    errorList5.Dispose()
    sketchFindMovableObjectsBuilder33 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject69 = sketchFindMovableObjectsBuilder33.Commit()
    
    sketchFindMovableObjectsBuilder33.Destroy()
    
    markId202 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder13 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects28 = [None] * 1 
    dragobjects28[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects28[0].Geometry = line17
    dragobjects28[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects28[0].PointIndex = 0
    sketchDragGeometryBuilder13.SetDragGeometry(dragobjects28)
    
    sketchDragGeometryBuilder13.SplineLinearScale = False
    
    foundrelations41 = sketchDragGeometryBuilder13.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    sketchDragGeometryBuilder13.SetRelationRelaxState(foundrelations41[0], True)
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    sketchDragGeometryBuilder13.Destroy()
    
    scaleAboutPoint152 = NXOpen.Point3d(59.421303263992741, -61.690116661345215, 0.0)
    viewCenter152 = NXOpen.Point3d(-59.421303263992762, 61.690116661345229, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint152, viewCenter152)
    
    scaleAboutPoint153 = NXOpen.Point3d(47.537042611194209, -49.352093329076169, 0.0)
    viewCenter153 = NXOpen.Point3d(-47.537042611194238, 49.352093329076197, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint153, viewCenter153)
    
    scaleAboutPoint154 = NXOpen.Point3d(38.306213245965935, -39.619964241766219, 0.0)
    viewCenter154 = NXOpen.Point3d(-38.306213245965985, 39.619964241766269, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint154, viewCenter154)
    
    scaleAboutPoint155 = NXOpen.Point3d(24.44959747973569, -20.854068438598048, 0.0)
    viewCenter155 = NXOpen.Point3d(-24.449597479735672, 20.854068438598095, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint155, viewCenter155)
    
    markId203 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder14 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects29 = [None] * 1 
    dragobjects29[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects29[0].Geometry = line13
    dragobjects29[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects29[0].PointIndex = 0
    sketchDragGeometryBuilder14.SetDragGeometry(dragobjects29)
    
    sketchDragGeometryBuilder14.SplineLinearScale = False
    
    foundrelations42 = sketchDragGeometryBuilder14.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects30 = [None] * 1 
    dragobjects30[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects30[0].Geometry = line13
    dragobjects30[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects30[0].PointIndex = 0
    sketchDragGeometryBuilder14.SetDragGeometry(dragobjects30)
    
    foundrelations43 = sketchDragGeometryBuilder14.FindRelations()
    
    sketchDragGeometryBuilder14.Destroy()
    
    markId204 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences11 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences11 = dimensionPreferences11.GetNarrowDimensionPreferences()
    
    option11 = narrowDimensionPreferences11.DimensionDisplayOption
    
    sketchLinearDimensionBuilder11 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder11 = sketchLinearDimensionBuilder11.Driving
    
    drivingValueBuilder11.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject21 = sketchLinearDimensionBuilder11.FirstAssociativity
    
    selectNXObject22 = sketchLinearDimensionBuilder11.SecondAssociativity
    
    point1_55 = NXOpen.Point3d(51.0, 5.0, 0.0)
    point2_55 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject21.SetValue(NXOpen.InferSnapType.SnapType.Start, line13, NXOpen.View.Null, point1_55, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_55)
    
    point1_56 = NXOpen.Point3d(54.0, 5.0, 0.0)
    point2_56 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject22.SetValue(NXOpen.InferSnapType.SnapType.End, line13, NXOpen.View.Null, point1_56, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_56)
    
    dimensionMeasurementBuilder11 = sketchLinearDimensionBuilder11.Measurement
    
    dimensionMeasurementBuilder11.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder11 = sketchLinearDimensionBuilder11.Origin
    
    origin58 = NXOpen.Point3d(52.5, 1.9894249869965988, 0.0)
    originBuilder11.OriginPoint = origin58
    
    originBuilder11.SetInferRelativeToGeometry(True)
    
    nXObject70 = sketchLinearDimensionBuilder11.Commit()
    
    horizontalDimension4 = nXObject70
    horizontalDimension4.IsOriginCentered = True
    
    sketchLinearDimensionBuilder11.Destroy()
    
    narrowDimensionPreferences11.Dispose()
    dimensionPreferences11.Dispose()
    sketchFindMovableObjectsBuilder34 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject71 = sketchFindMovableObjectsBuilder34.Commit()
    
    sketchFindMovableObjectsBuilder34.Destroy()
    
    markId205 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId206 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder11 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension4)
    
    selectNXObjectList22 = sketchEditDimensionValueBuilder11.ExtraGeometries
    
    foundrelations44 = sketchEditDimensionValueBuilder11.FindRelations()
    
    sketchHelpedDimensionalConstraint11 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line11] StartVertex] [[Curve Line11] EndVertex]")
    sketchHelpedDimensionalConstraint11.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId206, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId206, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint11.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId207 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId207, None)
    
    markId208 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder11.DimValue = 2.0
    
    theSession.ActiveSketch.Scale(0.66666666666666663)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin59 = NXOpen.Point3d(35.0, 1.326283324664399, 0.0)
    horizontalDimension4.AnnotationOrigin = origin59
    
    sketchEditDimensionValueBuilder11.RestoreOperation()
    
    sketchEditDimensionValueBuilder11.LoadExtraGeometry()
    
    selectNXObjectList23 = sketchEditDimensionValueBuilder11.ExtraGeometries
    
    foundrelations45 = sketchEditDimensionValueBuilder11.FindRelations()
    
    nXObject72 = sketchEditDimensionValueBuilder11.Commit()
    
    theSession.SetUndoMarkName(markId208, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId208, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId206, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId209 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    selectNXObjectList24 = sketchEditDimensionValueBuilder11.ExtraGeometries
    
    objects10 = [NXOpen.NXObject.Null] * 1 
    objects10[0] = line17
    selectNXObjectList24.SetArray(objects10)
    
    sketchEditDimensionValueBuilder11.RestoreOperation()
    
    sketchEditDimensionValueBuilder11.LoadExtraGeometry()
    
    selectNXObjectList25 = sketchEditDimensionValueBuilder11.ExtraGeometries
    
    theSession.ActiveSketch.Update()
    
    theSession.SetUndoMarkName(markId209, "Edit Dimension Value - Selection")
    
    theSession.SetUndoMarkVisibility(markId209, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId206, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId210 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId211 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint11.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId211, None)
    
    theSession.SetUndoMarkName(markId206, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder11.Destroy()
    
    theSession.DeleteUndoMark(markId210, None)
    
    theSession.SetUndoMarkVisibility(markId206, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId209, None)
    
    theSession.DeleteUndoMark(markId208, None)
    
    theSession.DeleteUndoMark(markId206, None)
    
    sketchFindMovableObjectsBuilder35 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject73 = sketchFindMovableObjectsBuilder35.Commit()
    
    sketchFindMovableObjectsBuilder35.Destroy()
    
    markId212 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder15 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects31 = [None] * 1 
    dragobjects31[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects31[0].Geometry = line17
    dragobjects31[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects31[0].PointIndex = 0
    sketchDragGeometryBuilder15.SetDragGeometry(dragobjects31)
    
    sketchDragGeometryBuilder15.SplineLinearScale = False
    
    foundrelations46 = sketchDragGeometryBuilder15.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects32 = [None] * 1 
    dragobjects32[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects32[0].Geometry = line17
    dragobjects32[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects32[0].PointIndex = 0
    sketchDragGeometryBuilder15.SetDragGeometry(dragobjects32)
    
    foundrelations47 = sketchDragGeometryBuilder15.FindRelations()
    
    sketchDragGeometryBuilder15.Destroy()
    
    markId213 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences12 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences12 = dimensionPreferences12.GetNarrowDimensionPreferences()
    
    option12 = narrowDimensionPreferences12.DimensionDisplayOption
    
    sketchLinearDimensionBuilder12 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder12 = sketchLinearDimensionBuilder12.Driving
    
    drivingValueBuilder12.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject23 = sketchLinearDimensionBuilder12.FirstAssociativity
    
    selectNXObject24 = sketchLinearDimensionBuilder12.SecondAssociativity
    
    point1_59 = NXOpen.Point3d(40.666666666666664, 3.333333333333333, 0.0)
    point2_59 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject23.SetValue(NXOpen.InferSnapType.SnapType.Start, line17, NXOpen.View.Null, point1_59, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_59)
    
    point1_60 = NXOpen.Point3d(44.0, 3.333333333333333, 0.0)
    point2_60 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject24.SetValue(NXOpen.InferSnapType.SnapType.End, line17, NXOpen.View.Null, point1_60, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_60)
    
    dimensionMeasurementBuilder12 = sketchLinearDimensionBuilder12.Measurement
    
    dimensionMeasurementBuilder12.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder12 = sketchLinearDimensionBuilder12.Origin
    
    origin61 = NXOpen.Point3d(42.333333333333329, 1.326283324664399, 0.0)
    originBuilder12.OriginPoint = origin61
    
    originBuilder12.SetInferRelativeToGeometry(True)
    
    nXObject74 = sketchLinearDimensionBuilder12.Commit()
    
    horizontalDimension5 = nXObject74
    horizontalDimension5.IsOriginCentered = True
    
    sketchLinearDimensionBuilder12.Destroy()
    
    narrowDimensionPreferences12.Dispose()
    dimensionPreferences12.Dispose()
    sketchFindMovableObjectsBuilder36 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject75 = sketchFindMovableObjectsBuilder36.Commit()
    
    sketchFindMovableObjectsBuilder36.Destroy()
    
    markId214 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId215 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder12 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension5)
    
    selectNXObjectList26 = sketchEditDimensionValueBuilder12.ExtraGeometries
    
    foundrelations48 = sketchEditDimensionValueBuilder12.FindRelations()
    
    sketchHelpedDimensionalConstraint12 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line15] StartVertex] [[Curve Line15] EndVertex]")
    sketchHelpedDimensionalConstraint12.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId215, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId215, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint12.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId216 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId216, None)
    
    markId217 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder12.DimValue = 2.0
    
    nXObject76 = sketchEditDimensionValueBuilder12.Commit()
    
    theSession.SetUndoMarkName(markId217, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId217, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId215, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId218 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId219 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint12.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId219, None)
    
    theSession.SetUndoMarkName(markId215, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder12.Destroy()
    
    theSession.DeleteUndoMark(markId218, None)
    
    theSession.SetUndoMarkVisibility(markId215, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId217, None)
    
    theSession.DeleteUndoMark(markId215, None)
    
    sketchFindMovableObjectsBuilder37 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject77 = sketchFindMovableObjectsBuilder37.Commit()
    
    sketchFindMovableObjectsBuilder37.Destroy()
    
    markId220 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder16 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects33 = [None] * 1 
    dragobjects33[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects33[0].Geometry = line14
    dragobjects33[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects33[0].PointIndex = 0
    sketchDragGeometryBuilder16.SetDragGeometry(dragobjects33)
    
    sketchDragGeometryBuilder16.SplineLinearScale = False
    
    foundrelations49 = sketchDragGeometryBuilder16.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects34 = [None] * 2 
    dragobjects34[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects34[1] = NXOpen.Sketch.SketchGeometry()
    dragobjects34[0].Geometry = line14
    dragobjects34[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects34[0].PointIndex = 0
    dragobjects34[1].Geometry = line20
    dragobjects34[1].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects34[1].PointIndex = 0
    sketchDragGeometryBuilder16.SetDragGeometry(dragobjects34)
    
    foundrelations50 = sketchDragGeometryBuilder16.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects35 = [None] * 2 
    dragobjects35[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects35[1] = NXOpen.Sketch.SketchGeometry()
    dragobjects35[0].Geometry = line14
    dragobjects35[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects35[0].PointIndex = 0
    dragobjects35[1].Geometry = line20
    dragobjects35[1].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects35[1].PointIndex = 0
    sketchDragGeometryBuilder16.SetDragGeometry(dragobjects35)
    
    foundrelations51 = sketchDragGeometryBuilder16.FindRelations()
    
    sketchDragGeometryBuilder16.Destroy()
    
    markId221 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences13 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences13 = dimensionPreferences13.GetNarrowDimensionPreferences()
    
    option13 = narrowDimensionPreferences13.DimensionDisplayOption
    
    sketchLinearDimensionBuilder13 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder13 = sketchLinearDimensionBuilder13.Driving
    
    drivingValueBuilder13.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder13 = sketchLinearDimensionBuilder13.Measurement
    
    dimensionMeasurementBuilder13.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject25 = sketchLinearDimensionBuilder13.FirstAssociativity
    
    selectNXObject26 = sketchLinearDimensionBuilder13.SecondAssociativity
    
    point1_65 = NXOpen.Point3d(36.0, 4.545769876599369, 0.0)
    point2_65 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject25.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line14, NXOpen.View.Null, point1_65, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_65)
    
    point1_66 = NXOpen.Point3d(40.666666666666664, 3.333333333333333, 0.0)
    point2_66 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject26.SetValue(NXOpen.InferSnapType.SnapType.End, line20, NXOpen.View.Null, point1_66, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_66)
    
    originBuilder13 = sketchLinearDimensionBuilder13.Origin
    
    origin64 = NXOpen.Point3d(38.333333333333329, 5.2538125185464644, 0.0)
    originBuilder13.OriginPoint = origin64
    
    originBuilder13.SetInferRelativeToGeometry(True)
    
    nXObject78 = sketchLinearDimensionBuilder13.Commit()
    
    perpendicularDimension5 = nXObject78
    perpendicularDimension5.IsOriginCentered = True
    
    sketchLinearDimensionBuilder13.Destroy()
    
    narrowDimensionPreferences13.Dispose()
    dimensionPreferences13.Dispose()
    sketchFindMovableObjectsBuilder38 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject79 = sketchFindMovableObjectsBuilder38.Commit()
    
    sketchFindMovableObjectsBuilder38.Destroy()
    
    markId222 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId223 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder13 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension5)
    
    selectNXObjectList27 = sketchEditDimensionValueBuilder13.ExtraGeometries
    
    foundrelations52 = sketchEditDimensionValueBuilder13.FindRelations()
    
    sketchHelpedDimensionalConstraint13 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line12] [[Curve Line18] EndVertex]")
    sketchHelpedDimensionalConstraint13.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId223, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId223, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint13.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId224 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId224, None)
    
    markId225 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder13.DimValue = 6.0
    
    nXObject80 = sketchEditDimensionValueBuilder13.Commit()
    
    theSession.SetUndoMarkName(markId225, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId225, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId223, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId226 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId227 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint13.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId227, None)
    
    theSession.SetUndoMarkName(markId223, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder13.Destroy()
    
    theSession.DeleteUndoMark(markId226, None)
    
    theSession.SetUndoMarkVisibility(markId223, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId225, None)
    
    theSession.DeleteUndoMark(markId223, None)
    
    sketchFindMovableObjectsBuilder39 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject81 = sketchFindMovableObjectsBuilder39.Commit()
    
    sketchFindMovableObjectsBuilder39.Destroy()
    
    markId228 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder17 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects36 = [None] * 1 
    dragobjects36[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects36[0].Geometry = line13
    dragobjects36[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects36[0].PointIndex = 0
    sketchDragGeometryBuilder17.SetDragGeometry(dragobjects36)
    
    sketchDragGeometryBuilder17.SplineLinearScale = False
    
    foundrelations53 = sketchDragGeometryBuilder17.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects37 = [None] * 1 
    dragobjects37[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects37[0].Geometry = line13
    dragobjects37[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects37[0].PointIndex = 0
    sketchDragGeometryBuilder17.SetDragGeometry(dragobjects37)
    
    foundrelations54 = sketchDragGeometryBuilder17.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects38 = [None] * 1 
    dragobjects38[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects38[0].Geometry = line13
    dragobjects38[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects38[0].PointIndex = 0
    sketchDragGeometryBuilder17.SetDragGeometry(dragobjects38)
    
    foundrelations55 = sketchDragGeometryBuilder17.FindRelations()
    
    sketchDragGeometryBuilder17.Destroy()
    
    markId229 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences14 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences14 = dimensionPreferences14.GetNarrowDimensionPreferences()
    
    option14 = narrowDimensionPreferences14.DimensionDisplayOption
    
    sketchLinearDimensionBuilder14 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder14 = sketchLinearDimensionBuilder14.Driving
    
    drivingValueBuilder14.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder14 = sketchLinearDimensionBuilder14.Measurement
    
    dimensionMeasurementBuilder14.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject27 = sketchLinearDimensionBuilder14.FirstAssociativity
    
    selectNXObject28 = sketchLinearDimensionBuilder14.SecondAssociativity
    
    point1_69 = NXOpen.Point3d(35.058526301099185, 3.333333333333333, 0.0)
    point2_69 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject27.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line13, NXOpen.View.Null, point1_69, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_69)
    
    point1_70 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_70 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject28.SetValue(NXOpen.InferSnapType.SnapType.Start, line1, NXOpen.View.Null, point1_70, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_70)
    
    originBuilder14 = sketchLinearDimensionBuilder14.Origin
    
    origin66 = NXOpen.Point3d(31.872334412337256, 1.6666666666666665, 0.0)
    originBuilder14.OriginPoint = origin66
    
    originBuilder14.SetInferRelativeToGeometry(True)
    
    nXObject82 = sketchLinearDimensionBuilder14.Commit()
    
    perpendicularDimension6 = nXObject82
    perpendicularDimension6.IsOriginCentered = True
    
    sketchLinearDimensionBuilder14.Destroy()
    
    narrowDimensionPreferences14.Dispose()
    dimensionPreferences14.Dispose()
    sketchFindMovableObjectsBuilder40 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject83 = sketchFindMovableObjectsBuilder40.Commit()
    
    sketchFindMovableObjectsBuilder40.Destroy()
    
    markId230 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId231 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder14 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension6)
    
    selectNXObjectList28 = sketchEditDimensionValueBuilder14.ExtraGeometries
    
    foundrelations56 = sketchEditDimensionValueBuilder14.FindRelations()
    
    sketchHelpedDimensionalConstraint14 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line11] [[WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line1] StartVertex]")
    sketchHelpedDimensionalConstraint14.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId231, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId231, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint14.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId232 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId232, None)
    
    markId233 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder14.DimValue = 4.0
    
    nXObject84 = sketchEditDimensionValueBuilder14.Commit()
    
    theSession.SetUndoMarkName(markId233, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId233, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId231, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId234 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId235 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint14.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId235, None)
    
    theSession.SetUndoMarkName(markId231, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder14.Destroy()
    
    theSession.DeleteUndoMark(markId234, None)
    
    theSession.SetUndoMarkVisibility(markId231, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId233, None)
    
    theSession.DeleteUndoMark(markId231, None)
    
    sketchFindMovableObjectsBuilder41 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject85 = sketchFindMovableObjectsBuilder41.Commit()
    
    sketchFindMovableObjectsBuilder41.Destroy()
    
    markId236 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder18 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects39 = [None] * 1 
    dragobjects39[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects39[0].Geometry = line16
    dragobjects39[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects39[0].PointIndex = 0
    sketchDragGeometryBuilder18.SetDragGeometry(dragobjects39)
    
    sketchDragGeometryBuilder18.SplineLinearScale = False
    
    foundrelations57 = sketchDragGeometryBuilder18.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects40 = [None] * 1 
    dragobjects40[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects40[0].Geometry = line16
    dragobjects40[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects40[0].PointIndex = 0
    sketchDragGeometryBuilder18.SetDragGeometry(dragobjects40)
    
    foundrelations58 = sketchDragGeometryBuilder18.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects41 = [None] * 1 
    dragobjects41[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects41[0].Geometry = line16
    dragobjects41[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects41[0].PointIndex = 0
    sketchDragGeometryBuilder18.SetDragGeometry(dragobjects41)
    
    foundrelations59 = sketchDragGeometryBuilder18.FindRelations()
    
    sketchDragGeometryBuilder18.Destroy()
    
    markId237 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences15 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences15 = dimensionPreferences15.GetNarrowDimensionPreferences()
    
    option15 = narrowDimensionPreferences15.DimensionDisplayOption
    
    sketchLinearDimensionBuilder15 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder15 = sketchLinearDimensionBuilder15.Driving
    
    drivingValueBuilder15.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder15 = sketchLinearDimensionBuilder15.Measurement
    
    dimensionMeasurementBuilder15.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject29 = sketchLinearDimensionBuilder15.FirstAssociativity
    
    selectNXObject30 = sketchLinearDimensionBuilder15.SecondAssociativity
    
    point1_75 = NXOpen.Point3d(34.0, 7.6434564351179155, 0.0)
    point2_75 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject29.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line16, NXOpen.View.Null, point1_75, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_75)
    
    point1_76 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_76 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject30.SetValue(NXOpen.InferSnapType.SnapType.End, line4, NXOpen.View.Null, point1_76, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_76)
    
    originBuilder15 = sketchLinearDimensionBuilder15.Origin
    
    origin69 = NXOpen.Point3d(17.0, 16.22847346872646, 0.0)
    originBuilder15.OriginPoint = origin69
    
    originBuilder15.SetInferRelativeToGeometry(True)
    
    nXObject86 = sketchLinearDimensionBuilder15.Commit()
    
    perpendicularDimension7 = nXObject86
    perpendicularDimension7.IsOriginCentered = True
    
    sketchLinearDimensionBuilder15.Destroy()
    
    narrowDimensionPreferences15.Dispose()
    dimensionPreferences15.Dispose()
    sketchFindMovableObjectsBuilder42 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject87 = sketchFindMovableObjectsBuilder42.Commit()
    
    sketchFindMovableObjectsBuilder42.Destroy()
    
    markId238 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId239 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder15 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension7)
    
    selectNXObjectList29 = sketchEditDimensionValueBuilder15.ExtraGeometries
    
    foundrelations60 = sketchEditDimensionValueBuilder15.FindRelations()
    
    sketchHelpedDimensionalConstraint15 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line14] [[WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line4] EndVertex]")
    sketchHelpedDimensionalConstraint15.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId239, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId239, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint15.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId240 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId240, None)
    
    markId241 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder15.DimValue = 55.0
    
    nXObject88 = sketchEditDimensionValueBuilder15.Commit()
    
    theSession.SetUndoMarkName(markId241, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId241, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId239, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId242 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId243 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint15.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId243, None)
    
    theSession.SetUndoMarkName(markId239, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder15.Destroy()
    
    theSession.DeleteUndoMark(markId242, None)
    
    theSession.SetUndoMarkVisibility(markId239, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId241, None)
    
    theSession.DeleteUndoMark(markId239, None)
    
    sketchFindMovableObjectsBuilder43 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject89 = sketchFindMovableObjectsBuilder43.Commit()
    
    sketchFindMovableObjectsBuilder43.Destroy()
    
    markId244 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder19 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects42 = [None] * 1 
    dragobjects42[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects42[0].Geometry = line14
    dragobjects42[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects42[0].PointIndex = 0
    sketchDragGeometryBuilder19.SetDragGeometry(dragobjects42)
    
    sketchDragGeometryBuilder19.SplineLinearScale = False
    
    foundrelations61 = sketchDragGeometryBuilder19.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects43 = [None] * 1 
    dragobjects43[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects43[0].Geometry = line14
    dragobjects43[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects43[0].PointIndex = 0
    sketchDragGeometryBuilder19.SetDragGeometry(dragobjects43)
    
    foundrelations62 = sketchDragGeometryBuilder19.FindRelations()
    
    sketchDragGeometryBuilder19.Destroy()
    
    markId245 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences16 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences16 = dimensionPreferences16.GetNarrowDimensionPreferences()
    
    option16 = narrowDimensionPreferences16.DimensionDisplayOption
    
    sketchLinearDimensionBuilder16 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder16 = sketchLinearDimensionBuilder16.Driving
    
    drivingValueBuilder16.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject31 = sketchLinearDimensionBuilder16.FirstAssociativity
    
    selectNXObject32 = sketchLinearDimensionBuilder16.SecondAssociativity
    
    point1_79 = NXOpen.Point3d(57.000000000000007, 4.0, 0.0)
    point2_79 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject31.SetValue(NXOpen.InferSnapType.SnapType.Start, line14, NXOpen.View.Null, point1_79, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_79)
    
    point1_80 = NXOpen.Point3d(57.000000000000007, 9.3333333333333321, 0.0)
    point2_80 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject32.SetValue(NXOpen.InferSnapType.SnapType.End, line14, NXOpen.View.Null, point1_80, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_80)
    
    dimensionMeasurementBuilder16 = sketchLinearDimensionBuilder16.Measurement
    
    dimensionMeasurementBuilder16.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder16 = sketchLinearDimensionBuilder16.Origin
    
    origin71 = NXOpen.Point3d(59.007050008668941, 6.6666666666666661, 0.0)
    originBuilder16.OriginPoint = origin71
    
    originBuilder16.SetInferRelativeToGeometry(True)
    
    nXObject90 = sketchLinearDimensionBuilder16.Commit()
    
    verticalDimension4 = nXObject90
    verticalDimension4.IsOriginCentered = True
    
    sketchLinearDimensionBuilder16.Destroy()
    
    narrowDimensionPreferences16.Dispose()
    dimensionPreferences16.Dispose()
    sketchFindMovableObjectsBuilder44 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject91 = sketchFindMovableObjectsBuilder44.Commit()
    
    sketchFindMovableObjectsBuilder44.Destroy()
    
    markId246 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId247 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder16 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension4)
    
    selectNXObjectList30 = sketchEditDimensionValueBuilder16.ExtraGeometries
    
    foundrelations63 = sketchEditDimensionValueBuilder16.FindRelations()
    
    sketchHelpedDimensionalConstraint16 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line12] StartVertex] [[Curve Line12] EndVertex]")
    sketchHelpedDimensionalConstraint16.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId247, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId247, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint16.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId248 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId248, None)
    
    markId249 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder16.DimValue = 6.0
    
    nXObject92 = sketchEditDimensionValueBuilder16.Commit()
    
    theSession.SetUndoMarkName(markId249, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId249, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId247, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId250 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId251 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint16.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId251, None)
    
    theSession.SetUndoMarkName(markId247, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder16.Destroy()
    
    theSession.DeleteUndoMark(markId250, None)
    
    theSession.SetUndoMarkVisibility(markId247, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId249, None)
    
    theSession.DeleteUndoMark(markId247, None)
    
    sketchFindMovableObjectsBuilder45 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject93 = sketchFindMovableObjectsBuilder45.Commit()
    
    sketchFindMovableObjectsBuilder45.Destroy()
    
    scaleAboutPoint156 = NXOpen.Point3d(21.772311239873218, -13.231546871386339, 0.0)
    viewCenter156 = NXOpen.Point3d(-21.772311239873233, 13.231546871386383, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint156, viewCenter156)
    
    scaleAboutPoint157 = NXOpen.Point3d(27.215389049841551, -16.539433589232928, 0.0)
    viewCenter157 = NXOpen.Point3d(-27.21538904984153, 16.539433589232974, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint157, viewCenter157)
    
    scaleAboutPoint158 = NXOpen.Point3d(34.019236312301906, -20.674291986541167, 0.0)
    viewCenter158 = NXOpen.Point3d(-34.019236312301913, 20.674291986541203, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint158, viewCenter158)
    
    scaleAboutPoint159 = NXOpen.Point3d(42.524045390377374, -25.842864983176469, 0.0)
    viewCenter159 = NXOpen.Point3d(-42.524045390377374, 25.842864983176511, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint159, viewCenter159)
    
    scaleAboutPoint160 = NXOpen.Point3d(53.15505673797167, -32.303581228970579, 0.0)
    viewCenter160 = NXOpen.Point3d(-53.155056737971741, 32.303581228970636, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint160, viewCenter160)
    
    scaleAboutPoint161 = NXOpen.Point3d(73.73643541395468, -33.356958877741363, 0.0)
    viewCenter161 = NXOpen.Point3d(-73.736435413954709, 33.356958877741384, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint161, viewCenter161)
    
    scaleAboutPoint162 = NXOpen.Point3d(58.989148331163733, -26.685567102193108, 0.0)
    viewCenter162 = NXOpen.Point3d(-58.989148331163733, 26.685567102193108, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint162, viewCenter162)
    
    scaleAboutPoint163 = NXOpen.Point3d(36.646738303902431, -29.300104445808799, 0.0)
    viewCenter163 = NXOpen.Point3d(-36.646738303902431, 29.300104445808799, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint163, viewCenter163)
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder7 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder7.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject94 = sketchWorkRegionBuilder7.Commit()
    
    sketchWorkRegionBuilder7.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId252 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId253 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder12 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section12 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder12.Section = section12
    
    extrudeBuilder12.AllowSelfIntersectingSection(True)
    
    expression38 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder12.DistanceTolerance = 0.01
    
    extrudeBuilder12.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies48 = [NXOpen.Body.Null] * 1 
    targetBodies48[0] = NXOpen.Body.Null
    extrudeBuilder12.BooleanOperation.SetTargetBodies(targetBodies48)
    
    extrudeBuilder12.Limits.StartExtend.Value.SetFormula("6")
    
    extrudeBuilder12.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder12.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies49 = [NXOpen.Body.Null] * 1 
    targetBodies49[0] = body1
    extrudeBuilder12.BooleanOperation.SetTargetBodies(targetBodies49)
    
    extrudeBuilder12.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder12.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder12.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder12.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder12 = extrudeBuilder12.SmartVolumeProfile
    
    smartVolumeProfileBuilder12.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder12.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId253, "Extrude Dialog")
    
    section12.DistanceTolerance = 0.01
    
    section12.ChainingTolerance = 0.0094999999999999998
    
    section12.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId254 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions7 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions7.SetSelectedFromInactive(False)
    
    curves6 = [NXOpen.ICurve.Null] * 8 
    curves6[0] = line13
    curves6[1] = line14
    curves6[2] = line15
    curves6[3] = line16
    curves6[4] = line17
    curves6[5] = line18
    curves6[6] = line19
    curves6[7] = line20
    seedPoint6 = NXOpen.Point3d(64.147146000000021, 7.4414379999999998, 0.0)
    regionBoundaryRule6 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch7, curves6, seedPoint6, 0.01, selectionIntentRuleOptions7)
    
    selectionIntentRuleOptions7.Dispose()
    selectionIntentRuleOptions8 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions8.SetSelectedFromInactive(False)
    
    curves7 = [NXOpen.ICurve.Null] * 8 
    curves7[0] = line13
    curves7[1] = line14
    curves7[2] = line15
    curves7[3] = line16
    curves7[4] = line17
    curves7[5] = line18
    curves7[6] = line19
    curves7[7] = line20
    seedPoint7 = NXOpen.Point3d(56.147145999999999, 7.4414379999999998, 0.0)
    regionBoundaryRule7 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch7, curves7, seedPoint7, 0.01, selectionIntentRuleOptions8)
    
    selectionIntentRuleOptions8.Dispose()
    section12.AllowSelfIntersection(True)
    
    section12.AllowDegenerateCurves(False)
    
    rules7 = [None] * 2 
    rules7[0] = regionBoundaryRule6
    rules7[1] = regionBoundaryRule7
    helpPoint7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section12.AddToSection(rules7, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint7, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId254, None)
    
    markId255 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId256 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId256, None)
    
    direction19 = workPart.Directions.CreateDirection(sketch7, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder12.Direction = direction19
    
    theSession.DeleteUndoMark(markId255, None)
    
    extrudeBuilder12.Limits.EndExtend.Value.SetFormula("-13")
    
    extrudeBuilder12.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder12.Limits.EndExtend.Value.SetFormula("-10")
    
    extrudeBuilder12.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Intersect
    
    targetBodies50 = [NXOpen.Body.Null] * 1 
    targetBodies50[0] = body1
    extrudeBuilder12.BooleanOperation.SetTargetBodies(targetBodies50)
    
    extrudeBuilder12.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies51 = [NXOpen.Body.Null] * 1 
    targetBodies51[0] = body1
    extrudeBuilder12.BooleanOperation.SetTargetBodies(targetBodies51)
    
    scaleAboutPoint164 = NXOpen.Point3d(-27.657915701058364, 9.248115562541452, 0.0)
    viewCenter164 = NXOpen.Point3d(27.657915701058542, -9.2481155625413791, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint164, viewCenter164)
    
    rotMatrix9 = NXOpen.Matrix3x3()
    
    rotMatrix9.Xx = 0.92725505469639624
    rotMatrix9.Xy = 0.36211964303400579
    rotMatrix9.Xz = -0.095223041691107499
    rotMatrix9.Yx = 0.09084897271738207
    rotMatrix9.Yy = 0.029129923817157743
    rotMatrix9.Yz = 0.99543855244540469
    rotMatrix9.Zx = 0.36324169322391719
    rotMatrix9.Zy = -0.93167634491132711
    rotMatrix9.Zz = -0.0058873284680439723
    translation9 = NXOpen.Point3d(-75.441780726173405, -35.894234885821554, 45.553094915787803)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix9, translation9, 1.9132557651349549)
    
    rotMatrix10 = NXOpen.Matrix3x3()
    
    rotMatrix10.Xx = 0.85276678783858251
    rotMatrix10.Xy = 0.51312804412434576
    rotMatrix10.Xz = -0.097408500104397569
    rotMatrix10.Yx = 0.15345816057872338
    rotMatrix10.Yy = -0.067890965665313302
    rotMatrix10.Yz = 0.98582017109248954
    rotMatrix10.Zx = 0.49923881911491941
    rotMatrix10.Zy = -0.85562282993977767
    rotMatrix10.Zz = -0.13663884650634889
    translation10 = NXOpen.Point3d(-80.032988780124981, -33.829532788553763, 32.830056464034698)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix10, translation10, 1.9132557651349549)
    
    markId257 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId257, None)
    
    markId258 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder12.ParentFeatureInternal = False
    
    feature14 = extrudeBuilder12.CommitFeature()
    
    theSession.DeleteUndoMark(markId258, None)
    
    theSession.SetUndoMarkName(markId253, "Extrude")
    
    expression39 = extrudeBuilder12.Limits.StartExtend.Value
    expression40 = extrudeBuilder12.Limits.EndExtend.Value
    extrudeBuilder12.Destroy()
    
    workPart.Expressions.Delete(expression38)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId259 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId260 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId261 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder8 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin72 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal8 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane19 = workPart.Planes.CreatePlane(origin72, normal8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder8.PlaneReference = plane19
    
    expression41 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression42 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder8 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder8 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder8.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId261, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder8.UseWorkPartOrigin = False
    
    coordinates17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point28 = workPart.Points.CreatePoint(coordinates17)
    
    origin73 = NXOpen.Point3d(0.0, 68.965449656829463, 8.9654496568294597)
    matrix11 = NXOpen.Matrix3x3()
    
    matrix11.Xx = 0.0
    matrix11.Xy = 1.0
    matrix11.Xz = 0.0
    matrix11.Yx = 0.0
    matrix11.Yy = 0.0
    matrix11.Yz = 1.0
    matrix11.Zx = 1.0
    matrix11.Zy = 0.0
    matrix11.Zz = 0.0
    plane20 = workPart.Planes.CreateFixedTypePlane(origin73, matrix11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point29 = workPart.Points.CreatePoint(coordinates18)
    
    origin74 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector11 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction20 = workPart.Directions.CreateDirection(origin74, vector11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin75 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector12 = NXOpen.Vector3d(0.0, 1.0, 0.0)
    direction21 = workPart.Directions.CreateDirection(origin75, vector12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin76 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix12 = NXOpen.Matrix3x3()
    
    matrix12.Xx = 0.0
    matrix12.Xy = 1.0
    matrix12.Xz = 0.0
    matrix12.Yx = 0.0
    matrix12.Yy = 0.0
    matrix12.Yz = 1.0
    matrix12.Zx = 1.0
    matrix12.Zy = 0.0
    matrix12.Zz = 0.0
    plane21 = workPart.Planes.CreateFixedTypePlane(origin76, matrix12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform8 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane21, direction21, point29, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem8 = workPart.CoordinateSystems.CreateCoordinateSystem(xform8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder8.CoordinateSystem = cartesianCoordinateSystem8
    
    datumAxis2 = workPart.Datums.FindObject("DATUM_CSYS(0) Y axis")
    simpleSketchInPlaceBuilder8.HorizontalReference.Value = datumAxis2
    
    point30 = simpleSketchInPlaceBuilder8.SketchOrigin
    
    simpleSketchInPlaceBuilder8.SketchOrigin = point30
    
    markId262 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId262, None)
    
    markId263 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject95 = simpleSketchInPlaceBuilder8.Commit()
    
    sketch8 = nXObject95
    feature15 = sketch8.Feature
    
    markId264 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs9 = theSession.UpdateManager.DoUpdate(markId264)
    
    sketch8.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder46 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject96 = sketchFindMovableObjectsBuilder46.Commit()
    
    sketchFindMovableObjectsBuilder46.Destroy()
    
    theSession.DeleteUndoMark(markId263, None)
    
    theSession.SetUndoMarkName(markId261, "Create Sketch")
    
    sketchInPlaceBuilder8.Destroy()
    
    sketchAlongPathBuilder8.Destroy()
    
    simpleSketchInPlaceBuilder8.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression42)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression41)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane19.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId260, None, True)
    
    markId265 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_005")
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Circle...
    # ----------------------------------------------
    markId266 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint165 = NXOpen.Point3d(13.967247429034597, -10.440863177149525, 0.0)
    viewCenter165 = NXOpen.Point3d(-13.967247429034432, 10.440863177149597, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint165, viewCenter165)
    
    scaleAboutPoint166 = NXOpen.Point3d(16.767611393766767, -13.051078971436908, 0.0)
    viewCenter166 = NXOpen.Point3d(-16.76761139376659, 13.051078971436997, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint166, viewCenter166)
    
    scaleAboutPoint167 = NXOpen.Point3d(17.502274779576123, -14.153074050150954, 0.0)
    viewCenter167 = NXOpen.Point3d(-17.502274779575973, 14.153074050151009, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint167, viewCenter167)
    
    scaleAboutPoint168 = NXOpen.Point3d(14.001819823660927, -11.322459240120763, 0.0)
    viewCenter168 = NXOpen.Point3d(-14.00181982366075, 11.322459240120821, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint168, viewCenter168)
    
    scaleAboutPoint169 = NXOpen.Point3d(11.201455858928753, -9.0579673920966108, 0.0)
    viewCenter169 = NXOpen.Point3d(-11.20145585892859, 9.057967392096657, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint169, viewCenter169)
    
    scaleAboutPoint170 = NXOpen.Point3d(8.9611646871430128, -7.2463739136772789, 0.0)
    viewCenter170 = NXOpen.Point3d(-8.9611646871428423, 7.2463739136773357, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint170, viewCenter170)
    
    scaleAboutPoint171 = NXOpen.Point3d(7.5229530706879766, -5.7970991309418158, 0.0)
    viewCenter171 = NXOpen.Point3d(-7.5229530706878105, 5.7970991309418842, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint171, viewCenter171)
    
    scaleAboutPoint172 = NXOpen.Point3d(5.4519283429927254, -2.6551599073015759, 0.0)
    viewCenter172 = NXOpen.Point3d(-5.4519283429925505, 2.6551599073016541, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint172, viewCenter172)
    
    markId267 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId267, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix1 = theSession.ActiveSketch.Orientation
    
    center1 = NXOpen.Point3d(0.0, 7.0, -6.0)
    arc1 = workPart.Curves.CreateArc(center1, nXMatrix1, 2.498354184995633, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    markId268 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.DeleteUndoMark(markId268, "Curve")
    
    sketchFindMovableObjectsBuilder47 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject97 = sketchFindMovableObjectsBuilder47.Commit()
    
    sketchFindMovableObjectsBuilder47.Destroy()
    
    markId269 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder20 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects44 = [None] * 1 
    dragobjects44[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects44[0].Geometry = arc1
    dragobjects44[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects44[0].PointIndex = 0
    sketchDragGeometryBuilder20.SetDragGeometry(dragobjects44)
    
    sketchDragGeometryBuilder20.SplineLinearScale = False
    
    foundrelations64 = sketchDragGeometryBuilder20.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects45 = [None] * 1 
    dragobjects45[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects45[0].Geometry = arc1
    dragobjects45[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects45[0].PointIndex = 0
    sketchDragGeometryBuilder20.SetDragGeometry(dragobjects45)
    
    foundrelations65 = sketchDragGeometryBuilder20.FindRelations()
    
    sketchDragGeometryBuilder20.Destroy()
    
    markId270 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences17 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences17 = dimensionPreferences17.GetNarrowDimensionPreferences()
    
    option17 = narrowDimensionPreferences17.DimensionDisplayOption
    
    sketchRadialDimensionBuilder1 = workPart.Sketches.CreateRadialDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder17 = sketchRadialDimensionBuilder1.Driving
    
    drivingValueBuilder17.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject33 = sketchRadialDimensionBuilder1.FirstAssociativity
    
    point1_82 = NXOpen.Point3d(0.0, 7.0, -6.0)
    point2_82 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject33.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, NXOpen.View.Null, point1_82, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_82)
    
    dimensionMeasurementBuilder17 = sketchRadialDimensionBuilder1.Measurement
    
    dimensionMeasurementBuilder17.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Diametral
    
    originBuilder17 = sketchRadialDimensionBuilder1.Origin
    
    origin78 = NXOpen.Point3d(0.0, 11.761777897598936, -3.6245985803132319)
    originBuilder17.OriginPoint = origin78
    
    originBuilder17.SetInferRelativeToGeometry(True)
    
    nXObject98 = sketchRadialDimensionBuilder1.Commit()
    
    sketchRadialDimensionBuilder1.Destroy()
    
    narrowDimensionPreferences17.Dispose()
    dimensionPreferences17.Dispose()
    sketchFindMovableObjectsBuilder48 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject99 = sketchFindMovableObjectsBuilder48.Commit()
    
    sketchFindMovableObjectsBuilder48.Destroy()
    
    markId271 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId272 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    diameterDimension1 = nXObject98
    sketchEditDimensionValueBuilder17 = workPart.Sketches.CreateEditDimensionValueBuilder(diameterDimension1)
    
    selectNXObjectList31 = sketchEditDimensionValueBuilder17.ExtraGeometries
    
    foundrelations66 = sketchEditDimensionValueBuilder17.FindRelations()
    
    sketchDimensionalConstraint1 = theSession.ActiveSketch.FindObject("DiameterDim [Curve Arc1]")
    sketchDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId272, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId272, None, NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId273 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId273, None)
    
    markId274 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder17.DimValue = 3.0
    
    theSession.ActiveSketch.Scale(0.60039525580717445)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin79 = NXOpen.Point3d(0.0, 7.0617156495760849, -2.1761917918254845)
    diameterDimension1.AnnotationOrigin = origin79
    
    sketchEditDimensionValueBuilder17.RestoreOperation()
    
    sketchEditDimensionValueBuilder17.LoadExtraGeometry()
    
    selectNXObjectList32 = sketchEditDimensionValueBuilder17.ExtraGeometries
    
    foundrelations67 = sketchEditDimensionValueBuilder17.FindRelations()
    
    nXObject100 = sketchEditDimensionValueBuilder17.Commit()
    
    theSession.SetUndoMarkName(markId274, "Edit Dimension Value - Diameter")
    
    theSession.SetUndoMarkVisibility(markId274, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId272, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId275 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId276 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId276, None)
    
    theSession.SetUndoMarkName(markId272, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder17.Destroy()
    
    theSession.DeleteUndoMark(markId275, None)
    
    theSession.SetUndoMarkVisibility(markId272, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId274, None)
    
    theSession.DeleteUndoMark(markId272, None)
    
    sketchFindMovableObjectsBuilder49 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject101 = sketchFindMovableObjectsBuilder49.Commit()
    
    sketchFindMovableObjectsBuilder49.Destroy()
    
    markId277 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder21 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects46 = [None] * 1 
    dragobjects46[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects46[0].Geometry = arc1
    dragobjects46[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects46[0].PointIndex = 0
    sketchDragGeometryBuilder21.SetDragGeometry(dragobjects46)
    
    sketchDragGeometryBuilder21.SplineLinearScale = False
    
    foundrelations68 = sketchDragGeometryBuilder21.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects47 = [None] * 1 
    dragobjects47[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects47[0].Geometry = arc1
    dragobjects47[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects47[0].PointIndex = -1475379168
    sketchDragGeometryBuilder21.SetDragGeometry(dragobjects47)
    
    foundrelations69 = sketchDragGeometryBuilder21.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects48 = [None] * 1 
    dragobjects48[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects48[0].Geometry = arc1
    dragobjects48[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects48[0].PointIndex = -1475379088
    sketchDragGeometryBuilder21.SetDragGeometry(dragobjects48)
    
    foundrelations70 = sketchDragGeometryBuilder21.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects49 = [None] * 1 
    dragobjects49[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects49[0].Geometry = arc1
    dragobjects49[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects49[0].PointIndex = -1475378416
    sketchDragGeometryBuilder21.SetDragGeometry(dragobjects49)
    
    foundrelations71 = sketchDragGeometryBuilder21.FindRelations()
    
    sketchDragGeometryBuilder21.Destroy()
    
    markId278 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences18 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences18 = dimensionPreferences18.GetNarrowDimensionPreferences()
    
    option18 = narrowDimensionPreferences18.DimensionDisplayOption
    
    sketchLinearDimensionBuilder17 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder18 = sketchLinearDimensionBuilder17.Driving
    
    drivingValueBuilder18.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder18 = sketchLinearDimensionBuilder17.Measurement
    
    dimensionMeasurementBuilder18.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject34 = sketchLinearDimensionBuilder17.FirstAssociativity
    
    selectNXObject35 = sketchLinearDimensionBuilder17.SecondAssociativity
    
    extrude3 = feature14
    edge5 = extrude3.FindObject("EDGE * 130 * 180 {(65,4,-10)(65,7,-10)(65,10,-10) EXTRUDE(2)}")
    point1_85 = NXOpen.Point3d(0.0, 6.150899188589845, -10.0)
    point2_85 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject34.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge5, NXOpen.View.Null, point1_85, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_85)
    
    point1_86 = NXOpen.Point3d(0.0, 4.2027667906502213, -3.602371534843047)
    point2_86 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject35.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, NXOpen.View.Null, point1_86, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_86)
    
    originBuilder18 = sketchLinearDimensionBuilder17.Origin
    
    origin81 = NXOpen.Point3d(0.0, 4.2027667906502213, -6.8011857674215239)
    originBuilder18.OriginPoint = origin81
    
    originBuilder18.SetInferRelativeToGeometry(True)
    
    nXObject102 = sketchLinearDimensionBuilder17.Commit()
    
    perpendicularDimension8 = nXObject102
    perpendicularDimension8.IsOriginCentered = True
    
    sketchLinearDimensionBuilder17.Destroy()
    
    narrowDimensionPreferences18.Dispose()
    dimensionPreferences18.Dispose()
    sketchFindMovableObjectsBuilder50 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject103 = sketchFindMovableObjectsBuilder50.Commit()
    
    sketchFindMovableObjectsBuilder50.Destroy()
    
    markId279 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId280 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder18 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension8)
    
    selectNXObjectList33 = sketchEditDimensionValueBuilder18.ExtraGeometries
    
    foundrelations72 = sketchEditDimensionValueBuilder18.FindRelations()
    
    sketchHelpedDimensionalConstraint17 = theSession.ActiveSketch.FindObject("PerpendicularDim [WorkPart|.Features|EXTRUDE(8)|EDGE * 130 * 180 {(65,4,-10)(65,7,-10)(65,10,-10) EXTRUDE(2)}] [[Curve Arc1] ArcCenter]")
    sketchHelpedDimensionalConstraint17.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId280, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId280, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint17.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId281 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId281, None)
    
    markId282 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder18.DimValue = 4.0
    
    nXObject104 = sketchEditDimensionValueBuilder18.Commit()
    
    theSession.SetUndoMarkName(markId282, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId282, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId280, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId283 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId284 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint17.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId284, None)
    
    theSession.SetUndoMarkName(markId280, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder18.Destroy()
    
    theSession.DeleteUndoMark(markId283, None)
    
    theSession.SetUndoMarkVisibility(markId280, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId282, None)
    
    theSession.DeleteUndoMark(markId280, None)
    
    sketchFindMovableObjectsBuilder51 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject105 = sketchFindMovableObjectsBuilder51.Commit()
    
    sketchFindMovableObjectsBuilder51.Destroy()
    
    markId285 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder22 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects50 = [None] * 1 
    dragobjects50[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects50[0].Geometry = arc1
    dragobjects50[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects50[0].PointIndex = 0
    sketchDragGeometryBuilder22.SetDragGeometry(dragobjects50)
    
    sketchDragGeometryBuilder22.SplineLinearScale = False
    
    foundrelations73 = sketchDragGeometryBuilder22.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects51 = [None] * 1 
    dragobjects51[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects51[0].Geometry = arc1
    dragobjects51[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects51[0].PointIndex = -1475378960
    sketchDragGeometryBuilder22.SetDragGeometry(dragobjects51)
    
    foundrelations74 = sketchDragGeometryBuilder22.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects52 = [None] * 1 
    dragobjects52[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects52[0].Geometry = arc1
    dragobjects52[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects52[0].PointIndex = -1475379040
    sketchDragGeometryBuilder22.SetDragGeometry(dragobjects52)
    
    foundrelations75 = sketchDragGeometryBuilder22.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects53 = [None] * 1 
    dragobjects53[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects53[0].Geometry = arc1
    dragobjects53[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects53[0].PointIndex = -1475379168
    sketchDragGeometryBuilder22.SetDragGeometry(dragobjects53)
    
    foundrelations76 = sketchDragGeometryBuilder22.FindRelations()
    
    sketchDragGeometryBuilder22.Destroy()
    
    markId286 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences19 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences19 = dimensionPreferences19.GetNarrowDimensionPreferences()
    
    option19 = narrowDimensionPreferences19.DimensionDisplayOption
    
    sketchLinearDimensionBuilder18 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder19 = sketchLinearDimensionBuilder18.Driving
    
    drivingValueBuilder19.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder19 = sketchLinearDimensionBuilder18.Measurement
    
    dimensionMeasurementBuilder19.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject36 = sketchLinearDimensionBuilder18.FirstAssociativity
    
    selectNXObject37 = sketchLinearDimensionBuilder18.SecondAssociativity
    
    edge7 = extrude3.FindObject("EDGE * 180 * 190 {(65,10,-10)(65,10,-5)(65,10,0) EXTRUDE(2)}")
    point1_89 = NXOpen.Point3d(0.0, 10.0, -6.4108559382640014)
    point2_89 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject36.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge7, NXOpen.View.Null, point1_89, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_89)
    
    point1_90 = NXOpen.Point3d(0.0, 4.2027667906502213, -6.0)
    point2_90 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject37.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, NXOpen.View.Null, point1_90, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_90)
    
    originBuilder19 = sketchLinearDimensionBuilder18.Origin
    
    origin83 = NXOpen.Point3d(0.0, 7.1013833953251106, -6.0)
    originBuilder19.OriginPoint = origin83
    
    originBuilder19.SetInferRelativeToGeometry(True)
    
    nXObject106 = sketchLinearDimensionBuilder18.Commit()
    
    perpendicularDimension9 = nXObject106
    perpendicularDimension9.IsOriginCentered = True
    
    sketchLinearDimensionBuilder18.Destroy()
    
    narrowDimensionPreferences19.Dispose()
    dimensionPreferences19.Dispose()
    sketchFindMovableObjectsBuilder52 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject107 = sketchFindMovableObjectsBuilder52.Commit()
    
    sketchFindMovableObjectsBuilder52.Destroy()
    
    markId287 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId288 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder19 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension9)
    
    selectNXObjectList34 = sketchEditDimensionValueBuilder19.ExtraGeometries
    
    foundrelations77 = sketchEditDimensionValueBuilder19.FindRelations()
    
    sketchHelpedDimensionalConstraint18 = theSession.ActiveSketch.FindObject("PerpendicularDim [WorkPart|.Features|EXTRUDE(8)|EDGE * 180 * 190 {(65,10,-10)(65,10,-5)(65,10,0) EXTRUDE(2)}] [[Curve Arc1] ArcCenter]")
    sketchHelpedDimensionalConstraint18.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId288, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId288, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint18.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId289 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId289, None)
    
    markId290 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder19.DimValue = 3.0
    
    nXObject108 = sketchEditDimensionValueBuilder19.Commit()
    
    theSession.SetUndoMarkName(markId290, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId290, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId288, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId291 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    markId292 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint18.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId292, None)
    
    theSession.SetUndoMarkName(markId288, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder19.Destroy()
    
    theSession.DeleteUndoMark(markId291, None)
    
    theSession.SetUndoMarkVisibility(markId288, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId290, None)
    
    theSession.DeleteUndoMark(markId288, None)
    
    sketchFindMovableObjectsBuilder53 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject109 = sketchFindMovableObjectsBuilder53.Commit()
    
    sketchFindMovableObjectsBuilder53.Destroy()
    
    sketchWorkRegionBuilder8 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder8.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject110 = sketchWorkRegionBuilder8.Commit()
    
    sketchWorkRegionBuilder8.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId293 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId294 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder13 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section13 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder13.Section = section13
    
    extrudeBuilder13.AllowSelfIntersectingSection(True)
    
    expression43 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder13.DistanceTolerance = 0.01
    
    extrudeBuilder13.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies52 = [NXOpen.Body.Null] * 1 
    targetBodies52[0] = NXOpen.Body.Null
    extrudeBuilder13.BooleanOperation.SetTargetBodies(targetBodies52)
    
    extrudeBuilder13.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder13.Limits.EndExtend.Value.SetFormula("-10")
    
    extrudeBuilder13.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies53 = [NXOpen.Body.Null] * 1 
    targetBodies53[0] = body1
    extrudeBuilder13.BooleanOperation.SetTargetBodies(targetBodies53)
    
    extrudeBuilder13.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder13.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder13.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder13.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder13 = extrudeBuilder13.SmartVolumeProfile
    
    smartVolumeProfileBuilder13.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder13.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId294, "Extrude Dialog")
    
    section13.DistanceTolerance = 0.01
    
    section13.ChainingTolerance = 0.0094999999999999998
    
    section13.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId295 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions9 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions9.SetSelectedFromInactive(False)
    
    curves8 = [NXOpen.ICurve.Null] * 1 
    curves8[0] = arc1
    seedPoint8 = NXOpen.Point3d(0.0, 6.8024474053278823, -6.0984370321532682)
    regionBoundaryRule8 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch8, curves8, seedPoint8, 0.01, selectionIntentRuleOptions9)
    
    selectionIntentRuleOptions9.Dispose()
    section13.AllowSelfIntersection(True)
    
    section13.AllowDegenerateCurves(False)
    
    rules8 = [None] * 1 
    rules8[0] = regionBoundaryRule8
    helpPoint8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section13.AddToSection(rules8, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint8, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId295, None)
    
    markId296 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId297 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId297, None)
    
    direction22 = workPart.Directions.CreateDirection(sketch8, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder13.Direction = direction22
    
    theSession.DeleteUndoMark(markId296, None)
    
    extrudeBuilder13.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies54 = [NXOpen.Body.Null] * 1 
    targetBodies54[0] = body1
    extrudeBuilder13.BooleanOperation.SetTargetBodies(targetBodies54)
    
    extrudeBuilder13.Limits.EndExtend.Value.SetFormula("-100")
    
    extrudeBuilder13.Limits.EndExtend.Value.SetFormula("-100")
    
    extrudeBuilder13.Limits.EndExtend.Value.SetFormula("100")
    
    markId298 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId298, None)
    
    markId299 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder13.ParentFeatureInternal = False
    
    feature16 = extrudeBuilder13.CommitFeature()
    
    theSession.DeleteUndoMark(markId299, None)
    
    theSession.SetUndoMarkName(markId294, "Extrude")
    
    expression44 = extrudeBuilder13.Limits.StartExtend.Value
    expression45 = extrudeBuilder13.Limits.EndExtend.Value
    extrudeBuilder13.Destroy()
    
    workPart.Expressions.Delete(expression43)
    
    rotMatrix11 = NXOpen.Matrix3x3()
    
    rotMatrix11.Xx = 0.83205622214260877
    rotMatrix11.Xy = 0.54749670945274465
    rotMatrix11.Xz = -0.089049403884503761
    rotMatrix11.Yx = 0.021307393511877437
    rotMatrix11.Yy = 0.12887291202484399
    rotMatrix11.Yz = 0.99143217999415645
    rotMatrix11.Zx = 0.55428191218503409
    rotMatrix11.Zy = -0.82682472488711456
    rotMatrix11.Zz = 0.095563780481140989
    translation11 = NXOpen.Point3d(-80.852474758070485, -37.706319425952444, 27.799584576668032)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix11, translation11, 1.9132557651349547)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId300 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId301 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId302 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder9 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin84 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal9 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane22 = workPart.Planes.CreatePlane(origin84, normal9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder9.PlaneReference = plane22
    
    expression46 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression47 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder9 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder9 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder9.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId302, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder9.UseWorkPartOrigin = False
    
    coordinates19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point31 = workPart.Points.CreatePoint(coordinates19)
    
    origin85 = NXOpen.Point3d(68.965449656829463, 68.965449656829463, 0.0)
    matrix13 = NXOpen.Matrix3x3()
    
    matrix13.Xx = 1.0
    matrix13.Xy = 0.0
    matrix13.Xz = 0.0
    matrix13.Yx = 0.0
    matrix13.Yy = 1.0
    matrix13.Yz = 0.0
    matrix13.Zx = 0.0
    matrix13.Zy = 0.0
    matrix13.Zz = 1.0
    plane23 = workPart.Planes.CreateFixedTypePlane(origin85, matrix13, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates20 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point32 = workPart.Points.CreatePoint(coordinates20)
    
    origin86 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector13 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction23 = workPart.Directions.CreateDirection(origin86, vector13, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin87 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector14 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction24 = workPart.Directions.CreateDirection(origin87, vector14, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin88 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix14 = NXOpen.Matrix3x3()
    
    matrix14.Xx = 1.0
    matrix14.Xy = 0.0
    matrix14.Xz = 0.0
    matrix14.Yx = 0.0
    matrix14.Yy = 1.0
    matrix14.Yz = 0.0
    matrix14.Zx = 0.0
    matrix14.Zy = 0.0
    matrix14.Zz = 1.0
    plane24 = workPart.Planes.CreateFixedTypePlane(origin88, matrix14, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform9 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane24, direction24, point32, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem9 = workPart.CoordinateSystems.CreateCoordinateSystem(xform9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder9.CoordinateSystem = cartesianCoordinateSystem9
    
    simpleSketchInPlaceBuilder9.HorizontalReference.Value = datumAxis1
    
    point33 = simpleSketchInPlaceBuilder9.SketchOrigin
    
    simpleSketchInPlaceBuilder9.SketchOrigin = point33
    
    markId303 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId303, None)
    
    markId304 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject111 = simpleSketchInPlaceBuilder9.Commit()
    
    sketch9 = nXObject111
    feature17 = sketch9.Feature
    
    markId305 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs10 = theSession.UpdateManager.DoUpdate(markId305)
    
    sketch9.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder54 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject112 = sketchFindMovableObjectsBuilder54.Commit()
    
    sketchFindMovableObjectsBuilder54.Destroy()
    
    theSession.DeleteUndoMark(markId304, None)
    
    theSession.SetUndoMarkName(markId302, "Create Sketch")
    
    sketchInPlaceBuilder9.Destroy()
    
    sketchAlongPathBuilder9.Destroy()
    
    simpleSketchInPlaceBuilder9.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression47)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression46)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane22.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId301, None, True)
    
    markId306 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_006")
    
    scaleAboutPoint173 = NXOpen.Point3d(41.348583973082462, 16.940473366898342, 0.0)
    viewCenter173 = NXOpen.Point3d(-41.348583973082299, -16.940473366898271, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint173, viewCenter173)
    
    scaleAboutPoint174 = NXOpen.Point3d(52.031453912616293, 21.175591708622914, 0.0)
    viewCenter174 = NXOpen.Point3d(-52.031453912616115, -21.175591708622839, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint174, viewCenter174)
    
    scaleAboutPoint175 = NXOpen.Point3d(65.255394857184825, 26.685567102193151, 0.0)
    viewCenter175 = NXOpen.Point3d(-65.255394857184669, -26.685567102193097, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint175, viewCenter175)
    
    scaleAboutPoint176 = NXOpen.Point3d(81.839340404499211, 33.627055710759564, 0.0)
    viewCenter176 = NXOpen.Point3d(-81.839340404499026, -33.627055710759514, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint176, viewCenter176)
    
    scaleAboutPoint177 = NXOpen.Point3d(102.63679654689668, 42.709061720994825, 0.0)
    viewCenter177 = NXOpen.Point3d(-102.63679654689645, -42.709061720994768, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint177, viewCenter177)
    
    scaleAboutPoint178 = NXOpen.Point3d(194.55412503338542, 135.25942965986991, 0.0)
    viewCenter178 = NXOpen.Point3d(-194.55412503338522, -135.25942965986985, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint178, viewCenter178)
    
    scaleAboutPoint179 = NXOpen.Point3d(158.00664731561722, 109.5580278929867, 0.0)
    viewCenter179 = NXOpen.Point3d(-158.00664731561699, -109.55802789298659, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint179, viewCenter179)
    
    scaleAboutPoint180 = NXOpen.Point3d(126.67541468551192, 87.916519147407499, 0.0)
    viewCenter180 = NXOpen.Point3d(-126.67541468551168, -87.916519147407385, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint180, viewCenter180)
    
    scaleAboutPoint181 = NXOpen.Point3d(101.34033174840955, 70.333215317926019, 0.0)
    viewCenter181 = NXOpen.Point3d(-101.34033174840928, -70.333215317925891, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint181, viewCenter181)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId307 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId308 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId308, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint21 = NXOpen.Point3d(54.0, 57.0, 0.0)
    endPoint21 = NXOpen.Point3d(64.0, 57.0, 0.0)
    line21 = workPart.Curves.CreateLine(startPoint21, endPoint21)
    
    startPoint22 = NXOpen.Point3d(64.0, 57.0, 0.0)
    endPoint22 = NXOpen.Point3d(64.0, 54.0, 0.0)
    line22 = workPart.Curves.CreateLine(startPoint22, endPoint22)
    
    startPoint23 = NXOpen.Point3d(64.0, 54.0, 0.0)
    endPoint23 = NXOpen.Point3d(54.0, 54.0, 0.0)
    line23 = workPart.Curves.CreateLine(startPoint23, endPoint23)
    
    startPoint24 = NXOpen.Point3d(54.0, 54.0, 0.0)
    endPoint24 = NXOpen.Point3d(54.0, 57.0, 0.0)
    line24 = workPart.Curves.CreateLine(startPoint24, endPoint24)
    
    theSession.ActiveSketch.AddGeometry(line21, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line22, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line23, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line24, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_21 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_21.Geometry = line21
    conGeom1_21.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_21.SplineDefiningPointIndex = 0
    conGeom2_21 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_21.Geometry = line22
    conGeom2_21.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_21.SplineDefiningPointIndex = 0
    sketchGeometricConstraint21 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_21, conGeom2_21)
    
    conGeom1_22 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_22.Geometry = line22
    conGeom1_22.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_22.SplineDefiningPointIndex = 0
    conGeom2_22 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_22.Geometry = line23
    conGeom2_22.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_22.SplineDefiningPointIndex = 0
    sketchGeometricConstraint22 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_22, conGeom2_22)
    
    conGeom1_23 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_23.Geometry = line23
    conGeom1_23.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_23.SplineDefiningPointIndex = 0
    conGeom2_23 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_23.Geometry = line24
    conGeom2_23.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_23.SplineDefiningPointIndex = 0
    sketchGeometricConstraint23 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_23, conGeom2_23)
    
    conGeom1_24 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_24.Geometry = line24
    conGeom1_24.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_24.SplineDefiningPointIndex = 0
    conGeom2_24 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_24.Geometry = line21
    conGeom2_24.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_24.SplineDefiningPointIndex = 0
    sketchGeometricConstraint24 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_24, conGeom2_24)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms11 = [NXOpen.SmartObject.Null] * 4 
    geoms11[0] = line21
    geoms11[1] = line22
    geoms11[2] = line23
    geoms11[3] = line24
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms11)
    
    geoms12 = [NXOpen.SmartObject.Null] * 4 
    geoms12[0] = line21
    geoms12[1] = line22
    geoms12[2] = line23
    geoms12[3] = line24
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms12)
    
    objects11 = [NXOpen.NXObject.Null] * 4 
    objects11[0] = sketchGeometricConstraint21
    objects11[1] = sketchGeometricConstraint22
    objects11[2] = sketchGeometricConstraint23
    objects11[3] = sketchGeometricConstraint24
    errorList6 = theSession.ActiveSketch.DeleteObjects(objects11)
    
    errorList6.Dispose()
    markId309 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId309, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint25 = NXOpen.Point3d(54.0, 64.0, 0.0)
    endPoint25 = NXOpen.Point3d(64.0, 64.0, 0.0)
    line25 = workPart.Curves.CreateLine(startPoint25, endPoint25)
    
    startPoint26 = NXOpen.Point3d(64.0, 64.0, 0.0)
    endPoint26 = NXOpen.Point3d(64.0, 60.0, 0.0)
    line26 = workPart.Curves.CreateLine(startPoint26, endPoint26)
    
    startPoint27 = NXOpen.Point3d(64.0, 60.0, 0.0)
    endPoint27 = NXOpen.Point3d(54.0, 60.0, 0.0)
    line27 = workPart.Curves.CreateLine(startPoint27, endPoint27)
    
    startPoint28 = NXOpen.Point3d(54.0, 60.0, 0.0)
    endPoint28 = NXOpen.Point3d(54.0, 64.0, 0.0)
    line28 = workPart.Curves.CreateLine(startPoint28, endPoint28)
    
    theSession.ActiveSketch.AddGeometry(line25, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line26, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line27, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line28, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_25 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_25.Geometry = line25
    conGeom1_25.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_25.SplineDefiningPointIndex = 0
    conGeom2_25 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_25.Geometry = line26
    conGeom2_25.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_25.SplineDefiningPointIndex = 0
    sketchGeometricConstraint25 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_25, conGeom2_25)
    
    conGeom1_26 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_26.Geometry = line26
    conGeom1_26.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_26.SplineDefiningPointIndex = 0
    conGeom2_26 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_26.Geometry = line27
    conGeom2_26.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_26.SplineDefiningPointIndex = 0
    sketchGeometricConstraint26 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_26, conGeom2_26)
    
    conGeom1_27 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_27.Geometry = line27
    conGeom1_27.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_27.SplineDefiningPointIndex = 0
    conGeom2_27 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_27.Geometry = line28
    conGeom2_27.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_27.SplineDefiningPointIndex = 0
    sketchGeometricConstraint27 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_27, conGeom2_27)
    
    conGeom1_28 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_28.Geometry = line28
    conGeom1_28.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_28.SplineDefiningPointIndex = 0
    conGeom2_28 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_28.Geometry = line25
    conGeom2_28.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_28.SplineDefiningPointIndex = 0
    sketchGeometricConstraint28 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_28, conGeom2_28)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms13 = [NXOpen.SmartObject.Null] * 4 
    geoms13[0] = line25
    geoms13[1] = line26
    geoms13[2] = line27
    geoms13[3] = line28
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms13)
    
    geoms14 = [NXOpen.SmartObject.Null] * 4 
    geoms14[0] = line25
    geoms14[1] = line26
    geoms14[2] = line27
    geoms14[3] = line28
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms14)
    
    objects12 = [NXOpen.NXObject.Null] * 4 
    objects12[0] = sketchGeometricConstraint25
    objects12[1] = sketchGeometricConstraint26
    objects12[2] = sketchGeometricConstraint27
    objects12[3] = sketchGeometricConstraint28
    errorList7 = theSession.ActiveSketch.DeleteObjects(objects12)
    
    errorList7.Dispose()
    sketchFindMovableObjectsBuilder55 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject113 = sketchFindMovableObjectsBuilder55.Commit()
    
    sketchFindMovableObjectsBuilder55.Destroy()
    
    markId310 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder23 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects54 = [None] * 1 
    dragobjects54[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects54[0].Geometry = line28
    dragobjects54[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects54[0].PointIndex = 0
    sketchDragGeometryBuilder23.SetDragGeometry(dragobjects54)
    
    sketchDragGeometryBuilder23.SplineLinearScale = False
    
    foundrelations78 = sketchDragGeometryBuilder23.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects55 = [None] * 1 
    dragobjects55[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects55[0].Geometry = line28
    dragobjects55[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects55[0].PointIndex = 0
    sketchDragGeometryBuilder23.SetDragGeometry(dragobjects55)
    
    foundrelations79 = sketchDragGeometryBuilder23.FindRelations()
    
    sketchDragGeometryBuilder23.Destroy()
    
    markId311 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences20 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences20 = dimensionPreferences20.GetNarrowDimensionPreferences()
    
    option20 = narrowDimensionPreferences20.DimensionDisplayOption
    
    sketchLinearDimensionBuilder19 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder20 = sketchLinearDimensionBuilder19.Driving
    
    drivingValueBuilder20.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject38 = sketchLinearDimensionBuilder19.FirstAssociativity
    
    selectNXObject39 = sketchLinearDimensionBuilder19.SecondAssociativity
    
    point1_93 = NXOpen.Point3d(54.0, 60.0, 0.0)
    point2_93 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject38.SetValue(NXOpen.InferSnapType.SnapType.Start, line28, NXOpen.View.Null, point1_93, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_93)
    
    point1_94 = NXOpen.Point3d(54.0, 64.0, 0.0)
    point2_94 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject39.SetValue(NXOpen.InferSnapType.SnapType.End, line28, NXOpen.View.Null, point1_94, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_94)
    
    dimensionMeasurementBuilder20 = sketchLinearDimensionBuilder19.Measurement
    
    dimensionMeasurementBuilder20.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder20 = sketchLinearDimensionBuilder19.Origin
    
    origin90 = NXOpen.Point3d(48.119970677727736, 62.0, 0.0)
    originBuilder20.OriginPoint = origin90
    
    originBuilder20.SetInferRelativeToGeometry(True)
    
    nXObject114 = sketchLinearDimensionBuilder19.Commit()
    
    verticalDimension5 = nXObject114
    verticalDimension5.IsOriginCentered = True
    
    sketchLinearDimensionBuilder19.Destroy()
    
    narrowDimensionPreferences20.Dispose()
    dimensionPreferences20.Dispose()
    sketchFindMovableObjectsBuilder56 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject115 = sketchFindMovableObjectsBuilder56.Commit()
    
    sketchFindMovableObjectsBuilder56.Destroy()
    
    markId312 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId313 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder20 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension5)
    
    selectNXObjectList35 = sketchEditDimensionValueBuilder20.ExtraGeometries
    
    foundrelations80 = sketchEditDimensionValueBuilder20.FindRelations()
    
    sketchHelpedDimensionalConstraint19 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line28] StartVertex] [[Curve Line28] EndVertex]")
    sketchHelpedDimensionalConstraint19.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId313, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId313, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint19.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId314 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId314, None)
    
    markId315 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder20.DimValue = 2.0
    
    theSession.ActiveSketch.Scale(0.5)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin91 = NXOpen.Point3d(24.059985338863868, 31.0, 0.0)
    verticalDimension5.AnnotationOrigin = origin91
    
    sketchEditDimensionValueBuilder20.RestoreOperation()
    
    sketchEditDimensionValueBuilder20.LoadExtraGeometry()
    
    selectNXObjectList36 = sketchEditDimensionValueBuilder20.ExtraGeometries
    
    foundrelations81 = sketchEditDimensionValueBuilder20.FindRelations()
    
    nXObject116 = sketchEditDimensionValueBuilder20.Commit()
    
    theSession.SetUndoMarkName(markId315, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId315, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId313, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId316 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    scaleAboutPoint182 = NXOpen.Point3d(-2.2472056507108564, -17.718352245990474, 0.0)
    viewCenter182 = NXOpen.Point3d(2.2472056507111513, 17.718352245990637, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint182, viewCenter182)
    
    scaleAboutPoint183 = NXOpen.Point3d(-1.797764520568685, -14.174681796792367, 0.0)
    viewCenter183 = NXOpen.Point3d(1.7977645205689443, 14.17468179679252, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint183, viewCenter183)
    
    scaleAboutPoint184 = NXOpen.Point3d(-1.4382116164549195, -11.339745437433884, 0.0)
    viewCenter184 = NXOpen.Point3d(1.4382116164551648, 11.339745437434024, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint184, viewCenter184)
    
    scaleAboutPoint185 = NXOpen.Point3d(-1.1505692931639055, -9.0717963499470926, 0.0)
    viewCenter185 = NXOpen.Point3d(1.1505692931641622, 9.0717963499472347, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint185, viewCenter185)
    
    scaleAboutPoint186 = NXOpen.Point3d(-0.92045543453110035, -7.3282413441523797, 0.0)
    viewCenter186 = NXOpen.Point3d(0.92045543453135392, 7.3282413441525183, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint186, viewCenter186)
    
    scaleAboutPoint187 = NXOpen.Point3d(-0.73636434762486569, -5.8625930753218833, 0.0)
    viewCenter187 = NXOpen.Point3d(0.73636434762511682, 5.8625930753220237, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint187, viewCenter187)
    
    markId317 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint19.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId317, None)
    
    theSession.SetUndoMarkName(markId313, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder20.Destroy()
    
    theSession.DeleteUndoMark(markId316, None)
    
    theSession.SetUndoMarkVisibility(markId313, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId315, None)
    
    theSession.DeleteUndoMark(markId313, None)
    
    sketchFindMovableObjectsBuilder57 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject117 = sketchFindMovableObjectsBuilder57.Commit()
    
    sketchFindMovableObjectsBuilder57.Destroy()
    
    markId318 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder24 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects56 = [None] * 1 
    dragobjects56[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects56[0].Geometry = line24
    dragobjects56[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects56[0].PointIndex = 0
    sketchDragGeometryBuilder24.SetDragGeometry(dragobjects56)
    
    sketchDragGeometryBuilder24.SplineLinearScale = False
    
    foundrelations82 = sketchDragGeometryBuilder24.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects57 = [None] * 1 
    dragobjects57[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects57[0].Geometry = line24
    dragobjects57[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects57[0].PointIndex = 0
    sketchDragGeometryBuilder24.SetDragGeometry(dragobjects57)
    
    foundrelations83 = sketchDragGeometryBuilder24.FindRelations()
    
    sketchDragGeometryBuilder24.Destroy()
    
    markId319 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences21 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences21 = dimensionPreferences21.GetNarrowDimensionPreferences()
    
    option21 = narrowDimensionPreferences21.DimensionDisplayOption
    
    sketchLinearDimensionBuilder20 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder21 = sketchLinearDimensionBuilder20.Driving
    
    drivingValueBuilder21.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject40 = sketchLinearDimensionBuilder20.FirstAssociativity
    
    selectNXObject41 = sketchLinearDimensionBuilder20.SecondAssociativity
    
    point1_97 = NXOpen.Point3d(27.0, 27.0, 0.0)
    point2_97 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject40.SetValue(NXOpen.InferSnapType.SnapType.Start, line24, NXOpen.View.Null, point1_97, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_97)
    
    point1_98 = NXOpen.Point3d(27.0, 28.5, 0.0)
    point2_98 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject41.SetValue(NXOpen.InferSnapType.SnapType.End, line24, NXOpen.View.Null, point1_98, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_98)
    
    dimensionMeasurementBuilder21 = sketchLinearDimensionBuilder20.Measurement
    
    dimensionMeasurementBuilder21.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder21 = sketchLinearDimensionBuilder20.Origin
    
    origin93 = NXOpen.Point3d(24.059985338863868, 27.75, 0.0)
    originBuilder21.OriginPoint = origin93
    
    originBuilder21.SetInferRelativeToGeometry(True)
    
    nXObject118 = sketchLinearDimensionBuilder20.Commit()
    
    verticalDimension6 = nXObject118
    verticalDimension6.IsOriginCentered = True
    
    sketchLinearDimensionBuilder20.Destroy()
    
    narrowDimensionPreferences21.Dispose()
    dimensionPreferences21.Dispose()
    sketchFindMovableObjectsBuilder58 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject119 = sketchFindMovableObjectsBuilder58.Commit()
    
    sketchFindMovableObjectsBuilder58.Destroy()
    
    markId320 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId321 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder21 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension6)
    
    selectNXObjectList37 = sketchEditDimensionValueBuilder21.ExtraGeometries
    
    foundrelations84 = sketchEditDimensionValueBuilder21.FindRelations()
    
    sketchHelpedDimensionalConstraint20 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line24] StartVertex] [[Curve Line24] EndVertex]")
    sketchHelpedDimensionalConstraint20.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId321, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId321, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint20.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId322 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId322, None)
    
    markId323 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder21.DimValue = 2.0
    
    nXObject120 = sketchEditDimensionValueBuilder21.Commit()
    
    theSession.SetUndoMarkName(markId323, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId323, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId321, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId324 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId325 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint20.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId325, None)
    
    theSession.SetUndoMarkName(markId321, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder21.Destroy()
    
    theSession.DeleteUndoMark(markId324, None)
    
    theSession.SetUndoMarkVisibility(markId321, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId323, None)
    
    theSession.DeleteUndoMark(markId321, None)
    
    sketchFindMovableObjectsBuilder59 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject121 = sketchFindMovableObjectsBuilder59.Commit()
    
    sketchFindMovableObjectsBuilder59.Destroy()
    
    markId326 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder25 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects58 = [None] * 1 
    dragobjects58[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects58[0].Geometry = line27
    dragobjects58[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects58[0].PointIndex = 0
    sketchDragGeometryBuilder25.SetDragGeometry(dragobjects58)
    
    sketchDragGeometryBuilder25.SplineLinearScale = False
    
    foundrelations85 = sketchDragGeometryBuilder25.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects59 = [None] * 2 
    dragobjects59[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects59[1] = NXOpen.Sketch.SketchGeometry()
    dragobjects59[0].Geometry = line27
    dragobjects59[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects59[0].PointIndex = 0
    dragobjects59[1].Geometry = line21
    dragobjects59[1].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects59[1].PointIndex = 0
    sketchDragGeometryBuilder25.SetDragGeometry(dragobjects59)
    
    foundrelations86 = sketchDragGeometryBuilder25.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects60 = [None] * 2 
    dragobjects60[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects60[1] = NXOpen.Sketch.SketchGeometry()
    dragobjects60[0].Geometry = line27
    dragobjects60[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects60[0].PointIndex = 0
    dragobjects60[1].Geometry = line21
    dragobjects60[1].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects60[1].PointIndex = 0
    sketchDragGeometryBuilder25.SetDragGeometry(dragobjects60)
    
    foundrelations87 = sketchDragGeometryBuilder25.FindRelations()
    
    sketchDragGeometryBuilder25.Destroy()
    
    markId327 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences22 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences22 = dimensionPreferences22.GetNarrowDimensionPreferences()
    
    option22 = narrowDimensionPreferences22.DimensionDisplayOption
    
    sketchLinearDimensionBuilder21 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder22 = sketchLinearDimensionBuilder21.Driving
    
    drivingValueBuilder22.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder22 = sketchLinearDimensionBuilder21.Measurement
    
    dimensionMeasurementBuilder22.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject42 = sketchLinearDimensionBuilder21.FirstAssociativity
    
    selectNXObject43 = sketchLinearDimensionBuilder21.SecondAssociativity
    
    point1_103 = NXOpen.Point3d(28.044890953219458, 30.0, 0.0)
    point2_103 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject42.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line27, NXOpen.View.Null, point1_103, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_103)
    
    point1_104 = NXOpen.Point3d(27.0, 28.999999999999996, 0.0)
    point2_104 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject43.SetValue(NXOpen.InferSnapType.SnapType.Start, line21, NXOpen.View.Null, point1_104, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_104)
    
    originBuilder22 = sketchLinearDimensionBuilder21.Origin
    
    origin96 = NXOpen.Point3d(27.999576224134845, 29.5, 0.0)
    originBuilder22.OriginPoint = origin96
    
    originBuilder22.SetInferRelativeToGeometry(True)
    
    nXObject122 = sketchLinearDimensionBuilder21.Commit()
    
    perpendicularDimension10 = nXObject122
    perpendicularDimension10.IsOriginCentered = True
    
    sketchLinearDimensionBuilder21.Destroy()
    
    narrowDimensionPreferences22.Dispose()
    dimensionPreferences22.Dispose()
    sketchFindMovableObjectsBuilder60 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject123 = sketchFindMovableObjectsBuilder60.Commit()
    
    sketchFindMovableObjectsBuilder60.Destroy()
    
    markId328 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId329 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder22 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension10)
    
    selectNXObjectList38 = sketchEditDimensionValueBuilder22.ExtraGeometries
    
    foundrelations88 = sketchEditDimensionValueBuilder22.FindRelations()
    
    sketchHelpedDimensionalConstraint21 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line27] [[Curve Line21] StartVertex]")
    sketchHelpedDimensionalConstraint21.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId329, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId329, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint21.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId330 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId330, None)
    
    markId331 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder22.DimValue = 6.0
    
    nXObject124 = sketchEditDimensionValueBuilder22.Commit()
    
    theSession.SetUndoMarkName(markId331, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId331, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId329, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId332 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    scaleAboutPoint188 = NXOpen.Point3d(2.6735690159923537, -3.3306325877190672, 0.0)
    viewCenter188 = NXOpen.Point3d(-2.6735690159921139, 3.3306325877192102, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint188, viewCenter188)
    
    scaleAboutPoint189 = NXOpen.Point3d(3.3419612699904024, -4.1632907346488572, 0.0)
    viewCenter189 = NXOpen.Point3d(-3.3419612699901609, 4.1632907346489967, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint189, viewCenter189)
    
    scaleAboutPoint190 = NXOpen.Point3d(4.1774515874879787, -5.2041134183110769, 0.0)
    viewCenter190 = NXOpen.Point3d(-4.1774515874877372, 5.2041134183112217, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint190, viewCenter190)
    
    scaleAboutPoint191 = NXOpen.Point3d(5.2218144843599434, -6.5051417728888685, 0.0)
    viewCenter191 = NXOpen.Point3d(-5.221814484359717, 6.5051417728890115, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint191, viewCenter191)
    
    scaleAboutPoint192 = NXOpen.Point3d(7.412321407883768, -7.9101638905026315, 0.0)
    viewCenter192 = NXOpen.Point3d(-7.4123214078835424, 7.9101638905027825, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint192, viewCenter192)
    
    scaleAboutPoint193 = NXOpen.Point3d(9.2654017598546972, -9.8877048631282989, 0.0)
    viewCenter193 = NXOpen.Point3d(-9.2654017598544485, 9.8877048631284534, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint193, viewCenter193)
    
    markId333 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint21.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId333, None)
    
    theSession.SetUndoMarkName(markId329, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder22.Destroy()
    
    theSession.DeleteUndoMark(markId332, None)
    
    theSession.SetUndoMarkVisibility(markId329, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId331, None)
    
    theSession.DeleteUndoMark(markId329, None)
    
    sketchFindMovableObjectsBuilder61 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject125 = sketchFindMovableObjectsBuilder61.Commit()
    
    sketchFindMovableObjectsBuilder61.Destroy()
    
    markId334 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder26 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects61 = [None] * 1 
    dragobjects61[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects61[0].Geometry = line23
    dragobjects61[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects61[0].PointIndex = 0
    sketchDragGeometryBuilder26.SetDragGeometry(dragobjects61)
    
    sketchDragGeometryBuilder26.SplineLinearScale = False
    
    foundrelations89 = sketchDragGeometryBuilder26.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects62 = [None] * 1 
    dragobjects62[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects62[0].Geometry = line23
    dragobjects62[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects62[0].PointIndex = 0
    sketchDragGeometryBuilder26.SetDragGeometry(dragobjects62)
    
    foundrelations90 = sketchDragGeometryBuilder26.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects63 = [None] * 1 
    dragobjects63[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects63[0].Geometry = line23
    dragobjects63[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects63[0].PointIndex = 0
    sketchDragGeometryBuilder26.SetDragGeometry(dragobjects63)
    
    foundrelations91 = sketchDragGeometryBuilder26.FindRelations()
    
    sketchDragGeometryBuilder26.Destroy()
    
    markId335 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences23 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences23 = dimensionPreferences23.GetNarrowDimensionPreferences()
    
    option23 = narrowDimensionPreferences23.DimensionDisplayOption
    
    sketchLinearDimensionBuilder22 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder23 = sketchLinearDimensionBuilder22.Driving
    
    drivingValueBuilder23.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder23 = sketchLinearDimensionBuilder22.Measurement
    
    dimensionMeasurementBuilder23.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject44 = sketchLinearDimensionBuilder22.FirstAssociativity
    
    selectNXObject45 = sketchLinearDimensionBuilder22.SecondAssociativity
    
    point1_109 = NXOpen.Point3d(29.299265935592636, 22.000000000000007, 0.0)
    point2_109 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject44.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line23, NXOpen.View.Null, point1_109, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_109)
    
    point1_110 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_110 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject45.SetValue(NXOpen.InferSnapType.SnapType.Start, line1, NXOpen.View.Null, point1_110, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_110)
    
    originBuilder23 = sketchLinearDimensionBuilder22.Origin
    
    origin99 = NXOpen.Point3d(47.795497060675473, 11.000000000000004, 0.0)
    originBuilder23.OriginPoint = origin99
    
    originBuilder23.SetInferRelativeToGeometry(True)
    
    nXObject126 = sketchLinearDimensionBuilder22.Commit()
    
    perpendicularDimension11 = nXObject126
    perpendicularDimension11.IsOriginCentered = True
    
    sketchLinearDimensionBuilder22.Destroy()
    
    narrowDimensionPreferences23.Dispose()
    dimensionPreferences23.Dispose()
    sketchFindMovableObjectsBuilder62 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject127 = sketchFindMovableObjectsBuilder62.Commit()
    
    sketchFindMovableObjectsBuilder62.Destroy()
    
    markId336 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId337 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder23 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension11)
    
    selectNXObjectList39 = sketchEditDimensionValueBuilder23.ExtraGeometries
    
    foundrelations92 = sketchEditDimensionValueBuilder23.FindRelations()
    
    sketchHelpedDimensionalConstraint22 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line23] [[WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line1] StartVertex]")
    sketchHelpedDimensionalConstraint22.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId337, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId337, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint22.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId338 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId338, None)
    
    markId339 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder23.DimValue = 55.399999999999999
    
    nXObject128 = sketchEditDimensionValueBuilder23.Commit()
    
    theSession.SetUndoMarkName(markId339, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId339, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId337, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId340 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder23.DimValue = 55.039999999999999
    
    nXObject129 = sketchEditDimensionValueBuilder23.Commit()
    
    theSession.SetUndoMarkName(markId340, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId340, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId337, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId341 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId342 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint22.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId342, None)
    
    theSession.SetUndoMarkName(markId337, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder23.Destroy()
    
    theSession.DeleteUndoMark(markId341, None)
    
    theSession.SetUndoMarkVisibility(markId337, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId340, None)
    
    theSession.DeleteUndoMark(markId339, None)
    
    theSession.DeleteUndoMark(markId337, None)
    
    sketchFindMovableObjectsBuilder63 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject130 = sketchFindMovableObjectsBuilder63.Commit()
    
    sketchFindMovableObjectsBuilder63.Destroy()
    
    markId343 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder27 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects64 = [None] * 1 
    dragobjects64[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects64[0].Geometry = line24
    dragobjects64[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects64[0].PointIndex = 0
    sketchDragGeometryBuilder27.SetDragGeometry(dragobjects64)
    
    sketchDragGeometryBuilder27.SplineLinearScale = False
    
    foundrelations93 = sketchDragGeometryBuilder27.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects65 = [None] * 1 
    dragobjects65[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects65[0].Geometry = line24
    dragobjects65[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects65[0].PointIndex = 0
    sketchDragGeometryBuilder27.SetDragGeometry(dragobjects65)
    
    foundrelations94 = sketchDragGeometryBuilder27.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects66 = [None] * 1 
    dragobjects66[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects66[0].Geometry = line24
    dragobjects66[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects66[0].PointIndex = 0
    sketchDragGeometryBuilder27.SetDragGeometry(dragobjects66)
    
    foundrelations95 = sketchDragGeometryBuilder27.FindRelations()
    
    sketchDragGeometryBuilder27.Destroy()
    
    markId344 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences24 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences24 = dimensionPreferences24.GetNarrowDimensionPreferences()
    
    option24 = narrowDimensionPreferences24.DimensionDisplayOption
    
    sketchLinearDimensionBuilder23 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder24 = sketchLinearDimensionBuilder23.Driving
    
    drivingValueBuilder24.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder24 = sketchLinearDimensionBuilder23.Measurement
    
    dimensionMeasurementBuilder24.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject46 = sketchLinearDimensionBuilder23.FirstAssociativity
    
    selectNXObject47 = sketchLinearDimensionBuilder23.SecondAssociativity
    
    point1_113 = NXOpen.Point3d(27.0, 56.087017497764492, 0.0)
    point2_113 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject46.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line24, NXOpen.View.Null, point1_113, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_113)
    
    point1_114 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_114 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject47.SetValue(NXOpen.InferSnapType.SnapType.End, line4, NXOpen.View.Null, point1_114, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_114)
    
    originBuilder24 = sketchLinearDimensionBuilder23.Origin
    
    origin101 = NXOpen.Point3d(13.5, 49.518262518763095, 0.0)
    originBuilder24.OriginPoint = origin101
    
    originBuilder24.SetInferRelativeToGeometry(True)
    
    nXObject131 = sketchLinearDimensionBuilder23.Commit()
    
    perpendicularDimension12 = nXObject131
    perpendicularDimension12.IsOriginCentered = True
    
    sketchLinearDimensionBuilder23.Destroy()
    
    narrowDimensionPreferences24.Dispose()
    dimensionPreferences24.Dispose()
    sketchFindMovableObjectsBuilder64 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject132 = sketchFindMovableObjectsBuilder64.Commit()
    
    sketchFindMovableObjectsBuilder64.Destroy()
    
    markId345 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId346 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder24 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension12)
    
    selectNXObjectList40 = sketchEditDimensionValueBuilder24.ExtraGeometries
    
    foundrelations96 = sketchEditDimensionValueBuilder24.FindRelations()
    
    sketchHelpedDimensionalConstraint23 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line24] [[WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line4] EndVertex]")
    sketchHelpedDimensionalConstraint23.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId346, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId346, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint23.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId347 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId347, None)
    
    markId348 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder24.DimValue = 55.0
    
    nXObject133 = sketchEditDimensionValueBuilder24.Commit()
    
    theSession.SetUndoMarkName(markId348, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId348, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId346, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId349 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId350 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint23.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId350, None)
    
    theSession.SetUndoMarkName(markId346, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder24.Destroy()
    
    theSession.DeleteUndoMark(markId349, None)
    
    theSession.SetUndoMarkVisibility(markId346, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId348, None)
    
    theSession.DeleteUndoMark(markId346, None)
    
    sketchFindMovableObjectsBuilder65 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject134 = sketchFindMovableObjectsBuilder65.Commit()
    
    sketchFindMovableObjectsBuilder65.Destroy()
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled6, undoUnavailable6 = theSession.UndoLastNVisibleMarks(1)
    
    markId351 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Sketch Drag")
    
    sketchDragGeometryBuilder28 = workPart.Sketches.CreateDragGeometryBuilder()
    
    sketchDragGeometryBuilder28.SnapRadius = 4.5635560906746395
    
    sketchDragGeometryBuilder28.SplineLinearScale = False
    
    snapgeometry1 = NXOpen.Sketch.SketchGeometry()
    
    snapgeometry1.Geometry = line22
    snapgeometry1.PointType = NXOpen.Sketch.PointType.NotSet
    snapgeometry1.PointIndex = 0
    sketchDragGeometryBuilder28.SnapGeometry = snapgeometry1
    
    dragobjects67 = [None] * 1 
    dragobjects67[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects67[0].Geometry = line22
    dragobjects67[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects67[0].PointIndex = 0
    sketchDragGeometryBuilder28.SetDragGeometry(dragobjects67)
    
    initialposition1 = NXOpen.Point3d(32.065057505698498, 56.259879470896102, 0.0)
    sketchDragGeometryBuilder28.InitializeDrag(initialposition1)
    
    sketchDragGeometryBuilder28.SetSnapTarget(line21)
    
    sketchDragGeometryBuilder28.SetSnapTarget(line23)
    
    snaphelppoint1 = NXOpen.Point3d(67.782428438244352, 55.039999999999992, 0.0)
    sketchDragGeometryBuilder28.SetSnapPointTarget(line23, snaphelppoint1)
    
    newposition1 = NXOpen.Point3d(67.847485943942843, 54.531259739579951, 0.0)
    sketchDragGeometryBuilder28.DragToPoint(newposition1)
    
    nXObject135 = sketchDragGeometryBuilder28.Commit()
    
    sketchDragGeometryBuilder28.Destroy()
    
    theSession.ActiveSketch.Update()
    
    sketchFindMovableObjectsBuilder66 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject136 = sketchFindMovableObjectsBuilder66.Commit()
    
    sketchFindMovableObjectsBuilder66.Destroy()
    
    markId352 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Sketch Drag")
    
    sketchDragGeometryBuilder29 = workPart.Sketches.CreateDragGeometryBuilder()
    
    sketchDragGeometryBuilder29.SnapRadius = 4.5635560906746395
    
    sketchDragGeometryBuilder29.SplineLinearScale = False
    
    snapgeometry2 = NXOpen.Sketch.SketchGeometry()
    
    snapgeometry2.Geometry = line24
    snapgeometry2.PointType = NXOpen.Sketch.PointType.NotSet
    snapgeometry2.PointIndex = 0
    sketchDragGeometryBuilder29.SnapGeometry = snapgeometry2
    
    dragobjects68 = [None] * 1 
    dragobjects68[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects68[0].Geometry = line24
    dragobjects68[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects68[0].PointIndex = 0
    sketchDragGeometryBuilder29.SetDragGeometry(dragobjects68)
    
    initialposition2 = NXOpen.Point3d(27.224922258013255, 56.087017497764492, 0.0)
    sketchDragGeometryBuilder29.InitializeDrag(initialposition2)
    
    sketchDragGeometryBuilder29.SetSnapTarget(line23)
    
    sketchDragGeometryBuilder29.SetSnapTarget(line21)
    
    snaphelppoint2 = NXOpen.Point3d(42.609637866727013, 57.039999999999985, 0.0)
    sketchDragGeometryBuilder29.SetSnapPointTarget(line21, snaphelppoint2)
    
    newposition2 = NXOpen.Point3d(42.609637866727013, 57.124189336554181, 0.0)
    sketchDragGeometryBuilder29.DragToPoint(newposition2)
    
    nXObject137 = sketchDragGeometryBuilder29.Commit()
    
    sketchDragGeometryBuilder29.Destroy()
    
    theSession.ActiveSketch.Update()
    
    sketchFindMovableObjectsBuilder67 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject138 = sketchFindMovableObjectsBuilder67.Commit()
    
    sketchFindMovableObjectsBuilder67.Destroy()
    
    scaleAboutPoint194 = NXOpen.Point3d(11.754614172949914, 15.81687054154286, 0.0)
    viewCenter194 = NXOpen.Point3d(-11.754614172949648, -15.816870541542713, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint194, viewCenter194)
    
    scaleAboutPoint195 = NXOpen.Point3d(14.693267716187393, 19.55501071051404, 0.0)
    viewCenter195 = NXOpen.Point3d(-14.693267716187133, -19.555010710513894, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint195, viewCenter195)
    
    scaleAboutPoint196 = NXOpen.Point3d(18.366584645234241, 24.173666555124385, 0.0)
    viewCenter196 = NXOpen.Point3d(-18.366584645233942, -24.173666555124267, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint196, viewCenter196)
    
    scaleAboutPoint197 = NXOpen.Point3d(25.996820177996856, 29.541841111360071, 0.0)
    viewCenter197 = NXOpen.Point3d(-25.996820177996568, -29.541841111359954, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint197, viewCenter197)
    
    scaleAboutPoint198 = NXOpen.Point3d(20.797456142397579, 23.633472889088061, 0.0)
    viewCenter198 = NXOpen.Point3d(-20.79745614239728, -23.633472889087944, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint198, viewCenter198)
    
    scaleAboutPoint199 = NXOpen.Point3d(16.854042380332604, 18.906778311270482, 0.0)
    viewCenter199 = NXOpen.Point3d(-16.854042380332348, -18.906778311270337, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint199, viewCenter199)
    
    scaleAboutPoint200 = NXOpen.Point3d(13.656095877397719, 15.125422649016402, 0.0)
    viewCenter200 = NXOpen.Point3d(-13.656095877397455, -15.125422649016254, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint200, viewCenter200)
    
    scaleAboutPoint201 = NXOpen.Point3d(9.1271121813494318, 12.791786011739584, 0.0)
    viewCenter201 = NXOpen.Point3d(-9.1271121813491263, -12.791786011739454, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint201, viewCenter201)
    
    scaleAboutPoint202 = NXOpen.Point3d(7.1910580822753385, 10.344060472195928, 0.0)
    viewCenter202 = NXOpen.Point3d(-7.1910580822750267, -10.344060472195787, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint202, viewCenter202)
    
    markId353 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Sketch Drag")
    
    sketchDragGeometryBuilder30 = workPart.Sketches.CreateDragGeometryBuilder()
    
    sketchDragGeometryBuilder30.SnapRadius = 2.336540718425415
    
    sketchDragGeometryBuilder30.SplineLinearScale = False
    
    snapgeometry3 = NXOpen.Sketch.SketchGeometry()
    
    snapgeometry3.Geometry = line28
    snapgeometry3.PointType = NXOpen.Sketch.PointType.NotSet
    snapgeometry3.PointIndex = 0
    sketchDragGeometryBuilder30.SnapGeometry = snapgeometry3
    
    dragobjects69 = [None] * 1 
    dragobjects69[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects69[0].Geometry = line28
    dragobjects69[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects69[0].PointIndex = 0
    sketchDragGeometryBuilder30.SetDragGeometry(dragobjects69)
    
    initialposition3 = NXOpen.Point3d(27.026498320604848, 64.018140902509373, 0.0)
    sketchDragGeometryBuilder30.InitializeDrag(initialposition3)
    
    sketchDragGeometryBuilder30.SetSnapTarget(line27)
    
    snaphelppoint3 = NXOpen.Point3d(37.204611298594358, 63.039999999999985, 0.0)
    sketchDragGeometryBuilder30.SetSnapPointTarget(line27, snaphelppoint3)
    
    newposition3 = NXOpen.Point3d(37.204611298594358, 62.425044958128396, 0.0)
    sketchDragGeometryBuilder30.DragToPoint(newposition3)
    
    nXObject139 = sketchDragGeometryBuilder30.Commit()
    
    sketchDragGeometryBuilder30.Destroy()
    
    theSession.ActiveSketch.Update()
    
    sketchFindMovableObjectsBuilder68 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject140 = sketchFindMovableObjectsBuilder68.Commit()
    
    sketchFindMovableObjectsBuilder68.Destroy()
    
    theAnnotationsAngularDimensionUtils = NXOpen.Annotations.AngularDimensionUtils.GetAngularDimensionUtils(theSession)
    
    perpendicularDimension13 = nXObject133
    theAnnotationsAngularDimensionUtils.SetAllowSupplementaryAngle(perpendicularDimension13, False)
    
    markId354 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Object Origin")
    
    perpendicularDimension13.LeaderOrientation = NXOpen.Annotations.LeaderOrientation.FromLeft
    
    perpendicularDimension13.IsOriginCentered = False
    
    origin102 = perpendicularDimension13.AnnotationOrigin
    
    location1 = NXOpen.Point3d(16.494364021641807, 49.414761412350494, 0.0)
    changed1 = theAnnotationsAngularDimensionUtils.InferQuadrantAngleFromLocation(perpendicularDimension13, location1)
    
    origin103 = NXOpen.Point3d(16.494364021641807, 49.414761412350494, 0.0)
    perpendicularDimension13.AnnotationOrigin = origin103
    
    nErrs11 = theSession.UpdateManager.DoUpdate(markId354)
    
    markId355 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId356 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder25 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension13)
    
    selectNXObjectList41 = sketchEditDimensionValueBuilder25.ExtraGeometries
    
    foundrelations97 = sketchEditDimensionValueBuilder25.FindRelations()
    
    sketchHelpedDimensionalConstraint23.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId356, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId356, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint23.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    markId357 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId357, None)
    
    markId358 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder25.DimValue = 55.0
    
    nXObject141 = sketchEditDimensionValueBuilder25.Commit()
    
    theSession.SetUndoMarkName(markId358, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId358, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId356, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId359 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    scaleAboutPoint203 = NXOpen.Point3d(34.959605446137999, 2.0798752607196569, 0.0)
    viewCenter203 = NXOpen.Point3d(-34.959605446137687, -2.079875260719521, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint203, viewCenter203)
    
    scaleAboutPoint204 = NXOpen.Point3d(44.142033458889415, 2.5998440758995711, 0.0)
    viewCenter204 = NXOpen.Point3d(-44.142033458889095, -2.5998440758994295, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint204, viewCenter204)
    
    scaleAboutPoint205 = NXOpen.Point3d(55.177541823611733, 3.2498050948744401, 0.0)
    viewCenter205 = NXOpen.Point3d(-55.177541823611428, -3.2498050948742985, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint205, viewCenter205)
    
    scaleAboutPoint206 = NXOpen.Point3d(69.144789252646191, 4.0622563685930357, 0.0)
    viewCenter206 = NXOpen.Point3d(-69.144789252645936, -4.0622563685928883, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint206, viewCenter206)
    
    scaleAboutPoint207 = NXOpen.Point3d(87.295296431465772, 5.2938979271557915, 0.0)
    viewCenter207 = NXOpen.Point3d(-87.295296431465516, -5.2938979271556441, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint207, viewCenter207)
    
    scaleAboutPoint208 = NXOpen.Point3d(109.1191205393322, 6.6173724089447177, 0.0)
    viewCenter208 = NXOpen.Point3d(-109.11912053933193, -6.6173724089446022, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint208, viewCenter208)
    
    scaleAboutPoint209 = NXOpen.Point3d(136.73652171543793, 8.2717155111808687, 0.0)
    viewCenter209 = NXOpen.Point3d(-136.7365217154377, -8.2717155111807532, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint209, viewCenter209)
    
    scaleAboutPoint210 = NXOpen.Point3d(183.58144119202308, 5.2753287698858138, 0.0)
    viewCenter210 = NXOpen.Point3d(-183.58144119202288, -5.2753287698857054, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint210, viewCenter210)
    
    scaleAboutPoint211 = NXOpen.Point3d(147.20277399489117, 4.2202630159086221, 0.0)
    viewCenter211 = NXOpen.Point3d(-147.20277399489095, -4.2202630159085652, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint211, viewCenter211)
    
    scaleAboutPoint212 = NXOpen.Point3d(118.03231602893111, 3.6463072457450321, 0.0)
    viewCenter212 = NXOpen.Point3d(-118.03231602893092, -3.6463072457449863, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint212, viewCenter212)
    
    scaleAboutPoint213 = NXOpen.Point3d(94.425852823144879, 3.1331232630105501, 0.0)
    viewCenter213 = NXOpen.Point3d(-94.425852823144695, -3.1331232630105319, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint213, viewCenter213)
    
    markId360 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint23.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId360, None)
    
    theSession.SetUndoMarkName(markId356, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder25.Destroy()
    
    theSession.DeleteUndoMark(markId359, None)
    
    theSession.SetUndoMarkVisibility(markId356, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId358, None)
    
    theSession.DeleteUndoMark(markId356, None)
    
    sketchFindMovableObjectsBuilder69 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject142 = sketchFindMovableObjectsBuilder69.Commit()
    
    sketchFindMovableObjectsBuilder69.Destroy()
    
    scaleAboutPoint214 = NXOpen.Point3d(73.98492450033136, 3.0250845298032853, 0.0)
    viewCenter214 = NXOpen.Point3d(-73.984924500331203, -3.025084529803256, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint214, viewCenter214)
    
    scaleAboutPoint215 = NXOpen.Point3d(59.187939600265075, 2.4200676238426277, 0.0)
    viewCenter215 = NXOpen.Point3d(-59.18793960026494, -2.4200676238426042, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint215, viewCenter215)
    
    markId361 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder31 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects70 = [None] * 1 
    dragobjects70[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects70[0].Geometry = line23
    dragobjects70[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects70[0].PointIndex = 0
    sketchDragGeometryBuilder31.SetDragGeometry(dragobjects70)
    
    sketchDragGeometryBuilder31.SplineLinearScale = False
    
    foundrelations98 = sketchDragGeometryBuilder31.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects71 = [None] * 1 
    dragobjects71[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects71[0].Geometry = line23
    dragobjects71[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects71[0].PointIndex = 0
    sketchDragGeometryBuilder31.SetDragGeometry(dragobjects71)
    
    foundrelations99 = sketchDragGeometryBuilder31.FindRelations()
    
    sketchDragGeometryBuilder31.Destroy()
    
    markId362 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences25 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences25 = dimensionPreferences25.GetNarrowDimensionPreferences()
    
    option25 = narrowDimensionPreferences25.DimensionDisplayOption
    
    sketchLinearDimensionBuilder24 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder25 = sketchLinearDimensionBuilder24.Driving
    
    drivingValueBuilder25.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject48 = sketchLinearDimensionBuilder24.FirstAssociativity
    
    selectNXObject49 = sketchLinearDimensionBuilder24.SecondAssociativity
    
    point1_117 = NXOpen.Point3d(67.782428438244352, 55.039999999999992, 0.0)
    point2_117 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject48.SetValue(NXOpen.InferSnapType.SnapType.Start, line23, NXOpen.View.Null, point1_117, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_117)
    
    point1_118 = NXOpen.Point3d(55.0, 55.039999999999992, 0.0)
    point2_118 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject49.SetValue(NXOpen.InferSnapType.SnapType.End, line23, NXOpen.View.Null, point1_118, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_118)
    
    dimensionMeasurementBuilder25 = sketchLinearDimensionBuilder24.Measurement
    
    dimensionMeasurementBuilder25.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder25 = sketchLinearDimensionBuilder24.Origin
    
    origin105 = NXOpen.Point3d(61.391214219122176, 52.09998533886386, 0.0)
    originBuilder25.OriginPoint = origin105
    
    originBuilder25.SetInferRelativeToGeometry(True)
    
    nXObject143 = sketchLinearDimensionBuilder24.Commit()
    
    horizontalDimension6 = nXObject143
    horizontalDimension6.IsOriginCentered = True
    
    sketchLinearDimensionBuilder24.Destroy()
    
    narrowDimensionPreferences25.Dispose()
    dimensionPreferences25.Dispose()
    sketchFindMovableObjectsBuilder70 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject144 = sketchFindMovableObjectsBuilder70.Commit()
    
    sketchFindMovableObjectsBuilder70.Destroy()
    
    markId363 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId364 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder26 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension6)
    
    selectNXObjectList42 = sketchEditDimensionValueBuilder26.ExtraGeometries
    
    foundrelations100 = sketchEditDimensionValueBuilder26.FindRelations()
    
    sketchHelpedDimensionalConstraint24 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line23] StartVertex] [[Curve Line23] EndVertex]")
    sketchHelpedDimensionalConstraint24.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId364, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId364, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint24.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId365 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId365, None)
    
    markId366 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder26.DimValue = 6.0
    
    nXObject145 = sketchEditDimensionValueBuilder26.Commit()
    
    theSession.SetUndoMarkName(markId366, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId366, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId364, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId367 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId368 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint24.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId368, None)
    
    theSession.SetUndoMarkName(markId364, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder26.Destroy()
    
    theSession.DeleteUndoMark(markId367, None)
    
    theSession.SetUndoMarkVisibility(markId364, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId366, None)
    
    theSession.DeleteUndoMark(markId364, None)
    
    sketchFindMovableObjectsBuilder71 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject146 = sketchFindMovableObjectsBuilder71.Commit()
    
    sketchFindMovableObjectsBuilder71.Destroy()
    
    markId369 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId370 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    perpendicularDimension14 = nXObject141
    sketchEditDimensionValueBuilder27 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension14)
    
    selectNXObjectList43 = sketchEditDimensionValueBuilder27.ExtraGeometries
    
    foundrelations101 = sketchEditDimensionValueBuilder27.FindRelations()
    
    sketchHelpedDimensionalConstraint23.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId370, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId370, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint23.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId371 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId371, None)
    
    markId372 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder27.DimValue = 57.0
    
    nXObject147 = sketchEditDimensionValueBuilder27.Commit()
    
    theSession.SetUndoMarkName(markId372, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId372, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId370, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId373 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId374 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint23.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId374, None)
    
    theSession.SetUndoMarkName(markId370, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder27.Destroy()
    
    theSession.DeleteUndoMark(markId373, None)
    
    theSession.SetUndoMarkVisibility(markId370, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId372, None)
    
    theSession.DeleteUndoMark(markId370, None)
    
    sketchFindMovableObjectsBuilder72 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject148 = sketchFindMovableObjectsBuilder72.Commit()
    
    sketchFindMovableObjectsBuilder72.Destroy()
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId375 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId376 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId376, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint29 = NXOpen.Point3d(4.5, 65.0, 0.0)
    endPoint29 = NXOpen.Point3d(11.499999999999998, 65.0, 0.0)
    line29 = workPart.Curves.CreateLine(startPoint29, endPoint29)
    
    startPoint30 = NXOpen.Point3d(11.499999999999998, 65.0, 0.0)
    endPoint30 = NXOpen.Point3d(11.499999999999998, 63.5, 0.0)
    line30 = workPart.Curves.CreateLine(startPoint30, endPoint30)
    
    startPoint31 = NXOpen.Point3d(11.499999999999998, 63.5, 0.0)
    endPoint31 = NXOpen.Point3d(4.5, 63.5, 0.0)
    line31 = workPart.Curves.CreateLine(startPoint31, endPoint31)
    
    startPoint32 = NXOpen.Point3d(4.5, 63.5, 0.0)
    endPoint32 = NXOpen.Point3d(4.5, 65.0, 0.0)
    line32 = workPart.Curves.CreateLine(startPoint32, endPoint32)
    
    theSession.ActiveSketch.AddGeometry(line29, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line30, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line31, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line32, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_29 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_29.Geometry = line29
    conGeom1_29.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_29.SplineDefiningPointIndex = 0
    conGeom2_29 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_29.Geometry = line30
    conGeom2_29.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_29.SplineDefiningPointIndex = 0
    sketchGeometricConstraint29 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_29, conGeom2_29)
    
    conGeom1_30 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_30.Geometry = line30
    conGeom1_30.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_30.SplineDefiningPointIndex = 0
    conGeom2_30 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_30.Geometry = line31
    conGeom2_30.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_30.SplineDefiningPointIndex = 0
    sketchGeometricConstraint30 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_30, conGeom2_30)
    
    conGeom1_31 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_31.Geometry = line31
    conGeom1_31.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_31.SplineDefiningPointIndex = 0
    conGeom2_31 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_31.Geometry = line32
    conGeom2_31.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_31.SplineDefiningPointIndex = 0
    sketchGeometricConstraint31 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_31, conGeom2_31)
    
    conGeom1_32 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_32.Geometry = line32
    conGeom1_32.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_32.SplineDefiningPointIndex = 0
    conGeom2_32 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_32.Geometry = line29
    conGeom2_32.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_32.SplineDefiningPointIndex = 0
    sketchGeometricConstraint32 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_32, conGeom2_32)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms15 = [NXOpen.SmartObject.Null] * 4 
    geoms15[0] = line29
    geoms15[1] = line30
    geoms15[2] = line31
    geoms15[3] = line32
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms15)
    
    geoms16 = [NXOpen.SmartObject.Null] * 4 
    geoms16[0] = line29
    geoms16[1] = line30
    geoms16[2] = line31
    geoms16[3] = line32
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms16)
    
    objects13 = [NXOpen.NXObject.Null] * 4 
    objects13[0] = sketchGeometricConstraint29
    objects13[1] = sketchGeometricConstraint30
    objects13[2] = sketchGeometricConstraint31
    objects13[3] = sketchGeometricConstraint32
    errorList8 = theSession.ActiveSketch.DeleteObjects(objects13)
    
    errorList8.Dispose()
    markId377 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId377, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint33 = NXOpen.Point3d(4.5, 59.0, 0.0)
    endPoint33 = NXOpen.Point3d(11.499999999999998, 59.0, 0.0)
    line33 = workPart.Curves.CreateLine(startPoint33, endPoint33)
    
    startPoint34 = NXOpen.Point3d(11.499999999999998, 59.0, 0.0)
    endPoint34 = NXOpen.Point3d(11.499999999999998, 57.5, 0.0)
    line34 = workPart.Curves.CreateLine(startPoint34, endPoint34)
    
    startPoint35 = NXOpen.Point3d(11.499999999999998, 57.5, 0.0)
    endPoint35 = NXOpen.Point3d(4.5, 57.5, 0.0)
    line35 = workPart.Curves.CreateLine(startPoint35, endPoint35)
    
    startPoint36 = NXOpen.Point3d(4.5, 57.5, 0.0)
    endPoint36 = NXOpen.Point3d(4.5, 59.0, 0.0)
    line36 = workPart.Curves.CreateLine(startPoint36, endPoint36)
    
    theSession.ActiveSketch.AddGeometry(line33, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line34, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line35, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line36, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_33 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_33.Geometry = line33
    conGeom1_33.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_33.SplineDefiningPointIndex = 0
    conGeom2_33 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_33.Geometry = line34
    conGeom2_33.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_33.SplineDefiningPointIndex = 0
    sketchGeometricConstraint33 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_33, conGeom2_33)
    
    conGeom1_34 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_34.Geometry = line34
    conGeom1_34.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_34.SplineDefiningPointIndex = 0
    conGeom2_34 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_34.Geometry = line35
    conGeom2_34.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_34.SplineDefiningPointIndex = 0
    sketchGeometricConstraint34 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_34, conGeom2_34)
    
    conGeom1_35 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_35.Geometry = line35
    conGeom1_35.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_35.SplineDefiningPointIndex = 0
    conGeom2_35 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_35.Geometry = line36
    conGeom2_35.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_35.SplineDefiningPointIndex = 0
    sketchGeometricConstraint35 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_35, conGeom2_35)
    
    conGeom1_36 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_36.Geometry = line36
    conGeom1_36.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_36.SplineDefiningPointIndex = 0
    conGeom2_36 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_36.Geometry = line33
    conGeom2_36.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_36.SplineDefiningPointIndex = 0
    sketchGeometricConstraint36 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_36, conGeom2_36)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms17 = [NXOpen.SmartObject.Null] * 4 
    geoms17[0] = line33
    geoms17[1] = line34
    geoms17[2] = line35
    geoms17[3] = line36
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms17)
    
    geoms18 = [NXOpen.SmartObject.Null] * 4 
    geoms18[0] = line33
    geoms18[1] = line34
    geoms18[2] = line35
    geoms18[3] = line36
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms18)
    
    objects14 = [NXOpen.NXObject.Null] * 4 
    objects14[0] = sketchGeometricConstraint33
    objects14[1] = sketchGeometricConstraint34
    objects14[2] = sketchGeometricConstraint35
    objects14[3] = sketchGeometricConstraint36
    errorList9 = theSession.ActiveSketch.DeleteObjects(objects14)
    
    errorList9.Dispose()
    sketchFindMovableObjectsBuilder73 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject149 = sketchFindMovableObjectsBuilder73.Commit()
    
    sketchFindMovableObjectsBuilder73.Destroy()
    
    markId378 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder32 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects72 = [None] * 1 
    dragobjects72[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects72[0].Geometry = line30
    dragobjects72[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects72[0].PointIndex = 0
    sketchDragGeometryBuilder32.SetDragGeometry(dragobjects72)
    
    sketchDragGeometryBuilder32.SplineLinearScale = False
    
    foundrelations102 = sketchDragGeometryBuilder32.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects73 = [None] * 2 
    dragobjects73[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects73[1] = NXOpen.Sketch.SketchGeometry()
    dragobjects73[0].Geometry = line30
    dragobjects73[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects73[0].PointIndex = 0
    dragobjects73[1].Geometry = line28
    dragobjects73[1].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects73[1].PointIndex = 0
    sketchDragGeometryBuilder32.SetDragGeometry(dragobjects73)
    
    foundrelations103 = sketchDragGeometryBuilder32.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects74 = [None] * 2 
    dragobjects74[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects74[1] = NXOpen.Sketch.SketchGeometry()
    dragobjects74[0].Geometry = line30
    dragobjects74[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects74[0].PointIndex = 0
    dragobjects74[1].Geometry = line28
    dragobjects74[1].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects74[1].PointIndex = 0
    sketchDragGeometryBuilder32.SetDragGeometry(dragobjects74)
    
    foundrelations104 = sketchDragGeometryBuilder32.FindRelations()
    
    sketchDragGeometryBuilder32.Destroy()
    
    markId379 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences26 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences26 = dimensionPreferences26.GetNarrowDimensionPreferences()
    
    option26 = narrowDimensionPreferences26.DimensionDisplayOption
    
    sketchLinearDimensionBuilder25 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder26 = sketchLinearDimensionBuilder25.Driving
    
    drivingValueBuilder26.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder26 = sketchLinearDimensionBuilder25.Measurement
    
    dimensionMeasurementBuilder26.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject50 = sketchLinearDimensionBuilder25.FirstAssociativity
    
    selectNXObject51 = sketchLinearDimensionBuilder25.SecondAssociativity
    
    point1_123 = NXOpen.Point3d(11.499999999999998, 64.378666155221978, 0.0)
    point2_123 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject50.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line30, NXOpen.View.Null, point1_123, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_123)
    
    point1_124 = NXOpen.Point3d(57.0, 65.039999999999992, 0.0)
    point2_124 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject51.SetValue(NXOpen.InferSnapType.SnapType.End, line28, NXOpen.View.Null, point1_124, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_124)
    
    originBuilder26 = sketchLinearDimensionBuilder25.Origin
    
    origin108 = NXOpen.Point3d(34.25, 64.489297818026216, 0.0)
    originBuilder26.OriginPoint = origin108
    
    originBuilder26.SetInferRelativeToGeometry(True)
    
    nXObject150 = sketchLinearDimensionBuilder25.Commit()
    
    perpendicularDimension15 = nXObject150
    perpendicularDimension15.IsOriginCentered = True
    
    sketchLinearDimensionBuilder25.Destroy()
    
    narrowDimensionPreferences26.Dispose()
    dimensionPreferences26.Dispose()
    sketchFindMovableObjectsBuilder74 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject151 = sketchFindMovableObjectsBuilder74.Commit()
    
    sketchFindMovableObjectsBuilder74.Destroy()
    
    markId380 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId381 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder28 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension15)
    
    selectNXObjectList44 = sketchEditDimensionValueBuilder28.ExtraGeometries
    
    foundrelations105 = sketchEditDimensionValueBuilder28.FindRelations()
    
    sketchHelpedDimensionalConstraint25 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line32] [[Curve Line28] EndVertex]")
    sketchHelpedDimensionalConstraint25.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId381, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId381, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint25.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId382 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId382, None)
    
    markId383 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder28.DimValue = 47.0
    
    nXObject152 = sketchEditDimensionValueBuilder28.Commit()
    
    theSession.SetUndoMarkName(markId383, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId383, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId381, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId384 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId385 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint25.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId385, None)
    
    theSession.SetUndoMarkName(markId381, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder28.Destroy()
    
    theSession.DeleteUndoMark(markId384, None)
    
    theSession.SetUndoMarkVisibility(markId381, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId383, None)
    
    theSession.DeleteUndoMark(markId381, None)
    
    sketchFindMovableObjectsBuilder75 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject153 = sketchFindMovableObjectsBuilder75.Commit()
    
    sketchFindMovableObjectsBuilder75.Destroy()
    
    markId386 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder33 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects75 = [None] * 1 
    dragobjects75[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects75[0].Geometry = line29
    dragobjects75[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects75[0].PointIndex = 0
    sketchDragGeometryBuilder33.SetDragGeometry(dragobjects75)
    
    sketchDragGeometryBuilder33.SplineLinearScale = False
    
    foundrelations106 = sketchDragGeometryBuilder33.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects76 = [None] * 1 
    dragobjects76[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects76[0].Geometry = line29
    dragobjects76[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects76[0].PointIndex = 0
    sketchDragGeometryBuilder33.SetDragGeometry(dragobjects76)
    
    foundrelations107 = sketchDragGeometryBuilder33.FindRelations()
    
    sketchDragGeometryBuilder33.Destroy()
    
    markId387 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences27 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences27 = dimensionPreferences27.GetNarrowDimensionPreferences()
    
    option27 = narrowDimensionPreferences27.DimensionDisplayOption
    
    sketchLinearDimensionBuilder26 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder27 = sketchLinearDimensionBuilder26.Driving
    
    drivingValueBuilder27.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject52 = sketchLinearDimensionBuilder26.FirstAssociativity
    
    selectNXObject53 = sketchLinearDimensionBuilder26.SecondAssociativity
    
    point1_127 = NXOpen.Point3d(4.5000000000000009, 65.0, 0.0)
    point2_127 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject52.SetValue(NXOpen.InferSnapType.SnapType.Start, line29, NXOpen.View.Null, point1_127, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_127)
    
    point1_128 = NXOpen.Point3d(10.000000000000004, 65.0, 0.0)
    point2_128 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject53.SetValue(NXOpen.InferSnapType.SnapType.End, line29, NXOpen.View.Null, point1_128, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_128)
    
    dimensionMeasurementBuilder27 = sketchLinearDimensionBuilder26.Measurement
    
    dimensionMeasurementBuilder27.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder27 = sketchLinearDimensionBuilder26.Origin
    
    origin110 = NXOpen.Point3d(7.2500000000000018, 67.940014661136132, 0.0)
    originBuilder27.OriginPoint = origin110
    
    originBuilder27.SetInferRelativeToGeometry(True)
    
    nXObject154 = sketchLinearDimensionBuilder26.Commit()
    
    horizontalDimension7 = nXObject154
    horizontalDimension7.IsOriginCentered = True
    
    sketchLinearDimensionBuilder26.Destroy()
    
    narrowDimensionPreferences27.Dispose()
    dimensionPreferences27.Dispose()
    sketchFindMovableObjectsBuilder76 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject155 = sketchFindMovableObjectsBuilder76.Commit()
    
    sketchFindMovableObjectsBuilder76.Destroy()
    
    markId388 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId389 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder29 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension7)
    
    selectNXObjectList45 = sketchEditDimensionValueBuilder29.ExtraGeometries
    
    foundrelations108 = sketchEditDimensionValueBuilder29.FindRelations()
    
    sketchHelpedDimensionalConstraint26 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line31] StartVertex] [[Curve Line31] EndVertex]")
    sketchHelpedDimensionalConstraint26.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId389, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId389, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint26.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId390 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId390, None)
    
    markId391 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder29.DimValue = 6.0
    
    nXObject156 = sketchEditDimensionValueBuilder29.Commit()
    
    theSession.SetUndoMarkName(markId391, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId391, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId389, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId392 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId393 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint26.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId393, None)
    
    theSession.SetUndoMarkName(markId389, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder29.Destroy()
    
    theSession.DeleteUndoMark(markId392, None)
    
    theSession.SetUndoMarkVisibility(markId389, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId391, None)
    
    theSession.DeleteUndoMark(markId389, None)
    
    sketchFindMovableObjectsBuilder77 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject157 = sketchFindMovableObjectsBuilder77.Commit()
    
    sketchFindMovableObjectsBuilder77.Destroy()
    
    markId394 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder34 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects77 = [None] * 1 
    dragobjects77[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects77[0].Geometry = line32
    dragobjects77[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects77[0].PointIndex = 0
    sketchDragGeometryBuilder34.SetDragGeometry(dragobjects77)
    
    sketchDragGeometryBuilder34.SplineLinearScale = False
    
    foundrelations109 = sketchDragGeometryBuilder34.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects78 = [None] * 1 
    dragobjects78[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects78[0].Geometry = line32
    dragobjects78[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects78[0].PointIndex = 0
    sketchDragGeometryBuilder34.SetDragGeometry(dragobjects78)
    
    foundrelations110 = sketchDragGeometryBuilder34.FindRelations()
    
    sketchDragGeometryBuilder34.Destroy()
    
    markId395 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences28 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences28 = dimensionPreferences28.GetNarrowDimensionPreferences()
    
    option28 = narrowDimensionPreferences28.DimensionDisplayOption
    
    sketchLinearDimensionBuilder27 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder28 = sketchLinearDimensionBuilder27.Driving
    
    drivingValueBuilder28.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject54 = sketchLinearDimensionBuilder27.FirstAssociativity
    
    selectNXObject55 = sketchLinearDimensionBuilder27.SecondAssociativity
    
    point1_131 = NXOpen.Point3d(4.0000000000000036, 63.5, 0.0)
    point2_131 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject54.SetValue(NXOpen.InferSnapType.SnapType.Start, line32, NXOpen.View.Null, point1_131, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_131)
    
    point1_132 = NXOpen.Point3d(4.0000000000000036, 65.0, 0.0)
    point2_132 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject55.SetValue(NXOpen.InferSnapType.SnapType.End, line32, NXOpen.View.Null, point1_132, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_132)
    
    dimensionMeasurementBuilder28 = sketchLinearDimensionBuilder27.Measurement
    
    dimensionMeasurementBuilder28.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder28 = sketchLinearDimensionBuilder27.Origin
    
    origin112 = NXOpen.Point3d(1.0599853388638696, 64.25, 0.0)
    originBuilder28.OriginPoint = origin112
    
    originBuilder28.SetInferRelativeToGeometry(True)
    
    nXObject158 = sketchLinearDimensionBuilder27.Commit()
    
    verticalDimension7 = nXObject158
    verticalDimension7.IsOriginCentered = True
    
    sketchLinearDimensionBuilder27.Destroy()
    
    narrowDimensionPreferences28.Dispose()
    dimensionPreferences28.Dispose()
    sketchFindMovableObjectsBuilder78 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject159 = sketchFindMovableObjectsBuilder78.Commit()
    
    sketchFindMovableObjectsBuilder78.Destroy()
    
    markId396 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId397 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder30 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension7)
    
    selectNXObjectList46 = sketchEditDimensionValueBuilder30.ExtraGeometries
    
    foundrelations111 = sketchEditDimensionValueBuilder30.FindRelations()
    
    sketchHelpedDimensionalConstraint27 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line34] StartVertex] [[Curve Line34] EndVertex]")
    sketchHelpedDimensionalConstraint27.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId397, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId397, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint27.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId398 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId398, None)
    
    markId399 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder30.DimValue = 2.0
    
    nXObject160 = sketchEditDimensionValueBuilder30.Commit()
    
    theSession.SetUndoMarkName(markId399, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId399, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId397, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId400 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    selectNXObjectList47 = sketchEditDimensionValueBuilder30.ExtraGeometries
    
    objects15 = [NXOpen.NXObject.Null] * 1 
    objects15[0] = line36
    selectNXObjectList47.SetArray(objects15)
    
    sketchEditDimensionValueBuilder30.RestoreOperation()
    
    sketchEditDimensionValueBuilder30.LoadExtraGeometry()
    
    selectNXObjectList48 = sketchEditDimensionValueBuilder30.ExtraGeometries
    
    theSession.ActiveSketch.Update()
    
    theSession.SetUndoMarkName(markId400, "Edit Dimension Value - Selection")
    
    theSession.SetUndoMarkVisibility(markId400, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId397, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId401 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId402 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint27.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId402, None)
    
    theSession.SetUndoMarkName(markId397, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder30.Destroy()
    
    theSession.DeleteUndoMark(markId401, None)
    
    theSession.SetUndoMarkVisibility(markId397, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId400, None)
    
    theSession.DeleteUndoMark(markId399, None)
    
    theSession.DeleteUndoMark(markId397, None)
    
    sketchFindMovableObjectsBuilder79 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject161 = sketchFindMovableObjectsBuilder79.Commit()
    
    sketchFindMovableObjectsBuilder79.Destroy()
    
    markId403 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder35 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects79 = [None] * 1 
    dragobjects79[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects79[0].Geometry = line36
    dragobjects79[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects79[0].PointIndex = 0
    sketchDragGeometryBuilder35.SetDragGeometry(dragobjects79)
    
    sketchDragGeometryBuilder35.SplineLinearScale = False
    
    foundrelations112 = sketchDragGeometryBuilder35.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects80 = [None] * 1 
    dragobjects80[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects80[0].Geometry = line36
    dragobjects80[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects80[0].PointIndex = 0
    sketchDragGeometryBuilder35.SetDragGeometry(dragobjects80)
    
    foundrelations113 = sketchDragGeometryBuilder35.FindRelations()
    
    sketchDragGeometryBuilder35.Destroy()
    
    markId404 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences29 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences29 = dimensionPreferences29.GetNarrowDimensionPreferences()
    
    option29 = narrowDimensionPreferences29.DimensionDisplayOption
    
    sketchLinearDimensionBuilder28 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder29 = sketchLinearDimensionBuilder28.Driving
    
    drivingValueBuilder29.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject56 = sketchLinearDimensionBuilder28.FirstAssociativity
    
    selectNXObject57 = sketchLinearDimensionBuilder28.SecondAssociativity
    
    point1_135 = NXOpen.Point3d(4.0000000000000036, 58.0, 0.0)
    point2_135 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject56.SetValue(NXOpen.InferSnapType.SnapType.Start, line36, NXOpen.View.Null, point1_135, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_135)
    
    point1_136 = NXOpen.Point3d(4.0000000000000036, 59.500000000000021, 0.0)
    point2_136 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject57.SetValue(NXOpen.InferSnapType.SnapType.End, line36, NXOpen.View.Null, point1_136, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_136)
    
    dimensionMeasurementBuilder29 = sketchLinearDimensionBuilder28.Measurement
    
    dimensionMeasurementBuilder29.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder29 = sketchLinearDimensionBuilder28.Origin
    
    origin114 = NXOpen.Point3d(1.0599853388638696, 58.750000000000014, 0.0)
    originBuilder29.OriginPoint = origin114
    
    originBuilder29.SetInferRelativeToGeometry(True)
    
    nXObject162 = sketchLinearDimensionBuilder28.Commit()
    
    verticalDimension8 = nXObject162
    verticalDimension8.IsOriginCentered = True
    
    sketchLinearDimensionBuilder28.Destroy()
    
    narrowDimensionPreferences29.Dispose()
    dimensionPreferences29.Dispose()
    sketchFindMovableObjectsBuilder80 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject163 = sketchFindMovableObjectsBuilder80.Commit()
    
    sketchFindMovableObjectsBuilder80.Destroy()
    
    markId405 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId406 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder31 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension8)
    
    selectNXObjectList49 = sketchEditDimensionValueBuilder31.ExtraGeometries
    
    foundrelations114 = sketchEditDimensionValueBuilder31.FindRelations()
    
    sketchHelpedDimensionalConstraint28 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line38] StartVertex] [[Curve Line38] EndVertex]")
    sketchHelpedDimensionalConstraint28.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId406, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId406, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint28.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId407 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId407, None)
    
    markId408 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder31.DimValue = 2.0
    
    nXObject164 = sketchEditDimensionValueBuilder31.Commit()
    
    theSession.SetUndoMarkName(markId408, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId408, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId406, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId409 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId410 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint28.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId410, None)
    
    theSession.SetUndoMarkName(markId406, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder31.Destroy()
    
    theSession.DeleteUndoMark(markId409, None)
    
    theSession.SetUndoMarkVisibility(markId406, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId408, None)
    
    theSession.DeleteUndoMark(markId406, None)
    
    sketchFindMovableObjectsBuilder81 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject165 = sketchFindMovableObjectsBuilder81.Commit()
    
    sketchFindMovableObjectsBuilder81.Destroy()
    
    markId411 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder36 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects81 = [None] * 1 
    dragobjects81[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects81[0].Geometry = line31
    dragobjects81[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects81[0].PointIndex = 0
    sketchDragGeometryBuilder36.SetDragGeometry(dragobjects81)
    
    sketchDragGeometryBuilder36.SplineLinearScale = False
    
    foundrelations115 = sketchDragGeometryBuilder36.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects82 = [None] * 2 
    dragobjects82[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects82[1] = NXOpen.Sketch.SketchGeometry()
    dragobjects82[0].Geometry = line31
    dragobjects82[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects82[0].PointIndex = 0
    dragobjects82[1].Geometry = line33
    dragobjects82[1].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects82[1].PointIndex = 0
    sketchDragGeometryBuilder36.SetDragGeometry(dragobjects82)
    
    foundrelations116 = sketchDragGeometryBuilder36.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects83 = [None] * 2 
    dragobjects83[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects83[1] = NXOpen.Sketch.SketchGeometry()
    dragobjects83[0].Geometry = line31
    dragobjects83[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects83[0].PointIndex = 0
    dragobjects83[1].Geometry = line33
    dragobjects83[1].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects83[1].PointIndex = 0
    sketchDragGeometryBuilder36.SetDragGeometry(dragobjects83)
    
    foundrelations117 = sketchDragGeometryBuilder36.FindRelations()
    
    sketchDragGeometryBuilder36.Destroy()
    
    markId412 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences30 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences30 = dimensionPreferences30.GetNarrowDimensionPreferences()
    
    option30 = narrowDimensionPreferences30.DimensionDisplayOption
    
    sketchLinearDimensionBuilder29 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder30 = sketchLinearDimensionBuilder29.Driving
    
    drivingValueBuilder30.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder30 = sketchLinearDimensionBuilder29.Measurement
    
    dimensionMeasurementBuilder30.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject58 = sketchLinearDimensionBuilder29.FirstAssociativity
    
    selectNXObject59 = sketchLinearDimensionBuilder29.SecondAssociativity
    
    point1_141 = NXOpen.Point3d(7.0794258511548627, 63.5, 0.0)
    point2_141 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject58.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line31, NXOpen.View.Null, point1_141, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_141)
    
    point1_142 = NXOpen.Point3d(10.000000000000004, 60.000000000000007, 0.0)
    point2_142 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject59.SetValue(NXOpen.InferSnapType.SnapType.End, line33, NXOpen.View.Null, point1_142, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_142)
    
    originBuilder30 = sketchLinearDimensionBuilder29.Origin
    
    origin117 = NXOpen.Point3d(7.96447915358873, 61.75, 0.0)
    originBuilder30.OriginPoint = origin117
    
    originBuilder30.SetInferRelativeToGeometry(True)
    
    nXObject166 = sketchLinearDimensionBuilder29.Commit()
    
    perpendicularDimension16 = nXObject166
    perpendicularDimension16.IsOriginCentered = True
    
    sketchLinearDimensionBuilder29.Destroy()
    
    narrowDimensionPreferences30.Dispose()
    dimensionPreferences30.Dispose()
    sketchFindMovableObjectsBuilder82 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject167 = sketchFindMovableObjectsBuilder82.Commit()
    
    sketchFindMovableObjectsBuilder82.Destroy()
    
    markId413 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId414 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder32 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension16)
    
    selectNXObjectList50 = sketchEditDimensionValueBuilder32.ExtraGeometries
    
    foundrelations118 = sketchEditDimensionValueBuilder32.FindRelations()
    
    sketchHelpedDimensionalConstraint29 = theSession.ActiveSketch.FindObject("PerpendicularDim [Curve Line33] [[Curve Line35] EndVertex]")
    sketchHelpedDimensionalConstraint29.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId414, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId414, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint29.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId415 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId415, None)
    
    markId416 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder32.DimValue = 6.0
    
    nXObject168 = sketchEditDimensionValueBuilder32.Commit()
    
    theSession.SetUndoMarkName(markId416, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId416, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId414, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId417 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId418 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint29.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId418, None)
    
    theSession.SetUndoMarkName(markId414, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder32.Destroy()
    
    theSession.DeleteUndoMark(markId417, None)
    
    theSession.SetUndoMarkVisibility(markId414, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId416, None)
    
    theSession.DeleteUndoMark(markId414, None)
    
    sketchFindMovableObjectsBuilder83 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject169 = sketchFindMovableObjectsBuilder83.Commit()
    
    sketchFindMovableObjectsBuilder83.Destroy()
    
    markId419 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder37 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects84 = [None] * 1 
    dragobjects84[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects84[0].Geometry = line35
    dragobjects84[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects84[0].PointIndex = 0
    sketchDragGeometryBuilder37.SetDragGeometry(dragobjects84)
    
    sketchDragGeometryBuilder37.SplineLinearScale = False
    
    foundrelations119 = sketchDragGeometryBuilder37.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects85 = [None] * 1 
    dragobjects85[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects85[0].Geometry = line35
    dragobjects85[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects85[0].PointIndex = 0
    sketchDragGeometryBuilder37.SetDragGeometry(dragobjects85)
    
    foundrelations120 = sketchDragGeometryBuilder37.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects86 = [None] * 1 
    dragobjects86[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects86[0].Geometry = line35
    dragobjects86[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects86[0].PointIndex = 0
    sketchDragGeometryBuilder37.SetDragGeometry(dragobjects86)
    
    foundrelations121 = sketchDragGeometryBuilder37.FindRelations()
    
    sketchDragGeometryBuilder37.Destroy()
    
    markId420 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences31 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences31 = dimensionPreferences31.GetNarrowDimensionPreferences()
    
    option31 = narrowDimensionPreferences31.DimensionDisplayOption
    
    sketchLinearDimensionBuilder30 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder31 = sketchLinearDimensionBuilder30.Driving
    
    drivingValueBuilder31.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder31 = sketchLinearDimensionBuilder30.Measurement
    
    dimensionMeasurementBuilder31.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject60 = sketchLinearDimensionBuilder30.FirstAssociativity
    
    selectNXObject61 = sketchLinearDimensionBuilder30.SecondAssociativity
    
    line38 = theSession.ActiveSketch.FindObject("Curve Included Curve29")
    point1_147 = NXOpen.Point3d(12.832272316975011, 0.0, 0.0)
    point2_147 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject60.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line38, NXOpen.View.Null, point1_147, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_147)
    
    point1_148 = NXOpen.Point3d(10.000000000000004, 55.499999999999993, 0.0)
    point2_148 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject61.SetValue(NXOpen.InferSnapType.SnapType.Start, line35, NXOpen.View.Null, point1_148, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_148)
    
    originBuilder31 = sketchLinearDimensionBuilder30.Origin
    
    origin120 = NXOpen.Point3d(8.0751108163929679, 27.749999999999996, 0.0)
    originBuilder31.OriginPoint = origin120
    
    originBuilder31.SetInferRelativeToGeometry(True)
    
    nXObject170 = sketchLinearDimensionBuilder30.Commit()
    
    perpendicularDimension17 = nXObject170
    perpendicularDimension17.IsOriginCentered = True
    
    sketchLinearDimensionBuilder30.Destroy()
    
    narrowDimensionPreferences31.Dispose()
    dimensionPreferences31.Dispose()
    sketchFindMovableObjectsBuilder84 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject171 = sketchFindMovableObjectsBuilder84.Commit()
    
    sketchFindMovableObjectsBuilder84.Destroy()
    
    markId421 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId422 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder33 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension17)
    
    selectNXObjectList51 = sketchEditDimensionValueBuilder33.ExtraGeometries
    
    foundrelations122 = sketchEditDimensionValueBuilder33.FindRelations()
    
    sketchHelpedDimensionalConstraint30 = theSession.ActiveSketch.FindObject("PerpendicularDim [WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line1] [[Curve Line37] StartVertex]")
    sketchHelpedDimensionalConstraint30.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId422, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId422, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint30.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId423 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId423, None)
    
    markId424 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder33.DimValue = 55.039999999999999
    
    nXObject172 = sketchEditDimensionValueBuilder33.Commit()
    
    theSession.SetUndoMarkName(markId424, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId424, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId422, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId425 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId426 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint30.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId426, None)
    
    theSession.SetUndoMarkName(markId422, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder33.Destroy()
    
    theSession.DeleteUndoMark(markId425, None)
    
    theSession.SetUndoMarkVisibility(markId422, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId424, None)
    
    theSession.DeleteUndoMark(markId422, None)
    
    sketchFindMovableObjectsBuilder85 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject173 = sketchFindMovableObjectsBuilder85.Commit()
    
    sketchFindMovableObjectsBuilder85.Destroy()
    
    scaleAboutPoint216 = NXOpen.Point3d(19.581804316349437, 7.9101638905027212, 0.0)
    viewCenter216 = NXOpen.Point3d(-19.581804316349285, -7.9101638905027016, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint216, viewCenter216)
    
    scaleAboutPoint217 = NXOpen.Point3d(15.665443453079584, 6.0626151216720254, 0.0)
    viewCenter217 = NXOpen.Point3d(-15.665443453079403, -6.0626151216719952, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint217, viewCenter217)
    
    scaleAboutPoint218 = NXOpen.Point3d(11.895116384711278, 5.1333091541164491, 0.0)
    viewCenter218 = NXOpen.Point3d(-11.895116384711132, -5.1333091541164313, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint218, viewCenter218)
    
    scaleAboutPoint219 = NXOpen.Point3d(14.691884820402294, 6.5051417728889476, 0.0)
    viewCenter219 = NXOpen.Point3d(-14.691884820402159, -6.5051417728889245, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint219, viewCenter219)
    
    scaleAboutPoint220 = NXOpen.Point3d(18.254224362698629, 8.2420588789154294, 0.0)
    viewCenter220 = NXOpen.Point3d(-18.254224362698498, -8.242058878915401, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint220, viewCenter220)
    
    scaleAboutPoint221 = NXOpen.Point3d(22.541201296362654, 10.302573598644274, 0.0)
    viewCenter221 = NXOpen.Point3d(-22.541201296362491, -10.302573598644249, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint221, viewCenter221)
    
    rotMatrix12 = NXOpen.Matrix3x3()
    
    rotMatrix12.Xx = 0.99283043863883758
    rotMatrix12.Xy = -0.0073583486012797697
    rotMatrix12.Xz = 0.11930454651049191
    rotMatrix12.Yx = 0.054582432767485235
    rotMatrix12.Yy = 0.91587467265968359
    rotMatrix12.Yz = -0.39773652335899068
    rotMatrix12.Zx = -0.10634132849177254
    rotMatrix12.Zy = 0.40139685933795816
    rotMatrix12.Zz = 0.90970988956272469
    translation12 = NXOpen.Point3d(-18.648558314901344, -38.43902061000275, -17.703331850771136)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix12, translation12, 1.5306046121079664)
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder9 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder9.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject174 = sketchWorkRegionBuilder9.Commit()
    
    sketchWorkRegionBuilder9.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId427 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId428 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder14 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section14 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder14.Section = section14
    
    extrudeBuilder14.AllowSelfIntersectingSection(True)
    
    expression48 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder14.DistanceTolerance = 0.01
    
    extrudeBuilder14.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies55 = [NXOpen.Body.Null] * 1 
    targetBodies55[0] = NXOpen.Body.Null
    extrudeBuilder14.BooleanOperation.SetTargetBodies(targetBodies55)
    
    extrudeBuilder14.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder14.Limits.EndExtend.Value.SetFormula("100")
    
    extrudeBuilder14.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies56 = [NXOpen.Body.Null] * 1 
    targetBodies56[0] = body1
    extrudeBuilder14.BooleanOperation.SetTargetBodies(targetBodies56)
    
    extrudeBuilder14.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder14.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder14.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder14.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder14 = extrudeBuilder14.SmartVolumeProfile
    
    smartVolumeProfileBuilder14.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder14.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId428, "Extrude Dialog")
    
    section14.DistanceTolerance = 0.01
    
    section14.ChainingTolerance = 0.0094999999999999998
    
    section14.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId429 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions10 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions10.SetSelectedFromInactive(False)
    
    curves9 = [NXOpen.ICurve.Null] * 16 
    curves9[0] = line21
    curves9[1] = line22
    curves9[2] = line23
    curves9[3] = line24
    curves9[4] = line25
    curves9[5] = line26
    curves9[6] = line27
    curves9[7] = line28
    curves9[8] = line29
    curves9[9] = line30
    curves9[10] = line31
    curves9[11] = line32
    curves9[12] = line33
    curves9[13] = line34
    curves9[14] = line35
    curves9[15] = line36
    seedPoint9 = NXOpen.Point3d(7.4414380000000016, 56.187145999999998, 0.0)
    regionBoundaryRule9 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch9, curves9, seedPoint9, 0.01, selectionIntentRuleOptions10)
    
    selectionIntentRuleOptions10.Dispose()
    selectionIntentRuleOptions11 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions11.SetSelectedFromInactive(False)
    
    curves10 = [NXOpen.ICurve.Null] * 16 
    curves10[0] = line21
    curves10[1] = line22
    curves10[2] = line23
    curves10[3] = line24
    curves10[4] = line25
    curves10[5] = line26
    curves10[6] = line27
    curves10[7] = line28
    curves10[8] = line29
    curves10[9] = line30
    curves10[10] = line31
    curves10[11] = line32
    curves10[12] = line33
    curves10[13] = line34
    curves10[14] = line35
    curves10[15] = line36
    seedPoint10 = NXOpen.Point3d(7.4414380000000016, 64.187146000000027, 0.0)
    regionBoundaryRule10 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch9, curves10, seedPoint10, 0.01, selectionIntentRuleOptions11)
    
    selectionIntentRuleOptions11.Dispose()
    selectionIntentRuleOptions12 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions12.SetSelectedFromInactive(False)
    
    curves11 = [NXOpen.ICurve.Null] * 16 
    curves11[0] = line21
    curves11[1] = line22
    curves11[2] = line23
    curves11[3] = line24
    curves11[4] = line25
    curves11[5] = line26
    curves11[6] = line27
    curves11[7] = line28
    curves11[8] = line29
    curves11[9] = line30
    curves11[10] = line31
    curves11[11] = line32
    curves11[12] = line33
    curves11[13] = line34
    curves11[14] = line35
    curves11[15] = line36
    seedPoint11 = NXOpen.Point3d(60.441437999999998, 64.187145999999984, 0.0)
    regionBoundaryRule11 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch9, curves11, seedPoint11, 0.01, selectionIntentRuleOptions12)
    
    selectionIntentRuleOptions12.Dispose()
    selectionIntentRuleOptions13 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions13.SetSelectedFromInactive(False)
    
    curves12 = [NXOpen.ICurve.Null] * 16 
    curves12[0] = line21
    curves12[1] = line22
    curves12[2] = line23
    curves12[3] = line24
    curves12[4] = line25
    curves12[5] = line26
    curves12[6] = line27
    curves12[7] = line28
    curves12[8] = line29
    curves12[9] = line30
    curves12[10] = line31
    curves12[11] = line32
    curves12[12] = line33
    curves12[13] = line34
    curves12[14] = line35
    curves12[15] = line36
    seedPoint12 = NXOpen.Point3d(60.441437999999998, 56.187145999999984, 0.0)
    regionBoundaryRule12 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch9, curves12, seedPoint12, 0.01, selectionIntentRuleOptions13)
    
    selectionIntentRuleOptions13.Dispose()
    section14.AllowSelfIntersection(True)
    
    section14.AllowDegenerateCurves(False)
    
    rules9 = [None] * 4 
    rules9[0] = regionBoundaryRule9
    rules9[1] = regionBoundaryRule10
    rules9[2] = regionBoundaryRule11
    rules9[3] = regionBoundaryRule12
    helpPoint9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section14.AddToSection(rules9, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint9, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId429, None)
    
    markId430 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId431 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId431, None)
    
    direction25 = workPart.Directions.CreateDirection(sketch9, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder14.Direction = direction25
    
    theSession.DeleteUndoMark(markId430, None)
    
    extrudeBuilder14.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder14.Limits.EndExtend.Value.SetFormula("-10")
    
    extrudeBuilder14.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies57 = [NXOpen.Body.Null] * 1 
    targetBodies57[0] = body1
    extrudeBuilder14.BooleanOperation.SetTargetBodies(targetBodies57)
    
    rotMatrix13 = NXOpen.Matrix3x3()
    
    rotMatrix13.Xx = 0.87832163852591061
    rotMatrix13.Xy = 0.46784266395003199
    rotMatrix13.Xz = -0.098358228355819421
    rotMatrix13.Yx = 0.097537283308788456
    rotMatrix13.Yy = 0.026048505809132361
    rotMatrix13.Yz = 0.99489092553397596
    rotMatrix13.Zx = 0.46801450582423049
    rotMatrix13.Zy = -0.8834278222544546
    rotMatrix13.Zz = -0.022753136154203685
    translation13 = NXOpen.Point3d(-78.849157010905842, -36.110648440824406, 36.371814800356653)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix13, translation13, 1.9132557651349547)
    
    markId432 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId432, None)
    
    markId433 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder14.ParentFeatureInternal = False
    
    feature18 = extrudeBuilder14.CommitFeature()
    
    theSession.DeleteUndoMark(markId433, None)
    
    theSession.SetUndoMarkName(markId428, "Extrude")
    
    expression49 = extrudeBuilder14.Limits.StartExtend.Value
    expression50 = extrudeBuilder14.Limits.EndExtend.Value
    extrudeBuilder14.Destroy()
    
    workPart.Expressions.Delete(expression48)
    
    rotMatrix14 = NXOpen.Matrix3x3()
    
    rotMatrix14.Xx = 0.99572742824052052
    rotMatrix14.Xy = 0.0028676168033218864
    rotMatrix14.Xz = -0.092296616532702228
    rotMatrix14.Yx = 0.09225916936418517
    rotMatrix14.Yy = -0.073003618160586856
    rotMatrix14.Yz = 0.99305524388308342
    rotMatrix14.Zx = -0.0038902850468819231
    rotMatrix14.Zy = -0.99732755326889933
    rotMatrix14.Zz = -0.072956268907623315
    translation14 = NXOpen.Point3d(-57.995001564979823, -29.850834165965068, 71.520086113490024)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix14, translation14, 1.9132557651349547)
    
    rotMatrix15 = NXOpen.Matrix3x3()
    
    rotMatrix15.Xx = 0.99344230777815123
    rotMatrix15.Xy = -0.041237586461452147
    rotMatrix15.Xz = -0.10663884179440157
    rotMatrix15.Yx = 0.058726826688010957
    rotMatrix15.Yy = -0.61621224852534096
    rotMatrix15.Yz = 0.78538756330521042
    rotMatrix15.Zx = -0.098099648029814718
    rotMatrix15.Zy = -0.78649979417045857
    rotMatrix15.Zz = -0.60974956566302563
    translation15 = NXOpen.Point3d(-55.211582141351229, 4.7536242164906248, 64.522982346559516)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix15, translation15, 1.9132557651349547)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId434 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId435 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId436 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder10 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin121 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal10 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane25 = workPart.Planes.CreatePlane(origin121, normal10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder10.PlaneReference = plane25
    
    expression51 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression52 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder10 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder10 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder10.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId436, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder10.UseWorkPartOrigin = False
    
    coordinates21 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point34 = workPart.Points.CreatePoint(coordinates21)
    
    origin122 = NXOpen.Point3d(68.965449656829463, 0.0, 8.9654496568294597)
    matrix15 = NXOpen.Matrix3x3()
    
    matrix15.Xx = 1.0
    matrix15.Xy = 0.0
    matrix15.Xz = 0.0
    matrix15.Yx = -0.0
    matrix15.Yy = 0.0
    matrix15.Yz = 1.0
    matrix15.Zx = 0.0
    matrix15.Zy = -1.0
    matrix15.Zz = 0.0
    plane26 = workPart.Planes.CreateFixedTypePlane(origin122, matrix15, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point35 = workPart.Points.CreatePoint(coordinates22)
    
    origin123 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector15 = NXOpen.Vector3d(0.0, -1.0, 0.0)
    direction26 = workPart.Directions.CreateDirection(origin123, vector15, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin124 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector16 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction27 = workPart.Directions.CreateDirection(origin124, vector16, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin125 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix16 = NXOpen.Matrix3x3()
    
    matrix16.Xx = 1.0
    matrix16.Xy = 0.0
    matrix16.Xz = 0.0
    matrix16.Yx = -0.0
    matrix16.Yy = 0.0
    matrix16.Yz = 1.0
    matrix16.Zx = 0.0
    matrix16.Zy = -1.0
    matrix16.Zz = 0.0
    plane27 = workPart.Planes.CreateFixedTypePlane(origin125, matrix16, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform10 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane27, direction27, point35, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem10 = workPart.CoordinateSystems.CreateCoordinateSystem(xform10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder10.CoordinateSystem = cartesianCoordinateSystem10
    
    simpleSketchInPlaceBuilder10.HorizontalReference.Value = datumAxis1
    
    point36 = simpleSketchInPlaceBuilder10.SketchOrigin
    
    simpleSketchInPlaceBuilder10.SketchOrigin = point36
    
    markId437 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId437, None)
    
    markId438 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject175 = simpleSketchInPlaceBuilder10.Commit()
    
    sketch10 = nXObject175
    feature19 = sketch10.Feature
    
    markId439 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs12 = theSession.UpdateManager.DoUpdate(markId439)
    
    sketch10.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder86 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject176 = sketchFindMovableObjectsBuilder86.Commit()
    
    sketchFindMovableObjectsBuilder86.Destroy()
    
    theSession.DeleteUndoMark(markId438, None)
    
    theSession.SetUndoMarkName(markId436, "Create Sketch")
    
    sketchInPlaceBuilder10.Destroy()
    
    sketchAlongPathBuilder10.Destroy()
    
    simpleSketchInPlaceBuilder10.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression52)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression51)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane25.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId435, None, True)
    
    markId440 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_007")
    
    scaleAboutPoint222 = NXOpen.Point3d(69.144789252646206, -8.9196778135913153, 0.0)
    viewCenter222 = NXOpen.Point3d(-69.144789252646049, 8.9196778135913863, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint222, viewCenter222)
    
    scaleAboutPoint223 = NXOpen.Point3d(55.315831402116949, -7.1357422508730419, 0.0)
    viewCenter223 = NXOpen.Point3d(-55.315831402116778, 7.1357422508731174, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint223, viewCenter223)
    
    scaleAboutPoint224 = NXOpen.Point3d(44.252665121693568, -5.7085938006984334, 0.0)
    viewCenter224 = NXOpen.Point3d(-44.252665121693433, 5.7085938006985009, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint224, viewCenter224)
    
    scaleAboutPoint225 = NXOpen.Point3d(33.915242549266004, -3.3632025492486681, 0.0)
    viewCenter225 = NXOpen.Point3d(-33.915242549265827, 3.3632025492487405, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint225, viewCenter225)
    
    scaleAboutPoint226 = NXOpen.Point3d(27.132194039412813, -2.6905620393989338, 0.0)
    viewCenter226 = NXOpen.Point3d(-27.132194039412639, 2.6905620393990013, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint226, viewCenter226)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Circle...
    # ----------------------------------------------
    markId441 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId442 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId442, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix2 = theSession.ActiveSketch.Orientation
    
    center2 = NXOpen.Point3d(59.5, 0.0, -6.5)
    arc2 = workPart.Curves.CreateArc(center2, nXMatrix2, 2.3699628293953436, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    scaleAboutPoint227 = NXOpen.Point3d(-24.741842080199248, 4.5088155439191411, 0.0)
    viewCenter227 = NXOpen.Point3d(24.741842080199419, -4.5088155439190789, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint227, viewCenter227)
    
    scaleAboutPoint228 = NXOpen.Point3d(-30.870659188893317, 5.4094457844758512, 0.0)
    viewCenter228 = NXOpen.Point3d(30.870659188893491, -5.4094457844757793, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint228, viewCenter228)
    
    scaleAboutPoint229 = NXOpen.Point3d(-38.588323986116677, 6.6910029664001041, 0.0)
    viewCenter229 = NXOpen.Point3d(38.588323986116855, -6.6910029664000259, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint229, viewCenter229)
    
    scaleAboutPoint230 = NXOpen.Point3d(-48.235404982645861, 8.3637537080001128, 0.0)
    viewCenter230 = NXOpen.Point3d(48.235404982646024, -8.3637537080000381, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint230, viewCenter230)
    
    scaleAboutPoint231 = NXOpen.Point3d(-70.140474217884147, 6.9144789252646532, 0.0)
    viewCenter231 = NXOpen.Point3d(70.140474217884318, -6.9144789252645777, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint231, viewCenter231)
    
    scaleAboutPoint232 = NXOpen.Point3d(-56.112379374307302, 5.443077809968341, 0.0)
    viewCenter232 = NXOpen.Point3d(56.112379374307473, -5.4430778099682655, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint232, viewCenter232)
    
    scaleAboutPoint233 = NXOpen.Point3d(-44.960707763640549, 4.3544622479746797, 0.0)
    viewCenter233 = NXOpen.Point3d(44.960707763640706, -4.3544622479746078, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint233, viewCenter233)
    
    markId443 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId443, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix3 = theSession.ActiveSketch.Orientation
    
    center3 = NXOpen.Point3d(7.2149545214409656, 0.0, -6.5)
    arc3 = workPart.Curves.CreateArc(center3, nXMatrix3, 0.066852114401099172, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    sketchFindMovableObjectsBuilder87 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject177 = sketchFindMovableObjectsBuilder87.Commit()
    
    sketchFindMovableObjectsBuilder87.Destroy()
    
    markId444 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder38 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects87 = [None] * 1 
    dragobjects87[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects87[0].Geometry = arc3
    dragobjects87[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects87[0].PointIndex = 0
    sketchDragGeometryBuilder38.SetDragGeometry(dragobjects87)
    
    sketchDragGeometryBuilder38.SplineLinearScale = False
    
    foundrelations123 = sketchDragGeometryBuilder38.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    sketchDragGeometryBuilder38.Destroy()
    
    markId445 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    markId446 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Sketch Delete")
    
    objects16 = [NXOpen.NXObject.Null] * 1 
    objects16[0] = arc3
    errorList10 = theSession.ActiveSketch.DeleteObjects(objects16)
    
    errorList10.Dispose()
    sketchFindMovableObjectsBuilder88 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject178 = sketchFindMovableObjectsBuilder88.Commit()
    
    sketchFindMovableObjectsBuilder88.Destroy()
    
    theSession.DeleteUndoMark(markId445, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Circle...
    # ----------------------------------------------
    markId447 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId448 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId448, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix4 = theSession.ActiveSketch.Orientation
    
    center4 = NXOpen.Point3d(6.0, 0.0, -6.5)
    arc4 = workPart.Curves.CreateArc(center4, nXMatrix4, 2.8395541718417983, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    sketchFindMovableObjectsBuilder89 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject179 = sketchFindMovableObjectsBuilder89.Commit()
    
    sketchFindMovableObjectsBuilder89.Destroy()
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Circle...
    # ----------------------------------------------
    markId449 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    theSession.DeleteUndoMark(markId449, "Curve")
    
    sketchFindMovableObjectsBuilder90 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject180 = sketchFindMovableObjectsBuilder90.Commit()
    
    sketchFindMovableObjectsBuilder90.Destroy()
    
    markId450 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder39 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects88 = [None] * 1 
    dragobjects88[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects88[0].Geometry = arc4
    dragobjects88[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects88[0].PointIndex = 0
    sketchDragGeometryBuilder39.SetDragGeometry(dragobjects88)
    
    sketchDragGeometryBuilder39.SplineLinearScale = False
    
    foundrelations124 = sketchDragGeometryBuilder39.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects89 = [None] * 1 
    dragobjects89[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects89[0].Geometry = arc4
    dragobjects89[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects89[0].PointIndex = 0
    sketchDragGeometryBuilder39.SetDragGeometry(dragobjects89)
    
    foundrelations125 = sketchDragGeometryBuilder39.FindRelations()
    
    sketchDragGeometryBuilder39.Destroy()
    
    markId451 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences32 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences32 = dimensionPreferences32.GetNarrowDimensionPreferences()
    
    option32 = narrowDimensionPreferences32.DimensionDisplayOption
    
    sketchRadialDimensionBuilder2 = workPart.Sketches.CreateRadialDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder32 = sketchRadialDimensionBuilder2.Driving
    
    drivingValueBuilder32.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject62 = sketchRadialDimensionBuilder2.FirstAssociativity
    
    point1_151 = NXOpen.Point3d(6.0, 0.0, -6.5)
    point2_151 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject62.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc4, NXOpen.View.Null, point1_151, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_151)
    
    dimensionMeasurementBuilder32 = sketchRadialDimensionBuilder2.Measurement
    
    dimensionMeasurementBuilder32.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Diametral
    
    originBuilder32 = sketchRadialDimensionBuilder2.Origin
    
    origin128 = NXOpen.Point3d(11.082401007450528, 0.0, -4.0079013119093894)
    originBuilder32.OriginPoint = origin128
    
    originBuilder32.SetInferRelativeToGeometry(True)
    
    nXObject181 = sketchRadialDimensionBuilder2.Commit()
    
    sketchRadialDimensionBuilder2.Destroy()
    
    narrowDimensionPreferences32.Dispose()
    dimensionPreferences32.Dispose()
    sketchFindMovableObjectsBuilder91 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject182 = sketchFindMovableObjectsBuilder91.Commit()
    
    sketchFindMovableObjectsBuilder91.Destroy()
    
    markId452 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId453 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    diameterDimension2 = nXObject181
    sketchEditDimensionValueBuilder34 = workPart.Sketches.CreateEditDimensionValueBuilder(diameterDimension2)
    
    selectNXObjectList52 = sketchEditDimensionValueBuilder34.ExtraGeometries
    
    foundrelations126 = sketchEditDimensionValueBuilder34.FindRelations()
    
    sketchDimensionalConstraint2 = theSession.ActiveSketch.FindObject("DiameterDim [Curve Arc4]")
    sketchDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId453, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId453, None, NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId454 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId454, None)
    
    markId455 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder34.DimValue = 3.0
    
    theSession.ActiveSketch.Scale(0.52825193999476816)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin129 = NXOpen.Point3d(5.8542998319857134, 0.0, -2.1171816433237112)
    diameterDimension2.AnnotationOrigin = origin129
    
    sketchEditDimensionValueBuilder34.RestoreOperation()
    
    sketchEditDimensionValueBuilder34.LoadExtraGeometry()
    
    selectNXObjectList53 = sketchEditDimensionValueBuilder34.ExtraGeometries
    
    foundrelations127 = sketchEditDimensionValueBuilder34.FindRelations()
    
    nXObject183 = sketchEditDimensionValueBuilder34.Commit()
    
    theSession.SetUndoMarkName(markId455, "Edit Dimension Value - Diameter")
    
    theSession.SetUndoMarkVisibility(markId455, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId453, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId456 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId457 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId457, None)
    
    theSession.SetUndoMarkName(markId453, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder34.Destroy()
    
    theSession.DeleteUndoMark(markId456, None)
    
    theSession.SetUndoMarkVisibility(markId453, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId455, None)
    
    theSession.DeleteUndoMark(markId453, None)
    
    sketchFindMovableObjectsBuilder92 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject184 = sketchFindMovableObjectsBuilder92.Commit()
    
    sketchFindMovableObjectsBuilder92.Destroy()
    
    markId458 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder40 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects90 = [None] * 1 
    dragobjects90[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects90[0].Geometry = arc2
    dragobjects90[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects90[0].PointIndex = 0
    sketchDragGeometryBuilder40.SetDragGeometry(dragobjects90)
    
    sketchDragGeometryBuilder40.SplineLinearScale = False
    
    foundrelations128 = sketchDragGeometryBuilder40.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects91 = [None] * 1 
    dragobjects91[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects91[0].Geometry = arc2
    dragobjects91[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects91[0].PointIndex = 0
    sketchDragGeometryBuilder40.SetDragGeometry(dragobjects91)
    
    foundrelations129 = sketchDragGeometryBuilder40.FindRelations()
    
    sketchDragGeometryBuilder40.Destroy()
    
    markId459 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences33 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences33 = dimensionPreferences33.GetNarrowDimensionPreferences()
    
    option33 = narrowDimensionPreferences33.DimensionDisplayOption
    
    sketchRadialDimensionBuilder3 = workPart.Sketches.CreateRadialDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder33 = sketchRadialDimensionBuilder3.Driving
    
    drivingValueBuilder33.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject63 = sketchRadialDimensionBuilder3.FirstAssociativity
    
    point1_153 = NXOpen.Point3d(31.430990429688705, 0.0, -3.4336376099659929)
    point2_153 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject63.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, NXOpen.View.Null, point1_153, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_153)
    
    dimensionMeasurementBuilder33 = sketchRadialDimensionBuilder3.Measurement
    
    dimensionMeasurementBuilder33.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Diametral
    
    originBuilder33 = sketchRadialDimensionBuilder3.Origin
    
    origin131 = NXOpen.Point3d(33.882676085580719, 0.0, -2.2020240280052072)
    originBuilder33.OriginPoint = origin131
    
    originBuilder33.SetInferRelativeToGeometry(True)
    
    nXObject185 = sketchRadialDimensionBuilder3.Commit()
    
    sketchRadialDimensionBuilder3.Destroy()
    
    narrowDimensionPreferences33.Dispose()
    dimensionPreferences33.Dispose()
    sketchFindMovableObjectsBuilder93 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject186 = sketchFindMovableObjectsBuilder93.Commit()
    
    sketchFindMovableObjectsBuilder93.Destroy()
    
    markId460 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId461 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    diameterDimension3 = nXObject185
    sketchEditDimensionValueBuilder35 = workPart.Sketches.CreateEditDimensionValueBuilder(diameterDimension3)
    
    selectNXObjectList54 = sketchEditDimensionValueBuilder35.ExtraGeometries
    
    foundrelations130 = sketchEditDimensionValueBuilder35.FindRelations()
    
    sketchDimensionalConstraint3 = theSession.ActiveSketch.FindObject("DiameterDim [Curve Arc2]")
    sketchDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId461, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId461, None, NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId462 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId462, None)
    
    markId463 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder35.DimValue = 3.0
    
    nXObject187 = sketchEditDimensionValueBuilder35.Commit()
    
    theSession.SetUndoMarkName(markId463, "Edit Dimension Value - Diameter")
    
    theSession.SetUndoMarkVisibility(markId463, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId461, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId464 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId465 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId465, None)
    
    theSession.SetUndoMarkName(markId461, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder35.Destroy()
    
    theSession.DeleteUndoMark(markId464, None)
    
    theSession.SetUndoMarkVisibility(markId461, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId463, None)
    
    theSession.DeleteUndoMark(markId461, None)
    
    sketchFindMovableObjectsBuilder94 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject188 = sketchFindMovableObjectsBuilder94.Commit()
    
    sketchFindMovableObjectsBuilder94.Destroy()
    
    markId466 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder41 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects92 = [None] * 1 
    dragobjects92[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects92[0].Geometry = arc2
    dragobjects92[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects92[0].PointIndex = 0
    sketchDragGeometryBuilder41.SetDragGeometry(dragobjects92)
    
    sketchDragGeometryBuilder41.SplineLinearScale = False
    
    foundrelations131 = sketchDragGeometryBuilder41.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects93 = [None] * 1 
    dragobjects93[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects93[0].Geometry = arc2
    dragobjects93[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects93[0].PointIndex = -1475379104
    sketchDragGeometryBuilder41.SetDragGeometry(dragobjects93)
    
    foundrelations132 = sketchDragGeometryBuilder41.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects94 = [None] * 1 
    dragobjects94[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects94[0].Geometry = arc2
    dragobjects94[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects94[0].PointIndex = -1475379088
    sketchDragGeometryBuilder41.SetDragGeometry(dragobjects94)
    
    foundrelations133 = sketchDragGeometryBuilder41.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects95 = [None] * 1 
    dragobjects95[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects95[0].Geometry = arc2
    dragobjects95[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects95[0].PointIndex = -1475378416
    sketchDragGeometryBuilder41.SetDragGeometry(dragobjects95)
    
    foundrelations134 = sketchDragGeometryBuilder41.FindRelations()
    
    sketchDragGeometryBuilder41.Destroy()
    
    markId467 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences34 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences34 = dimensionPreferences34.GetNarrowDimensionPreferences()
    
    option34 = narrowDimensionPreferences34.DimensionDisplayOption
    
    sketchLinearDimensionBuilder31 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder34 = sketchLinearDimensionBuilder31.Driving
    
    drivingValueBuilder34.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder34 = sketchLinearDimensionBuilder31.Measurement
    
    dimensionMeasurementBuilder34.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject64 = sketchLinearDimensionBuilder31.FirstAssociativity
    
    selectNXObject65 = sketchLinearDimensionBuilder31.SecondAssociativity
    
    extrude5 = feature18
    edge9 = extrude5.FindObject("EDGE * 150 * 250 {(57,55.04,-10)(60,55.04,-10)(63,55.04,-10) EXTRUDE(2)}")
    point1_156 = NXOpen.Point3d(60.459761195862619, 0.0, -10.0)
    point2_156 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject64.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge9, NXOpen.View.Null, point1_156, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_156)
    
    point1_157 = NXOpen.Point3d(31.430990429688705, 0.0, -3.4336376099659929)
    point2_157 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject65.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, NXOpen.View.Null, point1_157, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_157)
    
    originBuilder34 = sketchLinearDimensionBuilder31.Origin
    
    origin133 = NXOpen.Point3d(31.430990429688705, 0.0, -6.7168188049829967)
    originBuilder34.OriginPoint = origin133
    
    originBuilder34.SetInferRelativeToGeometry(True)
    
    nXObject189 = sketchLinearDimensionBuilder31.Commit()
    
    perpendicularDimension18 = nXObject189
    perpendicularDimension18.IsOriginCentered = True
    
    sketchLinearDimensionBuilder31.Destroy()
    
    narrowDimensionPreferences34.Dispose()
    dimensionPreferences34.Dispose()
    sketchFindMovableObjectsBuilder95 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject190 = sketchFindMovableObjectsBuilder95.Commit()
    
    sketchFindMovableObjectsBuilder95.Destroy()
    
    markId468 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId469 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder36 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension18)
    
    selectNXObjectList55 = sketchEditDimensionValueBuilder36.ExtraGeometries
    
    foundrelations135 = sketchEditDimensionValueBuilder36.FindRelations()
    
    sketchHelpedDimensionalConstraint31 = theSession.ActiveSketch.FindObject("PerpendicularDim [WorkPart|.Features|EXTRUDE(12)|EDGE * 150 * 250 {(57,55.04,-10)(60,55.04,-10)(63,55.04,-10) EXTRUDE(2)}] [[Curve Arc2] ArcCenter]")
    sketchHelpedDimensionalConstraint31.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId469, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId469, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint31.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId470 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId470, None)
    
    markId471 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder36.DimValue = 4.0
    
    nXObject191 = sketchEditDimensionValueBuilder36.Commit()
    
    theSession.SetUndoMarkName(markId471, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId471, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId469, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId472 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId473 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint31.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId473, None)
    
    theSession.SetUndoMarkName(markId469, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder36.Destroy()
    
    theSession.DeleteUndoMark(markId472, None)
    
    theSession.SetUndoMarkVisibility(markId469, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId471, None)
    
    theSession.DeleteUndoMark(markId469, None)
    
    sketchFindMovableObjectsBuilder96 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject192 = sketchFindMovableObjectsBuilder96.Commit()
    
    sketchFindMovableObjectsBuilder96.Destroy()
    
    scaleAboutPoint234 = NXOpen.Point3d(-34.779054572441297, 1.3311201668605768, 0.0)
    viewCenter234 = NXOpen.Point3d(34.77905457244146, -1.3311201668605044, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint234, viewCenter234)
    
    scaleAboutPoint235 = NXOpen.Point3d(-43.544622479746351, 1.6639002085757151, 0.0)
    viewCenter235 = NXOpen.Point3d(43.544622479746508, -1.6639002085756365, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint235, viewCenter235)
    
    scaleAboutPoint236 = NXOpen.Point3d(-56.820422016254405, 2.5224019119365608, 0.0)
    viewCenter236 = NXOpen.Point3d(56.820422016254561, -2.5224019119364929, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint236, viewCenter236)
    
    scaleAboutPoint237 = NXOpen.Point3d(-45.668750405587645, 2.0179215295492612, 0.0)
    viewCenter237 = NXOpen.Point3d(45.668750405587801, -2.017921529549195, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint237, viewCenter237)
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    markId474 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder42 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects96 = [None] * 1 
    dragobjects96[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects96[0].Geometry = arc4
    dragobjects96[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects96[0].PointIndex = 0
    sketchDragGeometryBuilder42.SetDragGeometry(dragobjects96)
    
    sketchDragGeometryBuilder42.SplineLinearScale = False
    
    foundrelations136 = sketchDragGeometryBuilder42.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects97 = [None] * 1 
    dragobjects97[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects97[0].Geometry = arc4
    dragobjects97[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects97[0].PointIndex = -1475378416
    sketchDragGeometryBuilder42.SetDragGeometry(dragobjects97)
    
    foundrelations137 = sketchDragGeometryBuilder42.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects98 = [None] * 1 
    dragobjects98[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects98[0].Geometry = arc4
    dragobjects98[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects98[0].PointIndex = -1475379024
    sketchDragGeometryBuilder42.SetDragGeometry(dragobjects98)
    
    foundrelations138 = sketchDragGeometryBuilder42.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects99 = [None] * 1 
    dragobjects99[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects99[0].Geometry = arc4
    dragobjects99[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects99[0].PointIndex = -1475378928
    sketchDragGeometryBuilder42.SetDragGeometry(dragobjects99)
    
    foundrelations139 = sketchDragGeometryBuilder42.FindRelations()
    
    sketchDragGeometryBuilder42.Destroy()
    
    markId475 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences35 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences35 = dimensionPreferences35.GetNarrowDimensionPreferences()
    
    option35 = narrowDimensionPreferences35.DimensionDisplayOption
    
    sketchLinearDimensionBuilder32 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder35 = sketchLinearDimensionBuilder32.Driving
    
    drivingValueBuilder35.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder35 = sketchLinearDimensionBuilder32.Measurement
    
    dimensionMeasurementBuilder35.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject66 = sketchLinearDimensionBuilder32.FirstAssociativity
    
    selectNXObject67 = sketchLinearDimensionBuilder32.SecondAssociativity
    
    edge11 = extrude5.FindObject("EDGE * 330 * 340 {(10,55.04,-10)(10,55.04,-5)(10,55.04,0) EXTRUDE(2)}")
    point1_160 = NXOpen.Point3d(10.000000000000002, 0.0, -5.897751817761085)
    point2_160 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject66.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge11, NXOpen.View.Null, point1_160, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_160)
    
    point1_161 = NXOpen.Point3d(3.1695116399686087, 0.0, -6.0)
    point2_161 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject67.SetValue(NXOpen.InferSnapType.SnapType.Center, arc4, NXOpen.View.Null, point1_161, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_161)
    
    originBuilder35 = sketchLinearDimensionBuilder32.Origin
    
    origin135 = NXOpen.Point3d(6.5847558199843057, 0.0, -6.0)
    originBuilder35.OriginPoint = origin135
    
    originBuilder35.SetInferRelativeToGeometry(True)
    
    nXObject193 = sketchLinearDimensionBuilder32.Commit()
    
    perpendicularDimension19 = nXObject193
    perpendicularDimension19.IsOriginCentered = True
    
    sketchLinearDimensionBuilder32.Destroy()
    
    narrowDimensionPreferences35.Dispose()
    dimensionPreferences35.Dispose()
    sketchFindMovableObjectsBuilder97 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject194 = sketchFindMovableObjectsBuilder97.Commit()
    
    sketchFindMovableObjectsBuilder97.Destroy()
    
    markId476 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId477 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder37 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension19)
    
    selectNXObjectList56 = sketchEditDimensionValueBuilder37.ExtraGeometries
    
    foundrelations140 = sketchEditDimensionValueBuilder37.FindRelations()
    
    sketchHelpedDimensionalConstraint32 = theSession.ActiveSketch.FindObject("PerpendicularDim [WorkPart|.Features|EXTRUDE(12)|EDGE * 330 * 340 {(10,55.04,-10)(10,55.04,-5)(10,55.04,0) EXTRUDE(2)}] [[Curve Arc4] ArcCenter]")
    sketchHelpedDimensionalConstraint32.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId477, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId477, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint32.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId478 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId478, None)
    
    markId479 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder37.DimValue = 3.0
    
    nXObject195 = sketchEditDimensionValueBuilder37.Commit()
    
    theSession.SetUndoMarkName(markId479, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId479, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId477, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId480 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId481 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint32.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId481, None)
    
    theSession.SetUndoMarkName(markId477, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder37.Destroy()
    
    theSession.DeleteUndoMark(markId480, None)
    
    theSession.SetUndoMarkVisibility(markId477, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId479, None)
    
    theSession.DeleteUndoMark(markId477, None)
    
    sketchFindMovableObjectsBuilder98 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject196 = sketchFindMovableObjectsBuilder98.Commit()
    
    sketchFindMovableObjectsBuilder98.Destroy()
    
    markId482 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder43 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects100 = [None] * 1 
    dragobjects100[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects100[0].Geometry = arc2
    dragobjects100[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects100[0].PointIndex = 0
    sketchDragGeometryBuilder43.SetDragGeometry(dragobjects100)
    
    sketchDragGeometryBuilder43.SplineLinearScale = False
    
    foundrelations141 = sketchDragGeometryBuilder43.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects101 = [None] * 1 
    dragobjects101[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects101[0].Geometry = arc2
    dragobjects101[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects101[0].PointIndex = -1475378416
    sketchDragGeometryBuilder43.SetDragGeometry(dragobjects101)
    
    foundrelations142 = sketchDragGeometryBuilder43.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    scaleAboutPoint238 = NXOpen.Point3d(16.879736584018858, 1.8409108690624814, 0.0)
    viewCenter238 = NXOpen.Point3d(-16.879736584018698, -1.8409108690624234, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint238, viewCenter238)
    
    rotMatrix16 = NXOpen.Matrix3x3()
    
    rotMatrix16.Xx = 0.99973123562343846
    rotMatrix16.Xy = 0.022562787477768763
    rotMatrix16.Xz = 0.0053270198109276563
    rotMatrix16.Yx = 0.0002687463173822747
    rotMatrix16.Yy = -0.24104390177536353
    rotMatrix16.Yz = 0.97051417567819442
    rotMatrix16.Zx = 0.02318155073004971
    rotMatrix16.Zy = -0.97025190442386722
    rotMatrix16.Zz = -0.24098518142742342
    translation16 = NXOpen.Point3d(-43.519281780070713, 23.211833845125739, -3.1757787783709475)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix16, translation16, 3.7368276662792086)
    
    dragobjects102 = [None] * 1 
    dragobjects102[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects102[0].Geometry = arc2
    dragobjects102[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects102[0].PointIndex = -1475379024
    sketchDragGeometryBuilder43.SetDragGeometry(dragobjects102)
    
    foundrelations143 = sketchDragGeometryBuilder43.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects103 = [None] * 1 
    dragobjects103[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects103[0].Geometry = arc2
    dragobjects103[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects103[0].PointIndex = -1475378672
    sketchDragGeometryBuilder43.SetDragGeometry(dragobjects103)
    
    foundrelations144 = sketchDragGeometryBuilder43.FindRelations()
    
    sketchDragGeometryBuilder43.Destroy()
    
    markId483 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences36 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences36 = dimensionPreferences36.GetNarrowDimensionPreferences()
    
    option36 = narrowDimensionPreferences36.DimensionDisplayOption
    
    sketchLinearDimensionBuilder33 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder36 = sketchLinearDimensionBuilder33.Driving
    
    drivingValueBuilder36.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder36 = sketchLinearDimensionBuilder33.Measurement
    
    dimensionMeasurementBuilder36.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject68 = sketchLinearDimensionBuilder33.FirstAssociativity
    
    selectNXObject69 = sketchLinearDimensionBuilder33.SecondAssociativity
    
    edge13 = extrude5.FindObject("EDGE * 250 * 260 {(63,55.04,-10)(63,55.04,-5)(63,55.04,0) EXTRUDE(2)}")
    point1_164 = NXOpen.Point3d(63.0, 0.0, -5.3402849067794023)
    point2_164 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject68.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge13, NXOpen.View.Null, point1_164, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_164)
    
    point1_165 = NXOpen.Point3d(31.430990429688705, 0.0, -6.0)
    point2_165 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject69.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, NXOpen.View.Null, point1_165, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_165)
    
    originBuilder36 = sketchLinearDimensionBuilder33.Origin
    
    origin137 = NXOpen.Point3d(47.215495214844353, 0.0, -6.0)
    originBuilder36.OriginPoint = origin137
    
    originBuilder36.SetInferRelativeToGeometry(True)
    
    nXObject197 = sketchLinearDimensionBuilder33.Commit()
    
    perpendicularDimension20 = nXObject197
    perpendicularDimension20.IsOriginCentered = True
    
    sketchLinearDimensionBuilder33.Destroy()
    
    narrowDimensionPreferences36.Dispose()
    dimensionPreferences36.Dispose()
    sketchFindMovableObjectsBuilder99 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject198 = sketchFindMovableObjectsBuilder99.Commit()
    
    sketchFindMovableObjectsBuilder99.Destroy()
    
    markId484 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId485 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder38 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension20)
    
    selectNXObjectList57 = sketchEditDimensionValueBuilder38.ExtraGeometries
    
    foundrelations145 = sketchEditDimensionValueBuilder38.FindRelations()
    
    sketchHelpedDimensionalConstraint33 = theSession.ActiveSketch.FindObject("PerpendicularDim [WorkPart|.Features|EXTRUDE(12)|EDGE * 250 * 260 {(63,55.04,-10)(63,55.04,-5)(63,55.04,0) EXTRUDE(2)}] [[Curve Arc2] ArcCenter]")
    sketchHelpedDimensionalConstraint33.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId485, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId485, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint33.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId486 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId486, None)
    
    markId487 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder38.DimValue = 3.0
    
    nXObject199 = sketchEditDimensionValueBuilder38.Commit()
    
    theSession.SetUndoMarkName(markId487, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId487, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId485, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId488 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    rotMatrix17 = NXOpen.Matrix3x3()
    
    rotMatrix17.Xx = 0.99990784126764087
    rotMatrix17.Xy = -0.012146850902476376
    rotMatrix17.Xz = 0.0060632486868637406
    rotMatrix17.Yx = -0.0061346037505937362
    rotMatrix17.Yy = -0.0058457455381666877
    rotMatrix17.Yz = 0.99996409630342464
    rotMatrix17.Zx = -0.012110970576669209
    rotMatrix17.Zy = -0.99990913650804036
    rotMatrix17.Zz = -0.0059197229187724024
    translation17 = NXOpen.Point3d(-41.447299815908153, 9.4841454749724896, 0.72120642508257049)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix17, translation17, 3.7368276662792086)
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    markId489 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint33.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId489, None)
    
    theSession.SetUndoMarkName(markId485, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder38.Destroy()
    
    theSession.DeleteUndoMark(markId488, None)
    
    theSession.SetUndoMarkVisibility(markId485, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId487, None)
    
    theSession.DeleteUndoMark(markId485, None)
    
    sketchFindMovableObjectsBuilder100 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject200 = sketchFindMovableObjectsBuilder100.Commit()
    
    sketchFindMovableObjectsBuilder100.Destroy()
    
    sketchWorkRegionBuilder10 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder10.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject201 = sketchWorkRegionBuilder10.Commit()
    
    sketchWorkRegionBuilder10.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId490 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId491 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder15 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section15 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder15.Section = section15
    
    extrudeBuilder15.AllowSelfIntersectingSection(True)
    
    expression53 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder15.DistanceTolerance = 0.01
    
    extrudeBuilder15.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies58 = [NXOpen.Body.Null] * 1 
    targetBodies58[0] = NXOpen.Body.Null
    extrudeBuilder15.BooleanOperation.SetTargetBodies(targetBodies58)
    
    extrudeBuilder15.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder15.Limits.EndExtend.Value.SetFormula("-10")
    
    extrudeBuilder15.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies59 = [NXOpen.Body.Null] * 1 
    targetBodies59[0] = body1
    extrudeBuilder15.BooleanOperation.SetTargetBodies(targetBodies59)
    
    extrudeBuilder15.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder15.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder15.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder15.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder15 = extrudeBuilder15.SmartVolumeProfile
    
    smartVolumeProfileBuilder15.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder15.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId491, "Extrude Dialog")
    
    section15.DistanceTolerance = 0.01
    
    section15.ChainingTolerance = 0.0094999999999999998
    
    section15.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId492 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions14 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions14.SetSelectedFromInactive(False)
    
    curves13 = [NXOpen.ICurve.Null] * 2 
    curves13[0] = arc2
    curves13[1] = arc4
    seedPoint13 = NXOpen.Point3d(6.8024474053275386, 0.0, -6.0984370321534405)
    regionBoundaryRule13 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch10, curves13, seedPoint13, 0.01, selectionIntentRuleOptions14)
    
    selectionIntentRuleOptions14.Dispose()
    selectionIntentRuleOptions15 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions15.SetSelectedFromInactive(False)
    
    curves14 = [NXOpen.ICurve.Null] * 2 
    curves14[0] = arc2
    curves14[1] = arc4
    seedPoint14 = NXOpen.Point3d(59.802447405327534, 0.0, -6.0984370321534467)
    regionBoundaryRule14 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch10, curves14, seedPoint14, 0.01, selectionIntentRuleOptions15)
    
    selectionIntentRuleOptions15.Dispose()
    section15.AllowSelfIntersection(True)
    
    section15.AllowDegenerateCurves(False)
    
    rules10 = [None] * 2 
    rules10[0] = regionBoundaryRule13
    rules10[1] = regionBoundaryRule14
    helpPoint10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section15.AddToSection(rules10, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint10, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId492, None)
    
    markId493 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId494 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId494, None)
    
    direction28 = workPart.Directions.CreateDirection(sketch10, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder15.Direction = direction28
    
    theSession.DeleteUndoMark(markId493, None)
    
    extrudeBuilder15.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies60 = [NXOpen.Body.Null] * 1 
    targetBodies60[0] = body1
    extrudeBuilder15.BooleanOperation.SetTargetBodies(targetBodies60)
    
    extrudeBuilder15.Limits.EndExtend.Value.SetFormula("100")
    
    extrudeBuilder15.Limits.EndExtend.Value.SetFormula("-100")
    
    markId495 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId495, None)
    
    markId496 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder15.ParentFeatureInternal = False
    
    feature20 = extrudeBuilder15.CommitFeature()
    
    theSession.DeleteUndoMark(markId496, None)
    
    theSession.SetUndoMarkName(markId491, "Extrude")
    
    expression54 = extrudeBuilder15.Limits.StartExtend.Value
    expression55 = extrudeBuilder15.Limits.EndExtend.Value
    extrudeBuilder15.Destroy()
    
    workPart.Expressions.Delete(expression53)
    
    rotMatrix18 = NXOpen.Matrix3x3()
    
    rotMatrix18.Xx = 0.99521077909646993
    rotMatrix18.Xy = 0.015606700551833507
    rotMatrix18.Xz = -0.096498373396025836
    rotMatrix18.Yx = 0.096965013378497084
    rotMatrix18.Yy = -0.03257823433988432
    rotMatrix18.Yz = 0.99475446459304673
    rotMatrix18.Zx = 0.012381088429589461
    rotMatrix18.Zy = -0.99934733178468849
    rotMatrix18.Zz = -0.033935513906785696
    translation18 = NXOpen.Point3d(-58.728347641247495, -32.558707836065935, 70.664990415849033)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix18, translation18, 1.9132557651349547)
    
    rotMatrix19 = NXOpen.Matrix3x3()
    
    rotMatrix19.Xx = 0.93254437293927994
    rotMatrix19.Xy = -0.34775186051638107
    rotMatrix19.Xz = -0.097106312908463416
    rotMatrix19.Yx = 0.083704055534765606
    rotMatrix19.Yy = -0.053396596177325589
    rotMatrix19.Yz = 0.99505901061379454
    rotMatrix19.Zx = -0.35121876884118003
    rotMatrix19.Zy = -0.93606487329888921
    rotMatrix19.Zz = -0.020686454254294176
    translation19 = NXOpen.Point3d(-33.166849607723222, -30.513948655195573, 88.684034342947243)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix19, translation19, 1.9132557651349547)
    
    rotMatrix20 = NXOpen.Matrix3x3()
    
    rotMatrix20.Xx = 0.90357770099265156
    rotMatrix20.Xy = -0.42110024736732338
    rotMatrix20.Xz = -0.078879147662790472
    rotMatrix20.Yx = 0.20168829015742926
    rotMatrix20.Yy = 0.25566688935323983
    rotMatrix20.Yz = 0.94549260986102168
    rotMatrix20.Zx = -0.37798038557867319
    rotMatrix20.Zy = -0.87023503914494915
    rotMatrix20.Zz = 0.31594588897813047
    translation20 = NXOpen.Point3d(-27.027946079868975, -56.136811864389315, 86.339941297960436)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix20, translation20, 1.9132557651349547)
    
    scaleAboutPoint239 = NXOpen.Point3d(-10.924876701917999, 3.1115155163691113, 0.0)
    viewCenter239 = NXOpen.Point3d(10.924876701918164, -3.1115155163690402, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint239, viewCenter239)
    
    rotMatrix21 = NXOpen.Matrix3x3()
    
    rotMatrix21.Xx = 0.84298541834753304
    rotMatrix21.Xy = -0.53730502910388489
    rotMatrix21.Xz = 0.026055520587821263
    rotMatrix21.Yx = 0.12755871805757982
    rotMatrix21.Yy = 0.24671376552378346
    rotMatrix21.Yz = 0.9606565938713878
    rotMatrix21.Zx = -0.52259387472581076
    rotMatrix21.Zy = -0.80649589186848447
    rotMatrix21.Zz = 0.27651404756054515
    translation21 = NXOpen.Point3d(-19.151341392447659, -50.373971229538668, 91.192401810200792)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix21, translation21, 1.5306046121079637)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()