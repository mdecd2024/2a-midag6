﻿# NX 2027
# Journal created by Admin on Fri May 17 14:47:51 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    # ----------------------------------------------
    #   Menu: File->New...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    fileNew1 = theSession.Parts.FileNew()
    
    theSession.SetUndoMarkName(markId1, "New Dialog")
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    fileNew1.TemplateFileName = "model-plain-1-mm-template.prt"
    
    fileNew1.UseBlankTemplate = False
    
    fileNew1.ApplicationName = "ModelTemplate"
    
    fileNew1.Units = NXOpen.Part.Units.Millimeters
    
    fileNew1.RelationType = ""
    
    fileNew1.UsesMasterModel = "No"
    
    fileNew1.TemplateType = NXOpen.FileNewTemplateType.Item
    
    fileNew1.TemplatePresentationName = "Model"
    
    fileNew1.ItemType = ""
    
    fileNew1.Specialization = ""
    
    fileNew1.SetCanCreateAltrep(False)
    
    fileNew1.NewFileName = "F:\\yan1\\portable_2024\\portable_2024\\s_link.prt"
    
    fileNew1.MasterFileName = ""
    
    fileNew1.MakeDisplayedPart = True
    
    fileNew1.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    
    nXObject1 = fileNew1.Commit()
    
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    theSession.DeleteUndoMark(markId3, None)
    
    fileNew1.Destroy()
    
    theSession.ApplicationSwitchImmediate("UG_APP_MODELING")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane1 = workPart.Planes.CreatePlane(origin1, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane1
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder1 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder1.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId6, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder1.UseWorkPartOrigin = False
    
    coordinates1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point1 = workPart.Points.CreatePoint(coordinates1)
    
    origin2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix1 = NXOpen.Matrix3x3()
    
    matrix1.Xx = 1.0
    matrix1.Xy = 0.0
    matrix1.Xz = 0.0
    matrix1.Yx = 0.0
    matrix1.Yy = 1.0
    matrix1.Yz = 0.0
    matrix1.Zx = 0.0
    matrix1.Zy = 0.0
    matrix1.Zz = 1.0
    plane2 = workPart.Planes.CreateFixedTypePlane(origin2, matrix1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2 = workPart.Points.CreatePoint(coordinates2)
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction1 = workPart.Directions.CreateDirection(origin3, vector1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector2 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction2 = workPart.Directions.CreateDirection(origin4, vector2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix2 = NXOpen.Matrix3x3()
    
    matrix2.Xx = 1.0
    matrix2.Xy = 0.0
    matrix2.Xz = 0.0
    matrix2.Yx = 0.0
    matrix2.Yy = 1.0
    matrix2.Yz = 0.0
    matrix2.Zx = 0.0
    matrix2.Zy = 0.0
    matrix2.Zz = 1.0
    plane3 = workPart.Planes.CreateFixedTypePlane(origin5, matrix2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane3, direction2, point2, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder1.CoordinateSystem = cartesianCoordinateSystem1
    
    datumAxis1 = workPart.Datums.FindObject("DATUM_CSYS(0) X axis")
    simpleSketchInPlaceBuilder1.HorizontalReference.Value = datumAxis1
    
    point3 = simpleSketchInPlaceBuilder1.SketchOrigin
    
    simpleSketchInPlaceBuilder1.SketchOrigin = point3
    
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId7, None)
    
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject2 = simpleSketchInPlaceBuilder1.Commit()
    
    sketch1 = nXObject2
    feature1 = sketch1.Feature
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId9)
    
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder1 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject3 = sketchFindMovableObjectsBuilder1.Commit()
    
    sketchFindMovableObjectsBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId8, None)
    
    theSession.SetUndoMarkName(markId6, "Create Sketch")
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    simpleSketchInPlaceBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane1.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId5, None, True)
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_000")
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Rectangle...
    # ----------------------------------------------
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId12, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    endPoint1 = NXOpen.Point3d(120.0, 0.0, 0.0)
    line1 = workPart.Curves.CreateLine(startPoint1, endPoint1)
    
    startPoint2 = NXOpen.Point3d(120.0, 0.0, 0.0)
    endPoint2 = NXOpen.Point3d(120.0, 220.0, 0.0)
    line2 = workPart.Curves.CreateLine(startPoint2, endPoint2)
    
    startPoint3 = NXOpen.Point3d(120.0, 220.0, 0.0)
    endPoint3 = NXOpen.Point3d(0.0, 220.0, 0.0)
    line3 = workPart.Curves.CreateLine(startPoint3, endPoint3)
    
    startPoint4 = NXOpen.Point3d(0.0, 220.0, 0.0)
    endPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    line4 = workPart.Curves.CreateLine(startPoint4, endPoint4)
    
    theSession.ActiveSketch.AddGeometry(line1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_1.Geometry = line1
    conGeom1_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_1.SplineDefiningPointIndex = 0
    conGeom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_1.Geometry = line2
    conGeom2_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint1 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_1, conGeom2_1)
    
    conGeom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_2.Geometry = line2
    conGeom1_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_2.SplineDefiningPointIndex = 0
    conGeom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_2.Geometry = line3
    conGeom2_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint2 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_2, conGeom2_2)
    
    conGeom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_3.Geometry = line3
    conGeom1_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_3.SplineDefiningPointIndex = 0
    conGeom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_3.Geometry = line4
    conGeom2_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint3 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_3, conGeom2_3)
    
    conGeom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_4.Geometry = line4
    conGeom1_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_4.SplineDefiningPointIndex = 0
    conGeom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_4.Geometry = line1
    conGeom2_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint4 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_4, conGeom2_4)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms1 = [NXOpen.SmartObject.Null] * 4 
    geoms1[0] = line1
    geoms1[1] = line2
    geoms1[2] = line3
    geoms1[3] = line4
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms1)
    
    geoms2 = [NXOpen.SmartObject.Null] * 4 
    geoms2[0] = line1
    geoms2[1] = line2
    geoms2[2] = line3
    geoms2[3] = line4
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms2)
    
    objects1 = [NXOpen.NXObject.Null] * 4 
    objects1[0] = sketchGeometricConstraint1
    objects1[1] = sketchGeometricConstraint2
    objects1[2] = sketchGeometricConstraint3
    objects1[3] = sketchGeometricConstraint4
    errorList1 = theSession.ActiveSketch.DeleteObjects(objects1)
    
    errorList1.Dispose()
    sketchFindMovableObjectsBuilder2 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject4 = sketchFindMovableObjectsBuilder2.Commit()
    
    sketchFindMovableObjectsBuilder2.Destroy()
    
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder1 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects1 = [None] * 1 
    dragobjects1[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects1[0].Geometry = line3
    dragobjects1[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects1[0].PointIndex = 0
    sketchDragGeometryBuilder1.SetDragGeometry(dragobjects1)
    
    sketchDragGeometryBuilder1.SplineLinearScale = False
    
    foundrelations1 = sketchDragGeometryBuilder1.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects2 = [None] * 1 
    dragobjects2[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects2[0].Geometry = line3
    dragobjects2[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects2[0].PointIndex = 0
    sketchDragGeometryBuilder1.SetDragGeometry(dragobjects2)
    
    foundrelations2 = sketchDragGeometryBuilder1.FindRelations()
    
    sketchDragGeometryBuilder1.Destroy()
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences1 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences1 = dimensionPreferences1.GetNarrowDimensionPreferences()
    
    option1 = narrowDimensionPreferences1.DimensionDisplayOption
    
    sketchLinearDimensionBuilder1 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder1 = sketchLinearDimensionBuilder1.Driving
    
    drivingValueBuilder1.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject1 = sketchLinearDimensionBuilder1.FirstAssociativity
    
    selectNXObject2 = sketchLinearDimensionBuilder1.SecondAssociativity
    
    point1_3 = NXOpen.Point3d(120.0, 220.0, 0.0)
    point2_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject1.SetValue(NXOpen.InferSnapType.SnapType.Start, line3, NXOpen.View.Null, point1_3, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_3)
    
    point1_4 = NXOpen.Point3d(0.0, 220.0, 0.0)
    point2_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject2.SetValue(NXOpen.InferSnapType.SnapType.End, line3, NXOpen.View.Null, point1_4, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_4)
    
    dimensionMeasurementBuilder1 = sketchLinearDimensionBuilder1.Measurement
    
    dimensionMeasurementBuilder1.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Horizontal
    
    originBuilder1 = sketchLinearDimensionBuilder1.Origin
    
    origin7 = NXOpen.Point3d(60.0, 255.04770590229197, 0.0)
    originBuilder1.OriginPoint = origin7
    
    originBuilder1.SetInferRelativeToGeometry(True)
    
    nXObject5 = sketchLinearDimensionBuilder1.Commit()
    
    horizontalDimension1 = nXObject5
    horizontalDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder1.Destroy()
    
    narrowDimensionPreferences1.Dispose()
    dimensionPreferences1.Dispose()
    sketchFindMovableObjectsBuilder3 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject6 = sketchFindMovableObjectsBuilder3.Commit()
    
    sketchFindMovableObjectsBuilder3.Destroy()
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder1 = workPart.Sketches.CreateEditDimensionValueBuilder(horizontalDimension1)
    
    selectNXObjectList1 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    foundrelations3 = sketchEditDimensionValueBuilder1.FindRelations()
    
    sketchHelpedDimensionalConstraint1 = theSession.ActiveSketch.FindObject("HorizontalDim [[Curve Line3] StartVertex] [[Curve Line3] EndVertex]")
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId16, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId16, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry1Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId17, None)
    
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder1.DimValue = 6.0
    
    theSession.ActiveSketch.Scale(0.050000000000000003)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin8 = NXOpen.Point3d(3.0, 12.7523852951146, 0.0)
    horizontalDimension1.AnnotationOrigin = origin8
    
    sketchEditDimensionValueBuilder1.RestoreOperation()
    
    sketchEditDimensionValueBuilder1.LoadExtraGeometry()
    
    selectNXObjectList2 = sketchEditDimensionValueBuilder1.ExtraGeometries
    
    foundrelations4 = sketchEditDimensionValueBuilder1.FindRelations()
    
    nXObject7 = sketchEditDimensionValueBuilder1.Commit()
    
    theSession.SetUndoMarkName(markId18, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId18, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId16, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    scaleAboutPoint1 = NXOpen.Point3d(42.243843665100421, 27.303947734760136, 0.0)
    viewCenter1 = NXOpen.Point3d(-42.243843665100421, -27.303947734760136, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(47.653116329534072, 30.266168479568801, 0.0)
    viewCenter2 = NXOpen.Point3d(-47.653116329533852, -30.266168479568911, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(59.566395411917867, 34.612905442060367, 0.0)
    viewCenter3 = NXOpen.Point3d(-59.56639541191732, -34.612905442060367, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(72.445616041521674, 43.266131802575458, 0.0)
    viewCenter4 = NXOpen.Point3d(-72.445616041521333, -43.266131802575458, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(57.956492833217482, 34.612905442060367, 0.0)
    viewCenter5 = NXOpen.Point3d(-57.956492833216934, -34.612905442060367, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(46.365194266573873, 27.690324353648183, 0.0)
    viewCenter6 = NXOpen.Point3d(-46.365194266573653, -27.690324353648183, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint6, viewCenter6)
    
    scaleAboutPoint7 = NXOpen.Point3d(37.092155413259363, 22.152259482918634, 0.0)
    viewCenter7 = NXOpen.Point3d(-37.092155413258659, -22.152259482918634, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint7, viewCenter7)
    
    scaleAboutPoint8 = NXOpen.Point3d(29.673724330607556, 17.721807586334904, 0.0)
    viewCenter8 = NXOpen.Point3d(-29.673724330606923, -17.721807586334904, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(23.73897946448616, 14.177446069067924, 0.0)
    viewCenter9 = NXOpen.Point3d(-23.738979464485372, -14.177446069067924, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint9, viewCenter9)
    
    scaleAboutPoint10 = NXOpen.Point3d(-7.9129931548282286, -1.3188321924713564, 0.0)
    viewCenter10 = NXOpen.Point3d(7.9129931548290378, 1.3188321924714463, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(-7.5964734286350497, -2.7431709603405294, 0.0)
    viewCenter11 = NXOpen.Point3d(7.5964734286358055, 2.7431709603406014, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint11, viewCenter11)
    
    scaleAboutPoint12 = NXOpen.Point3d(-7.4276629079987089, -4.2202630159085421, 0.0)
    viewCenter12 = NXOpen.Point3d(7.4276629079995153, 4.2202630159085999, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(-7.5627113245077942, -9.3183407391261017, 0.0)
    viewCenter13 = NXOpen.Point3d(7.5627113245085766, 9.318340739126171, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(-6.0501690596061621, -7.4546725913008816, 0.0)
    viewCenter14 = NXOpen.Point3d(6.0501690596069357, 7.4546725913009366, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(-4.8401352476848407, -5.9637380730407044, 0.0)
    viewCenter15 = NXOpen.Point3d(4.8401352476856365, 5.9637380730407639, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint15, viewCenter15)
    
    scaleAboutPoint16 = NXOpen.Point3d(-3.8721081981477901, -4.7709904584325518, 0.0)
    viewCenter16 = NXOpen.Point3d(3.8721081981485916, 4.7709904584326113, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint16, viewCenter16)
    
    scaleAboutPoint17 = NXOpen.Point3d(-2.4338965816927529, 2.3785807502910634, 0.0)
    viewCenter17 = NXOpen.Point3d(2.4338965816935452, -2.378580750291007, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(-1.9471172653541342, 1.9028646002328582, 0.0)
    viewCenter18 = NXOpen.Point3d(1.9471172653548965, -1.9028646002327978, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(-1.4868895480885111, 1.5930959443809924, 0.0)
    viewCenter19 = NXOpen.Point3d(1.4868895480892901, -1.593095944380944, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(-0.62307752491305735, 2.0674845144855478, 0.0)
    viewCenter20 = NXOpen.Point3d(0.62307752491383483, -2.0674845144854999, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint20, viewCenter20)
    
    scaleAboutPoint21 = NXOpen.Point3d(-0.40783256176113769, 1.6993023406730561, 0.0)
    viewCenter21 = NXOpen.Point3d(0.40783256176191429, -1.6993023406730137, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(-0.3262660494088328, 1.3956936558061401, 0.0)
    viewCenter22 = NXOpen.Point3d(0.32626604940961795, -1.3956936558060968, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint22, viewCenter22)
    
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId20, None)
    
    theSession.SetUndoMarkName(markId16, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId19, None)
    
    theSession.SetUndoMarkVisibility(markId16, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId18, None)
    
    theSession.DeleteUndoMark(markId16, None)
    
    sketchFindMovableObjectsBuilder4 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject8 = sketchFindMovableObjectsBuilder4.Commit()
    
    sketchFindMovableObjectsBuilder4.Destroy()
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder2 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects3 = [None] * 1 
    dragobjects3[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects3[0].Geometry = line2
    dragobjects3[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects3[0].PointIndex = 0
    sketchDragGeometryBuilder2.SetDragGeometry(dragobjects3)
    
    sketchDragGeometryBuilder2.SplineLinearScale = False
    
    foundrelations5 = sketchDragGeometryBuilder2.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects4 = [None] * 1 
    dragobjects4[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects4[0].Geometry = line2
    dragobjects4[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects4[0].PointIndex = 0
    sketchDragGeometryBuilder2.SetDragGeometry(dragobjects4)
    
    foundrelations6 = sketchDragGeometryBuilder2.FindRelations()
    
    sketchDragGeometryBuilder2.Destroy()
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences2 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences2 = dimensionPreferences2.GetNarrowDimensionPreferences()
    
    option2 = narrowDimensionPreferences2.DimensionDisplayOption
    
    sketchLinearDimensionBuilder2 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder2 = sketchLinearDimensionBuilder2.Driving
    
    drivingValueBuilder2.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject3 = sketchLinearDimensionBuilder2.FirstAssociativity
    
    selectNXObject4 = sketchLinearDimensionBuilder2.SecondAssociativity
    
    point1_7 = NXOpen.Point3d(6.0, 0.0, 0.0)
    point2_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject3.SetValue(NXOpen.InferSnapType.SnapType.Start, line2, NXOpen.View.Null, point1_7, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_7)
    
    point1_8 = NXOpen.Point3d(6.0, 11.0, 0.0)
    point2_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject4.SetValue(NXOpen.InferSnapType.SnapType.End, line2, NXOpen.View.Null, point1_8, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_8)
    
    dimensionMeasurementBuilder2 = sketchLinearDimensionBuilder2.Measurement
    
    dimensionMeasurementBuilder2.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Vertical
    
    originBuilder2 = sketchLinearDimensionBuilder2.Origin
    
    origin10 = NXOpen.Point3d(7.7523852951145997, 5.5, 0.0)
    originBuilder2.OriginPoint = origin10
    
    originBuilder2.SetInferRelativeToGeometry(True)
    
    nXObject9 = sketchLinearDimensionBuilder2.Commit()
    
    verticalDimension1 = nXObject9
    verticalDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder2.Destroy()
    
    narrowDimensionPreferences2.Dispose()
    dimensionPreferences2.Dispose()
    sketchFindMovableObjectsBuilder5 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject10 = sketchFindMovableObjectsBuilder5.Commit()
    
    sketchFindMovableObjectsBuilder5.Destroy()
    
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder2 = workPart.Sketches.CreateEditDimensionValueBuilder(verticalDimension1)
    
    selectNXObjectList3 = sketchEditDimensionValueBuilder2.ExtraGeometries
    
    foundrelations7 = sketchEditDimensionValueBuilder2.FindRelations()
    
    sketchHelpedDimensionalConstraint2 = theSession.ActiveSketch.FindObject("VerticalDim [[Curve Line2] StartVertex] [[Curve Line2] EndVertex]")
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId24, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId24, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId25, None)
    
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder2.DimValue = 15.0
    
    nXObject11 = sketchEditDimensionValueBuilder2.Commit()
    
    theSession.SetUndoMarkName(markId26, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId26, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId24, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    scaleAboutPoint23 = NXOpen.Point3d(2.1461055694477165, 4.4227175586583698, 0.0)
    viewCenter23 = NXOpen.Point3d(-2.1461055694469349, -4.4227175586583281, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint23, viewCenter23)
    
    scaleAboutPoint24 = NXOpen.Point3d(1.7168844555582521, 3.561375188218022, 0.0)
    viewCenter24 = NXOpen.Point3d(-1.7168844555574687, -3.5613751882179785, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(1.3920684774797412, 2.8862219766405408, 0.0)
    viewCenter25 = NXOpen.Point3d(-1.3920684774789593, -2.8862219766404933, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(1.1285035124103142, 2.3535237725917737, 0.0)
    viewCenter26 = NXOpen.Point3d(-1.1285035124095344, -2.3535237725917293, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(1.4106293905127947, 2.9419047157397138, 0.0)
    viewCenter27 = NXOpen.Point3d(-1.410629390512016, -2.9419047157396663, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint27, viewCenter27)
    
    scaleAboutPoint28 = NXOpen.Point3d(1.740085596849571, 3.700582035965958, 0.0)
    viewCenter28 = NXOpen.Point3d(-1.7400855968487996, -3.7005820359659105, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(2.1461055694477138, 4.654728971571596, 0.0)
    viewCenter29 = NXOpen.Point3d(-2.1461055694469398, -4.6547289715715463, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint29, viewCenter29)
    
    scaleAboutPoint30 = NXOpen.Point3d(2.5376248287387759, 7.4497414615105946, 0.0)
    viewCenter30 = NXOpen.Point3d(-2.5376248287380032, -7.4497414615105475, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(3.5798635976849043, 11.124765990272806, 0.0)
    viewCenter31 = NXOpen.Point3d(-3.5798635976841395, -11.124765990272756, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint31, viewCenter31)
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId28, None)
    
    theSession.SetUndoMarkName(markId24, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder2.Destroy()
    
    theSession.DeleteUndoMark(markId27, None)
    
    theSession.SetUndoMarkVisibility(markId24, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId26, None)
    
    theSession.DeleteUndoMark(markId24, None)
    
    sketchFindMovableObjectsBuilder6 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject12 = sketchFindMovableObjectsBuilder6.Commit()
    
    sketchFindMovableObjectsBuilder6.Destroy()
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder1 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder1.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject13 = sketchWorkRegionBuilder1.Commit()
    
    sketchWorkRegionBuilder1.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit2 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("6")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId30, "Extrude Dialog")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions1 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions1.SetSelectedFromInactive(False)
    
    curves1 = [NXOpen.ICurve.Null] * 4 
    curves1[0] = line1
    curves1[1] = line2
    curves1[2] = line3
    curves1[3] = line4
    seedPoint1 = NXOpen.Point3d(3.4414379999999998, 8.6035950000000003, 0.0)
    regionBoundaryRule1 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch1, curves1, seedPoint1, 0.01, selectionIntentRuleOptions1)
    
    selectionIntentRuleOptions1.Dispose()
    section1.AllowSelfIntersection(True)
    
    section1.AllowDegenerateCurves(False)
    
    rules1 = [None] * 1 
    rules1[0] = regionBoundaryRule1
    helpPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section1.AddToSection(rules1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId31, None)
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId33, None)
    
    direction3 = workPart.Directions.CreateDirection(sketch1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction3
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies2)
    
    targetBodies3 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies3)
    
    theSession.DeleteUndoMark(markId32, None)
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    targetBodies4[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies4)
    
    targetBodies5 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies5)
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("2.8")
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    targetBodies6[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies6)
    
    targetBodies7 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies7)
    
    scaleAboutPoint32 = NXOpen.Point3d(27.819116559944259, 2.5758441259207938, 0.0)
    viewCenter32 = NXOpen.Point3d(-27.819116559944259, -2.5758441259207938, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(22.255293247955404, 2.060675300736635, 0.0)
    viewCenter33 = NXOpen.Point3d(-22.255293247955404, -2.060675300736635, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(17.804234598364495, 1.6485402405893084, 0.0)
    viewCenter34 = NXOpen.Point3d(-17.804234598364328, -1.6485402405893084, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(14.243387678691551, 1.3188321924714914, 0.0)
    viewCenter35 = NXOpen.Point3d(-14.24338767869137, -1.3188321924714466, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(3.376210412726925, 0.6330394523863232, 0.0)
    viewCenter36 = NXOpen.Point3d(-3.3762104127267092, -0.63303945238625126, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(1.3504841650908994, -0.16881052063630486, 0.0)
    viewCenter37 = NXOpen.Point3d(-1.3504841650905539, 0.16881052063636243, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint37, viewCenter37)
    
    scaleAboutPoint38 = NXOpen.Point3d(0.27009683301834114, -0.67524208254533458, 0.0)
    viewCenter38 = NXOpen.Point3d(-0.27009683301794962, 0.67524208254538065, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(-0.21607746641434128, -0.75627113245077482, 0.0)
    viewCenter39 = NXOpen.Point3d(0.21607746641474659, 0.75627113245083011, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint39, viewCenter39)
    
    scaleAboutPoint40 = NXOpen.Point3d(-4.667273274553426, 0.086430986565847051, 0.0)
    viewCenter40 = NXOpen.Point3d(4.6672732745538097, -0.086430986565788084, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(-3.8721081981479903, 0.20743436775796217, 0.0)
    viewCenter41 = NXOpen.Point3d(3.8721081981483794, -0.20743436775791499, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint41, viewCenter41)
    
    scaleAboutPoint42 = NXOpen.Point3d(-3.0976865585183542, 0.16594749420637916, 0.0)
    viewCenter42 = NXOpen.Point3d(3.0976865585187503, -0.16594749420632254, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint42, viewCenter42)
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId34, None)
    
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    feature2 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId35, None)
    
    theSession.SetUndoMarkName(markId30, "Extrude")
    
    expression4 = extrudeBuilder1.Limits.StartExtend.Value
    expression5 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression3)
    
    scaleAboutPoint43 = NXOpen.Point3d(-10.532134298962877, 4.026992526074145, 0.0)
    viewCenter43 = NXOpen.Point3d(10.532134298963268, -4.0269925260740846, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint43, viewCenter43)
    
    scaleAboutPoint44 = NXOpen.Point3d(-7.4344477404443188, 2.8675726998857729, 0.0)
    viewCenter44 = NXOpen.Point3d(7.4344477404447113, -2.8675726998857125, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint44, viewCenter44)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch
    # ----------------------------------------------
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Update Model from Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane4 = workPart.Planes.CreatePlane(origin11, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.PlaneReference = plane4
    
    expression6 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression7 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder2 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    simpleSketchInPlaceBuilder2 = workPart.Sketches.CreateSimpleSketchInPlaceBuilder()
    
    sketchAlongPathBuilder2.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId38, "Create Sketch Dialog")
    
    simpleSketchInPlaceBuilder2.UseWorkPartOrigin = False
    
    coordinates3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point4 = workPart.Points.CreatePoint(coordinates3)
    
    origin12 = NXOpen.Point3d(6.5824923101106432, 11.082492310110643, 0.0)
    matrix3 = NXOpen.Matrix3x3()
    
    matrix3.Xx = 1.0
    matrix3.Xy = 0.0
    matrix3.Xz = 0.0
    matrix3.Yx = 0.0
    matrix3.Yy = 1.0
    matrix3.Yz = 0.0
    matrix3.Zx = 0.0
    matrix3.Zy = 0.0
    matrix3.Zz = 1.0
    plane5 = workPart.Planes.CreateFixedTypePlane(origin12, matrix3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    coordinates4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point5 = workPart.Points.CreatePoint(coordinates4)
    
    origin13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction4 = workPart.Directions.CreateDirection(origin13, vector3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector4 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction5 = workPart.Directions.CreateDirection(origin14, vector4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix4 = NXOpen.Matrix3x3()
    
    matrix4.Xx = 1.0
    matrix4.Xy = 0.0
    matrix4.Xz = 0.0
    matrix4.Yx = 0.0
    matrix4.Yy = 1.0
    matrix4.Yz = 0.0
    matrix4.Zx = 0.0
    matrix4.Zy = 0.0
    matrix4.Zz = 1.0
    plane6 = workPart.Planes.CreateFixedTypePlane(origin15, matrix4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane6, direction5, point5, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    simpleSketchInPlaceBuilder2.CoordinateSystem = cartesianCoordinateSystem2
    
    simpleSketchInPlaceBuilder2.HorizontalReference.Value = datumAxis1
    
    point6 = simpleSketchInPlaceBuilder2.SketchOrigin
    
    simpleSketchInPlaceBuilder2.SketchOrigin = point6
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId39, None)
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = False
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = False
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = False
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.DisplayShadedRegions = True
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    theSession.Preferences.Sketch.EditDimensionOnCreation = True
    
    theSession.Preferences.Sketch.CreateDimensionForTypedValues = True
    
    nXObject14 = simpleSketchInPlaceBuilder2.Commit()
    
    sketch2 = nXObject14
    feature3 = sketch2.Feature
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId41)
    
    sketch2.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.Preferences.Sketch.FindMovableObjects = True
    
    sketchFindMovableObjectsBuilder7 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject15 = sketchFindMovableObjectsBuilder7.Commit()
    
    sketchFindMovableObjectsBuilder7.Destroy()
    
    theSession.DeleteUndoMark(markId40, None)
    
    theSession.SetUndoMarkName(markId38, "Create Sketch")
    
    sketchInPlaceBuilder2.Destroy()
    
    sketchAlongPathBuilder2.Destroy()
    
    simpleSketchInPlaceBuilder2.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression7)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression6)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane4.DestroyPlane()
    
    theSession.DeleteUndoMarksUpToMark(markId37, None, True)
    
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_001")
    
    scaleAboutPoint45 = NXOpen.Point3d(6.3440620718461833, 3.8800736778701217, 0.0)
    viewCenter45 = NXOpen.Point3d(-6.3440620718457872, -3.8800736778700635, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint45, viewCenter45)
    
    scaleAboutPoint46 = NXOpen.Point3d(5.0752496574769852, 2.8774852968730293, 0.0)
    viewCenter46 = NXOpen.Point3d(-5.0752496574765908, -2.8774852968729756, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint46, viewCenter46)
    
    scaleAboutPoint47 = NXOpen.Point3d(4.1689550757847025, 2.1207293211599723, 0.0)
    viewCenter47 = NXOpen.Point3d(-4.1689550757843064, -2.1207293211599167, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint47, viewCenter47)
    
    scaleAboutPoint48 = NXOpen.Point3d(3.2191583541711903, 1.5515763238572182, 0.0)
    viewCenter48 = NXOpen.Point3d(-3.2191583541707947, -1.5515763238571638, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint48, viewCenter48)
    
    # ----------------------------------------------
    #   Menu: Insert->Curve->Circle...
    # ----------------------------------------------
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId44, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix1 = theSession.ActiveSketch.Orientation
    
    center1 = NXOpen.Point3d(3.0, 3.4000000000000004, 0.0)
    arc1 = workPart.Curves.CreateArc(center1, nXMatrix1, 1.6243735210059458, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    scaleAboutPoint49 = NXOpen.Point3d(-0.90484451036137847, 3.0973523623915753, 0.0)
    viewCenter49 = NXOpen.Point3d(0.90484451036177416, -3.097352362391522, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint49, viewCenter49)
    
    scaleAboutPoint50 = NXOpen.Point3d(-0.44546191279319353, 3.9998767586240209, 0.0)
    viewCenter50 = NXOpen.Point3d(0.44546191279358921, -3.9998767586239667, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint50, viewCenter50)
    
    scaleAboutPoint51 = NXOpen.Point3d(-0.55682739099154144, 4.9998459482800204, 0.0)
    viewCenter51 = NXOpen.Point3d(0.55682739099193712, -4.9998459482799671, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint51, viewCenter51)
    
    scaleAboutPoint52 = NXOpen.Point3d(-0.69603423873947623, 6.2498074353500179, 0.0)
    viewCenter52 = NXOpen.Point3d(0.69603423873987191, -6.2498074353499637, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint52, viewCenter52)
    
    scaleAboutPoint53 = NXOpen.Point3d(-0.8700427984244008, 7.9210146439905893, 0.0)
    viewCenter53 = NXOpen.Point3d(0.87004279842479026, -7.9210146439905369, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint53, viewCenter53)
    
    scaleAboutPoint54 = NXOpen.Point3d(-0.22657364542287653, 13.617076089926591, 0.0)
    viewCenter54 = NXOpen.Point3d(0.22657364542326677, -13.617076089926542, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint54, viewCenter54)
    
    scaleAboutPoint55 = NXOpen.Point3d(-0.28321705677864389, 17.134631935119767, 0.0)
    viewCenter55 = NXOpen.Point3d(0.28321705677903997, -17.134631935119721, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint55, viewCenter55)
    
    scaleAboutPoint56 = NXOpen.Point3d(-0.2832170567786475, 21.559898447289118, 0.0)
    viewCenter56 = NXOpen.Point3d(0.28321705677904596, -21.559898447289072, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint56, viewCenter56)
    
    scaleAboutPoint57 = NXOpen.Point3d(-0.17701066048658301, 31.64065556201092, 0.0)
    viewCenter57 = NXOpen.Point3d(0.17701066048697545, -31.640655562010867, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint57, viewCenter57)
    
    scaleAboutPoint58 = NXOpen.Point3d(-0.14160852838921811, 25.312524449608734, 0.0)
    viewCenter58 = NXOpen.Point3d(0.14160852838961654, -25.312524449608684, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint58, viewCenter58)
    
    scaleAboutPoint59 = NXOpen.Point3d(-0.11328682271134551, 20.193376148331218, 0.0)
    viewCenter59 = NXOpen.Point3d(0.11328682271173188, -20.193376148331176, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint59, viewCenter59)
    
    scaleAboutPoint60 = NXOpen.Point3d(0.090629458169408678, 15.74686835690345, 0.0)
    viewCenter60 = NXOpen.Point3d(-0.090629458169037752, -15.746868356903404, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint60, viewCenter60)
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId45, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix2 = theSession.ActiveSketch.Orientation
    
    center2 = NXOpen.Point3d(3.0, 12.07469072599598, 0.0)
    arc2 = workPart.Curves.CreateArc(center2, nXMatrix2, 1.2598630335395602, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    sketchFindMovableObjectsBuilder8 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject16 = sketchFindMovableObjectsBuilder8.Commit()
    
    sketchFindMovableObjectsBuilder8.Destroy()
    
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder3 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects5 = [None] * 1 
    dragobjects5[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects5[0].Geometry = arc1
    dragobjects5[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects5[0].PointIndex = 0
    sketchDragGeometryBuilder3.SetDragGeometry(dragobjects5)
    
    sketchDragGeometryBuilder3.SplineLinearScale = False
    
    foundrelations8 = sketchDragGeometryBuilder3.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects6 = [None] * 1 
    dragobjects6[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects6[0].Geometry = arc1
    dragobjects6[0].PointType = NXOpen.Sketch.PointType.Quadrant
    dragobjects6[0].PointIndex = 0
    sketchDragGeometryBuilder3.SetDragGeometry(dragobjects6)
    
    foundrelations9 = sketchDragGeometryBuilder3.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects7 = [None] * 2 
    dragobjects7[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects7[1] = NXOpen.Sketch.SketchGeometry()
    dragobjects7[0].Geometry = arc1
    dragobjects7[0].PointType = NXOpen.Sketch.PointType.Quadrant
    dragobjects7[0].PointIndex = 0
    dragobjects7[1].Geometry = arc1
    dragobjects7[1].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects7[1].PointIndex = 0
    sketchDragGeometryBuilder3.SetDragGeometry(dragobjects7)
    
    foundrelations10 = sketchDragGeometryBuilder3.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    sketchDragGeometryBuilder3.Destroy()
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder4 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects8 = [None] * 1 
    dragobjects8[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects8[0].Geometry = arc1
    dragobjects8[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects8[0].PointIndex = 0
    sketchDragGeometryBuilder4.SetDragGeometry(dragobjects8)
    
    sketchDragGeometryBuilder4.SplineLinearScale = False
    
    foundrelations11 = sketchDragGeometryBuilder4.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects9 = [None] * 1 
    dragobjects9[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects9[0].Geometry = arc1
    dragobjects9[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects9[0].PointIndex = 0
    sketchDragGeometryBuilder4.SetDragGeometry(dragobjects9)
    
    foundrelations12 = sketchDragGeometryBuilder4.FindRelations()
    
    sketchDragGeometryBuilder4.Destroy()
    
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences3 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences3 = dimensionPreferences3.GetNarrowDimensionPreferences()
    
    option3 = narrowDimensionPreferences3.DimensionDisplayOption
    
    sketchRadialDimensionBuilder1 = workPart.Sketches.CreateRadialDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder3 = sketchRadialDimensionBuilder1.Driving
    
    drivingValueBuilder3.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject5 = sketchRadialDimensionBuilder1.FirstAssociativity
    
    point1_11 = NXOpen.Point3d(3.0, 3.4000000000000004, 0.0)
    point2_11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject5.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, NXOpen.View.Null, point1_11, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_11)
    
    dimensionMeasurementBuilder3 = sketchRadialDimensionBuilder1.Measurement
    
    dimensionMeasurementBuilder3.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Diametral
    
    originBuilder3 = sketchRadialDimensionBuilder1.Origin
    
    origin18 = NXOpen.Point3d(6.0714312708326386, 4.9289534009528939, 0.0)
    originBuilder3.OriginPoint = origin18
    
    originBuilder3.SetInferRelativeToGeometry(True)
    
    nXObject17 = sketchRadialDimensionBuilder1.Commit()
    
    sketchRadialDimensionBuilder1.Destroy()
    
    narrowDimensionPreferences3.Dispose()
    dimensionPreferences3.Dispose()
    sketchFindMovableObjectsBuilder9 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject18 = sketchFindMovableObjectsBuilder9.Commit()
    
    sketchFindMovableObjectsBuilder9.Destroy()
    
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    diameterDimension1 = nXObject17
    sketchEditDimensionValueBuilder3 = workPart.Sketches.CreateEditDimensionValueBuilder(diameterDimension1)
    
    selectNXObjectList4 = sketchEditDimensionValueBuilder3.ExtraGeometries
    
    foundrelations13 = sketchEditDimensionValueBuilder3.FindRelations()
    
    sketchDimensionalConstraint1 = theSession.ActiveSketch.FindObject("DiameterDim [Curve Arc1]")
    sketchDimensionalConstraint1.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId50, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId50, None, NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId51, None)
    
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder3.DimValue = 3.0
    
    theSession.ActiveSketch.Scale(0.92343293005451543)
    
    theSession.ActiveSketch.LocalUpdate()
    
    origin19 = NXOpen.Point3d(5.6065595680495939, 4.5515578811440989, 0.0)
    diameterDimension1.AnnotationOrigin = origin19
    
    sketchEditDimensionValueBuilder3.RestoreOperation()
    
    sketchEditDimensionValueBuilder3.LoadExtraGeometry()
    
    selectNXObjectList5 = sketchEditDimensionValueBuilder3.ExtraGeometries
    
    foundrelations14 = sketchEditDimensionValueBuilder3.FindRelations()
    
    nXObject19 = sketchEditDimensionValueBuilder3.Commit()
    
    theSession.SetUndoMarkName(markId52, "Edit Dimension Value - Diameter")
    
    theSession.SetUndoMarkVisibility(markId52, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId50, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId54, None)
    
    theSession.SetUndoMarkName(markId50, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder3.Destroy()
    
    theSession.DeleteUndoMark(markId53, None)
    
    theSession.SetUndoMarkVisibility(markId50, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId52, None)
    
    theSession.DeleteUndoMark(markId50, None)
    
    sketchFindMovableObjectsBuilder10 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject20 = sketchFindMovableObjectsBuilder10.Commit()
    
    sketchFindMovableObjectsBuilder10.Destroy()
    
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder5 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects10 = [None] * 1 
    dragobjects10[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects10[0].Geometry = arc2
    dragobjects10[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects10[0].PointIndex = 0
    sketchDragGeometryBuilder5.SetDragGeometry(dragobjects10)
    
    sketchDragGeometryBuilder5.SplineLinearScale = False
    
    foundrelations15 = sketchDragGeometryBuilder5.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects11 = [None] * 1 
    dragobjects11[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects11[0].Geometry = arc2
    dragobjects11[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects11[0].PointIndex = 0
    sketchDragGeometryBuilder5.SetDragGeometry(dragobjects11)
    
    foundrelations16 = sketchDragGeometryBuilder5.FindRelations()
    
    sketchDragGeometryBuilder5.Destroy()
    
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences4 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences4 = dimensionPreferences4.GetNarrowDimensionPreferences()
    
    option4 = narrowDimensionPreferences4.DimensionDisplayOption
    
    sketchRadialDimensionBuilder2 = workPart.Sketches.CreateRadialDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder4 = sketchRadialDimensionBuilder2.Driving
    
    drivingValueBuilder4.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject6 = sketchRadialDimensionBuilder2.FirstAssociativity
    
    point1_13 = NXOpen.Point3d(2.7702987901635465, 11.150167036608552, 0.0)
    point2_13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject6.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, NXOpen.View.Null, point1_13, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_13)
    
    dimensionMeasurementBuilder4 = sketchRadialDimensionBuilder2.Measurement
    
    dimensionMeasurementBuilder4.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Diametral
    
    originBuilder4 = sketchRadialDimensionBuilder2.Origin
    
    origin21 = NXOpen.Point3d(5.2902581039685046, 12.446928637586963, 0.0)
    originBuilder4.OriginPoint = origin21
    
    originBuilder4.SetInferRelativeToGeometry(True)
    
    nXObject21 = sketchRadialDimensionBuilder2.Commit()
    
    sketchRadialDimensionBuilder2.Destroy()
    
    narrowDimensionPreferences4.Dispose()
    dimensionPreferences4.Dispose()
    sketchFindMovableObjectsBuilder11 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject22 = sketchFindMovableObjectsBuilder11.Commit()
    
    sketchFindMovableObjectsBuilder11.Destroy()
    
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    diameterDimension2 = nXObject21
    sketchEditDimensionValueBuilder4 = workPart.Sketches.CreateEditDimensionValueBuilder(diameterDimension2)
    
    selectNXObjectList6 = sketchEditDimensionValueBuilder4.ExtraGeometries
    
    foundrelations17 = sketchEditDimensionValueBuilder4.FindRelations()
    
    sketchDimensionalConstraint2 = theSession.ActiveSketch.FindObject("DiameterDim [Curve Arc2]")
    sketchDimensionalConstraint2.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId58, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId58, None, NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId59, None)
    
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder4.DimValue = 3.0
    
    nXObject23 = sketchEditDimensionValueBuilder4.Commit()
    
    theSession.SetUndoMarkName(markId60, "Edit Dimension Value - Diameter")
    
    theSession.SetUndoMarkVisibility(markId60, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId58, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    nXObject24 = sketchEditDimensionValueBuilder4.Commit()
    
    theSession.SetUndoMarkName(markId61, "Edit Dimension Value - Diameter")
    
    theSession.SetUndoMarkVisibility(markId61, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId58, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId63, None)
    
    theSession.SetUndoMarkName(markId58, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder4.Destroy()
    
    theSession.DeleteUndoMark(markId62, None)
    
    theSession.SetUndoMarkVisibility(markId58, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId61, None)
    
    theSession.DeleteUndoMark(markId60, None)
    
    theSession.DeleteUndoMark(markId58, None)
    
    sketchFindMovableObjectsBuilder12 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject25 = sketchFindMovableObjectsBuilder12.Commit()
    
    sketchFindMovableObjectsBuilder12.Destroy()
    
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder6 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects12 = [None] * 1 
    dragobjects12[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects12[0].Geometry = arc2
    dragobjects12[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects12[0].PointIndex = 0
    sketchDragGeometryBuilder6.SetDragGeometry(dragobjects12)
    
    sketchDragGeometryBuilder6.SplineLinearScale = False
    
    foundrelations18 = sketchDragGeometryBuilder6.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects13 = [None] * 1 
    dragobjects13[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects13[0].Geometry = arc2
    dragobjects13[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects13[0].PointIndex = -1475379104
    sketchDragGeometryBuilder6.SetDragGeometry(dragobjects13)
    
    foundrelations19 = sketchDragGeometryBuilder6.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects14 = [None] * 2 
    dragobjects14[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects14[1] = NXOpen.Sketch.SketchGeometry()
    dragobjects14[0].Geometry = arc2
    dragobjects14[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects14[0].PointIndex = -1475379152
    dragobjects14[1].Geometry = arc1
    dragobjects14[1].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects14[1].PointIndex = 0
    sketchDragGeometryBuilder6.SetDragGeometry(dragobjects14)
    
    foundrelations20 = sketchDragGeometryBuilder6.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects15 = [None] * 2 
    dragobjects15[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects15[1] = NXOpen.Sketch.SketchGeometry()
    dragobjects15[0].Geometry = arc2
    dragobjects15[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects15[0].PointIndex = -1475379152
    dragobjects15[1].Geometry = arc1
    dragobjects15[1].PointType = NXOpen.Sketch.PointType.Center
    dragobjects15[1].PointIndex = 0
    sketchDragGeometryBuilder6.SetDragGeometry(dragobjects15)
    
    foundrelations21 = sketchDragGeometryBuilder6.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects16 = [None] * 2 
    dragobjects16[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects16[1] = NXOpen.Sketch.SketchGeometry()
    dragobjects16[0].Geometry = arc2
    dragobjects16[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects16[0].PointIndex = -1475379152
    dragobjects16[1].Geometry = arc1
    dragobjects16[1].PointType = NXOpen.Sketch.PointType.Center
    dragobjects16[1].PointIndex = 32756
    sketchDragGeometryBuilder6.SetDragGeometry(dragobjects16)
    
    foundrelations22 = sketchDragGeometryBuilder6.FindRelations()
    
    sketchDragGeometryBuilder6.Destroy()
    
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences5 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences5 = dimensionPreferences5.GetNarrowDimensionPreferences()
    
    option5 = narrowDimensionPreferences5.DimensionDisplayOption
    
    sketchLinearDimensionBuilder3 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder5 = sketchLinearDimensionBuilder3.Driving
    
    drivingValueBuilder5.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    selectNXObject7 = sketchLinearDimensionBuilder3.FirstAssociativity
    
    selectNXObject8 = sketchLinearDimensionBuilder3.SecondAssociativity
    
    point1_22 = NXOpen.Point3d(2.7702987901635465, 11.150167036608552, 0.0)
    point2_22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject7.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, NXOpen.View.Null, point1_22, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_22)
    
    point1_23 = NXOpen.Point3d(2.7702987901635465, 3.1396719621853526, 0.0)
    point2_23 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject8.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, NXOpen.View.Null, point1_23, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_23)
    
    dimensionMeasurementBuilder5 = sketchLinearDimensionBuilder3.Measurement
    
    dimensionMeasurementBuilder5.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.PointToPoint
    
    originBuilder5 = sketchLinearDimensionBuilder3.Origin
    
    origin26 = NXOpen.Point3d(1.6315845325889855, 7.144919499396952, 0.0)
    originBuilder5.OriginPoint = origin26
    
    originBuilder5.SetInferRelativeToGeometry(True)
    
    nXObject26 = sketchLinearDimensionBuilder3.Commit()
    
    parallelDimension1 = nXObject26
    parallelDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder3.Destroy()
    
    narrowDimensionPreferences5.Dispose()
    dimensionPreferences5.Dispose()
    sketchFindMovableObjectsBuilder13 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject27 = sketchFindMovableObjectsBuilder13.Commit()
    
    sketchFindMovableObjectsBuilder13.Destroy()
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder5 = workPart.Sketches.CreateEditDimensionValueBuilder(parallelDimension1)
    
    selectNXObjectList7 = sketchEditDimensionValueBuilder5.ExtraGeometries
    
    foundrelations23 = sketchEditDimensionValueBuilder5.FindRelations()
    
    sketchHelpedDimensionalConstraint3 = theSession.ActiveSketch.FindObject("ParallelDim [[Curve Arc2] ArcCenter] [[Curve Arc1] ArcCenter]")
    sketchHelpedDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId67, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId67, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId68, None)
    
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder5.DimValue = 9.0
    
    nXObject28 = sketchEditDimensionValueBuilder5.Commit()
    
    theSession.SetUndoMarkName(markId69, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId69, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId67, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint3.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId71, None)
    
    theSession.SetUndoMarkName(markId67, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder5.Destroy()
    
    theSession.DeleteUndoMark(markId70, None)
    
    theSession.SetUndoMarkVisibility(markId67, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId69, None)
    
    theSession.DeleteUndoMark(markId67, None)
    
    sketchFindMovableObjectsBuilder14 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject29 = sketchFindMovableObjectsBuilder14.Commit()
    
    sketchFindMovableObjectsBuilder14.Destroy()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder7 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects17 = [None] * 1 
    dragobjects17[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects17[0].Geometry = arc1
    dragobjects17[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects17[0].PointIndex = 0
    sketchDragGeometryBuilder7.SetDragGeometry(dragobjects17)
    
    sketchDragGeometryBuilder7.SplineLinearScale = False
    
    foundrelations24 = sketchDragGeometryBuilder7.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects18 = [None] * 1 
    dragobjects18[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects18[0].Geometry = arc1
    dragobjects18[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects18[0].PointIndex = -1475379168
    sketchDragGeometryBuilder7.SetDragGeometry(dragobjects18)
    
    foundrelations25 = sketchDragGeometryBuilder7.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects19 = [None] * 1 
    dragobjects19[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects19[0].Geometry = arc1
    dragobjects19[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects19[0].PointIndex = -1475379040
    sketchDragGeometryBuilder7.SetDragGeometry(dragobjects19)
    
    foundrelations26 = sketchDragGeometryBuilder7.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects20 = [None] * 1 
    dragobjects20[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects20[0].Geometry = arc1
    dragobjects20[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects20[0].PointIndex = -1475379168
    sketchDragGeometryBuilder7.SetDragGeometry(dragobjects20)
    
    foundrelations27 = sketchDragGeometryBuilder7.FindRelations()
    
    sketchDragGeometryBuilder7.Destroy()
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences6 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences6 = dimensionPreferences6.GetNarrowDimensionPreferences()
    
    option6 = narrowDimensionPreferences6.DimensionDisplayOption
    
    sketchLinearDimensionBuilder4 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder6 = sketchLinearDimensionBuilder4.Driving
    
    drivingValueBuilder6.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder6 = sketchLinearDimensionBuilder4.Measurement
    
    dimensionMeasurementBuilder6.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject9 = sketchLinearDimensionBuilder4.FirstAssociativity
    
    selectNXObject10 = sketchLinearDimensionBuilder4.SecondAssociativity
    
    point1_26 = NXOpen.Point3d(3.7363240285315884, 0.0, 0.0)
    point2_26 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject9.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line1, NXOpen.View.Null, point1_26, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_26)
    
    point1_27 = NXOpen.Point3d(2.7702987901635465, 2.150167036608551, 0.0)
    point2_27 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject10.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, NXOpen.View.Null, point1_27, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_27)
    
    originBuilder6 = sketchLinearDimensionBuilder4.Origin
    
    origin28 = NXOpen.Point3d(2.7702987901635465, 1.0750835183042755, 0.0)
    originBuilder6.OriginPoint = origin28
    
    originBuilder6.SetInferRelativeToGeometry(True)
    
    nXObject30 = sketchLinearDimensionBuilder4.Commit()
    
    perpendicularDimension1 = nXObject30
    perpendicularDimension1.IsOriginCentered = True
    
    sketchLinearDimensionBuilder4.Destroy()
    
    narrowDimensionPreferences6.Dispose()
    dimensionPreferences6.Dispose()
    sketchFindMovableObjectsBuilder15 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject31 = sketchFindMovableObjectsBuilder15.Commit()
    
    sketchFindMovableObjectsBuilder15.Destroy()
    
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder6 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension1)
    
    selectNXObjectList8 = sketchEditDimensionValueBuilder6.ExtraGeometries
    
    foundrelations28 = sketchEditDimensionValueBuilder6.FindRelations()
    
    sketchHelpedDimensionalConstraint4 = theSession.ActiveSketch.FindObject("PerpendicularDim [WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line1] [[Curve Arc1] ArcCenter]")
    sketchHelpedDimensionalConstraint4.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId75, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId75, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint4.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId76, None)
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder6.DimValue = 3.0
    
    nXObject32 = sketchEditDimensionValueBuilder6.Commit()
    
    theSession.SetUndoMarkName(markId77, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId77, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId75, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint4.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId79, None)
    
    theSession.SetUndoMarkName(markId75, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder6.Destroy()
    
    theSession.DeleteUndoMark(markId78, None)
    
    theSession.SetUndoMarkVisibility(markId75, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId77, None)
    
    theSession.DeleteUndoMark(markId75, None)
    
    sketchFindMovableObjectsBuilder16 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject33 = sketchFindMovableObjectsBuilder16.Commit()
    
    sketchFindMovableObjectsBuilder16.Destroy()
    
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder8 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects21 = [None] * 1 
    dragobjects21[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects21[0].Geometry = arc1
    dragobjects21[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects21[0].PointIndex = 0
    sketchDragGeometryBuilder8.SetDragGeometry(dragobjects21)
    
    sketchDragGeometryBuilder8.SplineLinearScale = False
    
    foundrelations29 = sketchDragGeometryBuilder8.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects22 = [None] * 1 
    dragobjects22[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects22[0].Geometry = arc1
    dragobjects22[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects22[0].PointIndex = -1475378416
    sketchDragGeometryBuilder8.SetDragGeometry(dragobjects22)
    
    foundrelations30 = sketchDragGeometryBuilder8.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects23 = [None] * 1 
    dragobjects23[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects23[0].Geometry = arc1
    dragobjects23[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects23[0].PointIndex = -1475379024
    sketchDragGeometryBuilder8.SetDragGeometry(dragobjects23)
    
    foundrelations31 = sketchDragGeometryBuilder8.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    sketchDragGeometryBuilder8.Destroy()
    
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder9 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects24 = [None] * 1 
    dragobjects24[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects24[0].Geometry = arc1
    dragobjects24[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects24[0].PointIndex = 0
    sketchDragGeometryBuilder9.SetDragGeometry(dragobjects24)
    
    sketchDragGeometryBuilder9.SplineLinearScale = False
    
    foundrelations32 = sketchDragGeometryBuilder9.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects25 = [None] * 1 
    dragobjects25[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects25[0].Geometry = arc1
    dragobjects25[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects25[0].PointIndex = -1475378416
    sketchDragGeometryBuilder9.SetDragGeometry(dragobjects25)
    
    foundrelations33 = sketchDragGeometryBuilder9.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects26 = [None] * 1 
    dragobjects26[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects26[0].Geometry = arc1
    dragobjects26[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects26[0].PointIndex = -1475379120
    sketchDragGeometryBuilder9.SetDragGeometry(dragobjects26)
    
    foundrelations34 = sketchDragGeometryBuilder9.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects27 = [None] * 2 
    dragobjects27[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects27[1] = NXOpen.Sketch.SketchGeometry()
    dragobjects27[0].Geometry = arc1
    dragobjects27[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects27[0].PointIndex = -1475379152
    dragobjects27[1].Geometry = arc1
    dragobjects27[1].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects27[1].PointIndex = 0
    sketchDragGeometryBuilder9.SetDragGeometry(dragobjects27)
    
    foundrelations35 = sketchDragGeometryBuilder9.FindRelations()
    
    sketchDragGeometryBuilder9.Destroy()
    
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Select Geometry")
    
    sketchDragGeometryBuilder10 = workPart.Sketches.CreateDragGeometryBuilder()
    
    dragobjects28 = [None] * 1 
    dragobjects28[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects28[0].Geometry = arc1
    dragobjects28[0].PointType = NXOpen.Sketch.PointType.NotSet
    dragobjects28[0].PointIndex = 0
    sketchDragGeometryBuilder10.SetDragGeometry(dragobjects28)
    
    sketchDragGeometryBuilder10.SplineLinearScale = False
    
    foundrelations36 = sketchDragGeometryBuilder10.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects29 = [None] * 1 
    dragobjects29[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects29[0].Geometry = arc1
    dragobjects29[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects29[0].PointIndex = -1475378448
    sketchDragGeometryBuilder10.SetDragGeometry(dragobjects29)
    
    foundrelations37 = sketchDragGeometryBuilder10.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects30 = [None] * 1 
    dragobjects30[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects30[0].Geometry = arc1
    dragobjects30[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects30[0].PointIndex = -1475379120
    sketchDragGeometryBuilder10.SetDragGeometry(dragobjects30)
    
    foundrelations38 = sketchDragGeometryBuilder10.FindRelations()
    
    theSession.ActiveSketch.UpdateDimensionDisplay()
    
    dragobjects31 = [None] * 1 
    dragobjects31[0] = NXOpen.Sketch.SketchGeometry()
    dragobjects31[0].Geometry = arc1
    dragobjects31[0].PointType = NXOpen.Sketch.PointType.Center
    dragobjects31[0].PointIndex = -1475378416
    sketchDragGeometryBuilder10.SetDragGeometry(dragobjects31)
    
    foundrelations39 = sketchDragGeometryBuilder10.FindRelations()
    
    sketchDragGeometryBuilder10.Destroy()
    
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constant Dimension")
    
    dimensionPreferences7 = workPart.Annotations.Preferences.GetDimensionPreferences()
    
    narrowDimensionPreferences7 = dimensionPreferences7.GetNarrowDimensionPreferences()
    
    option7 = narrowDimensionPreferences7.DimensionDisplayOption
    
    sketchLinearDimensionBuilder5 = workPart.Sketches.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    
    drivingValueBuilder7 = sketchLinearDimensionBuilder5.Driving
    
    drivingValueBuilder7.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Constant
    
    dimensionMeasurementBuilder7 = sketchLinearDimensionBuilder5.Measurement
    
    dimensionMeasurementBuilder7.Method = NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod.Perpendicular
    
    selectNXObject11 = sketchLinearDimensionBuilder5.FirstAssociativity
    
    selectNXObject12 = sketchLinearDimensionBuilder5.SecondAssociativity
    
    point1_34 = NXOpen.Point3d(0.0, 3.2292556086792938, 0.0)
    point2_34 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject11.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line4, NXOpen.View.Null, point1_34, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_34)
    
    point1_35 = NXOpen.Point3d(2.7702987901635465, 3.0, 0.0)
    point2_35 = NXOpen.Point3d(0.0, 0.0, 0.0)
    selectNXObject12.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, NXOpen.View.Null, point1_35, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_35)
    
    originBuilder7 = sketchLinearDimensionBuilder5.Origin
    
    origin32 = NXOpen.Point3d(1.3851493950817733, 3.0, 0.0)
    originBuilder7.OriginPoint = origin32
    
    originBuilder7.SetInferRelativeToGeometry(True)
    
    nXObject34 = sketchLinearDimensionBuilder5.Commit()
    
    perpendicularDimension2 = nXObject34
    perpendicularDimension2.IsOriginCentered = True
    
    sketchLinearDimensionBuilder5.Destroy()
    
    narrowDimensionPreferences7.Dispose()
    dimensionPreferences7.Dispose()
    sketchFindMovableObjectsBuilder17 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject35 = sketchFindMovableObjectsBuilder17.Commit()
    
    sketchFindMovableObjectsBuilder17.Destroy()
    
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Edit Dimension")
    
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchEditDimensionValueBuilder7 = workPart.Sketches.CreateEditDimensionValueBuilder(perpendicularDimension2)
    
    selectNXObjectList9 = sketchEditDimensionValueBuilder7.ExtraGeometries
    
    foundrelations40 = sketchEditDimensionValueBuilder7.FindRelations()
    
    sketchHelpedDimensionalConstraint5 = theSession.ActiveSketch.FindObject("PerpendicularDim [WorkPart|.Features|SKETCH(1)|SKETCH_000|Curve Line4] [[Curve Arc1] ArcCenter]")
    sketchHelpedDimensionalConstraint5.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.SetUndoMarkName(markId85, "Edit Dimension Value Dialog")
    
    theSession.SetUndoMarkVisibility(markId85, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchHelpedDimensionalConstraint5.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Geometry2Moves)
    
    # ----------------------------------------------
    #   Dialog Begin Edit Dimension Value
    # ----------------------------------------------
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    theSession.DeleteUndoMark(markId86, None)
    
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder7.DimValue = 3.0
    
    nXObject36 = sketchEditDimensionValueBuilder7.Commit()
    
    theSession.SetUndoMarkName(markId87, "Edit Dimension Value - Distance")
    
    theSession.SetUndoMarkVisibility(markId87, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId85, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Edit Dimension Value")
    
    sketchHelpedDimensionalConstraint5.SetEndBehaviorPreference(NXOpen.SketchDimensionalConstraint.EndBehaviorPreference.Any)
    
    theSession.DeleteUndoMark(markId89, None)
    
    theSession.SetUndoMarkName(markId85, "Edit Dimension Value")
    
    sketchEditDimensionValueBuilder7.Destroy()
    
    theSession.DeleteUndoMark(markId88, None)
    
    theSession.SetUndoMarkVisibility(markId85, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId87, None)
    
    theSession.DeleteUndoMark(markId85, None)
    
    sketchFindMovableObjectsBuilder18 = workPart.Sketches.CreateFindMovableObjectsBuilder()
    
    nXObject37 = sketchFindMovableObjectsBuilder18.Commit()
    
    sketchFindMovableObjectsBuilder18.Destroy()
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    sketchWorkRegionBuilder2 = workPart.Sketches.CreateWorkRegionBuilder()
    
    sketchWorkRegionBuilder2.Scope = NXOpen.SketchWorkRegionBuilder.ScopeType.EntireSketch
    
    nXObject38 = sketchWorkRegionBuilder2.Commit()
    
    sketchWorkRegionBuilder2.Destroy()
    
    theSession.ActiveSketch.CalculateStatus()
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder2.Section = section2
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    expression8 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder2.DistanceTolerance = 0.01
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    targetBodies8[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies8)
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("2.8")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies9 = [NXOpen.Body.Null] * 1 
    targetBodies9[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies9)
    
    extrudeBuilder2.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder2.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder2 = extrudeBuilder2.SmartVolumeProfile
    
    smartVolumeProfileBuilder2.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder2.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId91, "Extrude Dialog")
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    selectionIntentRuleOptions2 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions2.SetSelectedFromInactive(False)
    
    curves2 = [NXOpen.ICurve.Null] * 2 
    curves2[0] = arc1
    curves2[1] = arc2
    seedPoint2 = NXOpen.Point3d(2.8024474053275377, 11.901562967846559, 0.0)
    regionBoundaryRule2 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch2, curves2, seedPoint2, 0.01, selectionIntentRuleOptions2)
    
    selectionIntentRuleOptions2.Dispose()
    selectionIntentRuleOptions3 = workPart.ScRuleFactory.CreateRuleOptions()
    
    selectionIntentRuleOptions3.SetSelectedFromInactive(False)
    
    curves3 = [NXOpen.ICurve.Null] * 2 
    curves3[0] = arc1
    curves3[1] = arc2
    seedPoint3 = NXOpen.Point3d(2.8024474053275377, 2.9015629678465582, 0.0)
    regionBoundaryRule3 = workPart.ScRuleFactory.CreateRuleRegionBoundary(sketch2, curves3, seedPoint3, 0.01, selectionIntentRuleOptions3)
    
    selectionIntentRuleOptions3.Dispose()
    section2.AllowSelfIntersection(True)
    
    section2.AllowDegenerateCurves(False)
    
    rules2 = [None] * 2 
    rules2[0] = regionBoundaryRule2
    rules2[1] = regionBoundaryRule3
    helpPoint2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section2.AddToSection(rules2, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint2, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId92, None)
    
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId94, None)
    
    direction6 = workPart.Directions.CreateDirection(sketch2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder2.Direction = direction6
    
    targetBodies10 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(2)")
    targetBodies10[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies10)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies11 = [NXOpen.Body.Null] * 1 
    targetBodies11[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies11)
    
    theSession.DeleteUndoMark(markId93, None)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies12 = [NXOpen.Body.Null] * 1 
    targetBodies12[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies12)
    
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId95, None)
    
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder2.ParentFeatureInternal = False
    
    feature4 = extrudeBuilder2.CommitFeature()
    
    theSession.DeleteUndoMark(markId96, None)
    
    theSession.SetUndoMarkName(markId91, "Extrude")
    
    expression9 = extrudeBuilder2.Limits.StartExtend.Value
    expression10 = extrudeBuilder2.Limits.EndExtend.Value
    extrudeBuilder2.Destroy()
    
    workPart.Expressions.Delete(expression8)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()