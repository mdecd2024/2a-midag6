﻿# NX 2027
# Journal created by Admin on Fri May 17 16:44:01 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Assemblies
import NXOpen.Positioning
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    # ----------------------------------------------
    #   Menu: File->New...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    fileNew1 = theSession.Parts.FileNew()
    
    theSession.SetUndoMarkName(markId1, "New Dialog")
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    fileNew1.TemplateFileName = "assembly-mm-template.prt"
    
    fileNew1.UseBlankTemplate = False
    
    fileNew1.ApplicationName = "AssemblyTemplate"
    
    fileNew1.Units = NXOpen.Part.Units.Millimeters
    
    fileNew1.RelationType = ""
    
    fileNew1.UsesMasterModel = "No"
    
    fileNew1.TemplateType = NXOpen.FileNewTemplateType.Item
    
    fileNew1.TemplatePresentationName = "Assembly"
    
    fileNew1.ItemType = ""
    
    fileNew1.Specialization = ""
    
    fileNew1.SetCanCreateAltrep(False)
    
    fileNew1.NewFileName = "F:\\yan1\\portable_2024\\portable_2024\\新增資料夾\\assembly.prt"
    
    fileNew1.MasterFileName = ""
    
    fileNew1.MakeDisplayedPart = True
    
    fileNew1.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    
    nXObject1 = fileNew1.Commit()
    
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    theSession.DeleteUndoMark(markId3, None)
    
    fileNew1.Destroy()
    
    theSession.ApplicationSwitchImmediate("UG_APP_MODELING")
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    addComponentBuilder1 = workPart.AssemblyManager.CreateAddComponentBuilder()
    
    componentPositioner1 = workPart.ComponentAssembly.Positioner
    
    componentPositioner1.BeginAssemblyConstraints()
    
    network1 = componentPositioner1.EstablishNetwork()
    
    componentNetwork1 = network1
    componentNetwork1.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    addComponentBuilder1.SetScatterOption(True)
    
    addComponentBuilder1.SetAllowMultipleAssemblyLocations(True)
    
    addComponentBuilder1.SetInitialLocationType(NXOpen.Assemblies.AddComponentBuilder.LocationType.Snap)
    
    addComponentBuilder1.ReferenceSet = "Use Model"
    
    addComponentBuilder1.Layer = -1
    
    theSession.SetUndoMarkName(markId4, "Assemble Dialog")
    
    componentNetwork1.MoveObjectsState = True
    
    # ----------------------------------------------
    #   Dialog Begin Assemble
    # ----------------------------------------------
    basePart1, partLoadStatus1 = theSession.Parts.OpenBase("F:\\yan1\\portable_2024\\portable_2024\\新增資料夾\\base_w.prt")
    
    partLoadStatus1.Dispose()
    basePart2, partLoadStatus2 = theSession.Parts.OpenBase("F:\\yan1\\portable_2024\\portable_2024\\新增資料夾\\platform.prt")
    
    partLoadStatus2.Dispose()
    basePart3, partLoadStatus3 = theSession.Parts.OpenBase("F:\\yan1\\portable_2024\\portable_2024\\新增資料夾\\s_link.prt")
    
    partLoadStatus3.Dispose()
    basePart4, partLoadStatus4 = theSession.Parts.OpenBase("F:\\yan1\\portable_2024\\portable_2024\\新增資料夾\\s_link1.prt")
    
    partLoadStatus4.Dispose()
    basePart5, partLoadStatus5 = theSession.Parts.OpenBase("F:\\yan1\\portable_2024\\portable_2024\\新增資料夾\\y_link.prt")
    
    partLoadStatus5.Dispose()
    basePart6, partLoadStatus6 = theSession.Parts.OpenBase("F:\\yan1\\portable_2024\\portable_2024\\新增資料夾\\y_link1.prt")
    
    partLoadStatus6.Dispose()
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Add Component")
    
    point1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    orientation1 = NXOpen.Matrix3x3()
    
    orientation1.Xx = 0.63121905864762995
    orientation1.Xy = 0.77560460287442845
    orientation1.Xz = -0.0
    orientation1.Yx = -0.29117688182626567
    orientation1.Yy = 0.23697177216995516
    orientation1.Yz = 0.92685511418158761
    orientation1.Zx = 0.71887309275694333
    orientation1.Zy = -0.58504861267644326
    orientation1.Zz = 0.37541922875025491
    addComponentBuilder1.SetInitialLocationAndOrientation(point1, orientation1)
    
    partstouse1 = [NXOpen.BasePart.Null] * 6 
    part1 = basePart1
    partstouse1[0] = part1
    part2 = basePart2
    partstouse1[1] = part2
    part3 = basePart3
    partstouse1[2] = part3
    part4 = basePart4
    partstouse1[3] = part4
    part5 = basePart5
    partstouse1[4] = part5
    part6 = basePart6
    partstouse1[5] = part6
    addComponentBuilder1.SetPartsToAdd(partstouse1)
    
    arrangement1 = workPart.ComponentAssembly.Arrangements.FindObject("Arrangement 1")
    componentPositioner1.PrimaryArrangement = arrangement1
    
    scaleAboutPoint1 = NXOpen.Point3d(228.8208998592568, 166.26939218745062, 0.0)
    viewCenter1 = NXOpen.Point3d(-228.8208998592568, -166.26939218745062, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(183.05671988740531, 127.88308235124816, 0.0)
    viewCenter2 = NXOpen.Point3d(-183.05671988740531, -127.88308235124823, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(146.44537590992428, 100.25349332151356, 0.0)
    viewCenter3 = NXOpen.Point3d(-146.44537590992428, -100.25349332151369, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(116.60884137874346, 80.202794657210845, 0.0)
    viewCenter4 = NXOpen.Point3d(-116.60884137874346, -80.202794657210987, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint4, viewCenter4)
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assemble")
    
    theSession.DeleteUndoMark(markId6, None)
    
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assemble")
    
    addComponentBuilder1.SetKeepConstraintsOption(True)
    
    nXObject2 = addComponentBuilder1.Commit()
    
    componentNetwork1.Solve()
    
    componentPositioner1.ClearNetwork()
    
    nErrs1 = theSession.UpdateManager.AddToDeleteList(NXOpen.TaggedObject.Null)
    
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraint")
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId8)
    
    componentPositioner1.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner1.EndAssemblyConstraints()
    
    errorList1 = addComponentBuilder1.GetOperationFailures()
    
    errorList1.Dispose()
    theSession.DeleteUndoMark(markId7, None)
    
    theSession.SetUndoMarkName(markId4, "Assemble")
    
    addComponentBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId5, None)
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    scaleAboutPoint5 = NXOpen.Point3d(91.535203185567596, 38.322154443718446, 0.0)
    viewCenter5 = NXOpen.Point3d(-91.535203185567596, -38.322154443718553, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(63.768064994347569, 28.555479654062196, 0.0)
    viewCenter6 = NXOpen.Point3d(-63.768064994347505, -28.555479654062317, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint6, viewCenter6)
    
    scaleAboutPoint7 = NXOpen.Point3d(51.014451995478069, 22.844383723249731, 0.0)
    viewCenter7 = NXOpen.Point3d(-51.014451995478026, -22.844383723249852, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint7, viewCenter7)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner2 = workPart.ComponentAssembly.Positioner
    
    componentPositioner2.ClearNetwork()
    
    componentPositioner2.PrimaryArrangement = arrangement1
    
    componentPositioner2.BeginAssemblyConstraints()
    
    allowInterpartPositioning1 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit1)
    
    unit2 = workPart.UnitCollection.FindObject("Degrees")
    expression4 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit2)
    
    expression5 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression6 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression7 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression8 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    network2 = componentPositioner2.EstablishNetwork()
    
    componentNetwork2 = network2
    componentNetwork2.MoveObjectsState = True
    
    componentNetwork2.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork2.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId10, "Assembly Constraints Dialog")
    
    componentNetwork2.MoveObjectsState = True
    
    componentNetwork2.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    component1 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT s_link 1")
    face1 = component1.FindObject("PROTO#.Features|EXTRUDE(4)|FACE 170 {(4.5,3,1.4) EXTRUDE(2)}")
    line1 = workPart.Lines.CreateFaceAxis(face1, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    objects1 = [NXOpen.TaggedObject.Null] * 1 
    objects1[0] = line1
    nErrs3 = theSession.UpdateManager.AddObjectsToDeleteList(objects1)
    
    scaleAboutPoint8 = NXOpen.Point3d(-100.45922854494142, -86.668508554955125, 0.0)
    viewCenter8 = NXOpen.Point3d(100.45922854494154, 86.668508554954968, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(-80.367382835953123, -69.334806843964088, 0.0)
    viewCenter9 = NXOpen.Point3d(80.36738283595318, 69.334806843963975, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint9, viewCenter9)
    
    scaleAboutPoint10 = NXOpen.Point3d(-64.150393085126865, -55.611358658806907, 0.0)
    viewCenter10 = NXOpen.Point3d(64.150393085126908, 55.611358658806786, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(-51.320314468101465, -44.603897473954049, 0.0)
    viewCenter11 = NXOpen.Point3d(51.320314468101529, 44.603897473953936, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint11, viewCenter11)
    
    component2 = nXObject2
    face2 = component2.FindObject("PROTO#.Features|EXTRUDE(8)|FACE 140 1 {(65.25,7,14.5) EXTRUDE(2)}")
    line2 = workPart.Lines.CreateFaceAxis(face2, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    scaleAboutPoint12 = NXOpen.Point3d(-40.321464074266764, -35.683117979163256, 0.0)
    viewCenter12 = NXOpen.Point3d(40.321464074266807, 35.683117979163143, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(-32.183692509391946, -28.546494383330629, 0.0)
    viewCenter13 = NXOpen.Point3d(32.183692509392003, 28.546494383330501, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(-25.746954007513555, -22.8371955066645, 0.0)
    viewCenter14 = NXOpen.Point3d(25.746954007513605, 22.837195506664383, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(-20.597563206010836, -18.269756405331613, 0.0)
    viewCenter15 = NXOpen.Point3d(20.597563206010907, 18.26975640533151, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint15, viewCenter15)
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint1 = componentPositioner2.CreateConstraint(True)
    
    componentConstraint1 = constraint1
    componentConstraint1.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    edge1 = component1.FindObject("PROTO#.Features|EXTRUDE(4)|EDGE * 170 EXTRUDE(2) 130 {(2.25,4.2990381056767,2.8)(4.5,3,2.8)(2.25,1.7009618943233,2.8) EXTRUDE(2)}")
    constraintReference1 = componentConstraint1.CreateConstraintReference(component1, edge1, False, False, False)
    
    helpPoint1 = NXOpen.Point3d(104.80347664434306, 228.82799945861012, 156.4366977751406)
    constraintReference1.HelpPoint = helpPoint1
    
    edge2 = component2.FindObject("PROTO#.Features|EXTRUDE(8)|EDGE * 140 EXTRUDE(4) 200 {(64.5,5.7009618943234,16.75)(64.5,7,14.5)(64.5,8.2990381056766,16.75) EXTRUDE(2)}")
    constraintReference2 = componentConstraint1.CreateConstraintReference(component2, edge2, False, False, False)
    
    helpPoint2 = NXOpen.Point3d(74.401868784979641, 37.97621668493079, 42.845412821055049)
    constraintReference2.HelpPoint = helpPoint2
    
    constraintReference2.SetFixHint(True)
    
    objects2 = [NXOpen.TaggedObject.Null] * 1 
    objects2[0] = line2
    nErrs4 = theSession.UpdateManager.AddObjectsToDeleteList(objects2)
    
    componentNetwork2.Solve()
    
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Reverse Last Constraint")
    
    componentConstraint1.FlipAlignment()
    
    componentNetwork2.Solve()
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    theSession.DeleteUndoMark(markId14, None)
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs5 = theSession.UpdateManager.DoUpdate(markId11)
    
    componentNetwork2.Solve()
    
    componentPositioner2.ClearNetwork()
    
    nErrs6 = theSession.UpdateManager.AddToDeleteList(componentNetwork2)
    
    componentPositioner2.DeleteNonPersistentConstraints()
    
    nErrs7 = theSession.UpdateManager.DoUpdate(markId11)
    
    theSession.DeleteUndoMark(markId15, None)
    
    theSession.SetUndoMarkName(markId10, "Assembly Constraints")
    
    componentPositioner2.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner2.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId11, None)
    
    theSession.DeleteUndoMark(markId13, None)
    
    theSession.DeleteUndoMark(markId12, None)
    
    theSession.DeleteUndoMark(markId9, None)
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    scaleAboutPoint16 = NXOpen.Point3d(-3.5363852810319694, 4.7590716813887566, 0.0)
    viewCenter16 = NXOpen.Point3d(3.5363852810320369, -4.7590716813888685, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint16, viewCenter16)
    
    scaleAboutPoint17 = NXOpen.Point3d(-3.9972440011664587, 6.1369452017908586, 0.0)
    viewCenter17 = NXOpen.Point3d(3.9972440011665271, -6.1369452017909669, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(-4.761423001389459, 7.7887475022729014, 0.0)
    viewCenter18 = NXOpen.Point3d(4.7614230013895291, -7.7887475022729964, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(-5.804821251693947, 9.8828918778840329, 0.0)
    viewCenter19 = NXOpen.Point3d(5.8048212516940154, -9.8828918778841146, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(-7.2560265646174544, 12.537311722408651, 0.0)
    viewCenter20 = NXOpen.Point3d(7.2560265646175175, -12.537311722408729, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint20, viewCenter20)
    
    scaleAboutPoint21 = NXOpen.Point3d(-8.6107910181377871, 16.47531348137035, 0.0)
    viewCenter21 = NXOpen.Point3d(8.6107910181378564, -16.475313481370435, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(-8.8978173854090574, 22.172786871704893, 0.0)
    viewCenter22 = NXOpen.Point3d(8.8978173854091303, -22.172786871704965, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(14.351318363563102, 38.838255321392495, 0.0)
    viewCenter23 = NXOpen.Point3d(-14.35131836356298, -38.83825532139258, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint23, viewCenter23)
    
    scaleAboutPoint24 = NXOpen.Point3d(19.733062749899226, 48.547819151740612, 0.0)
    viewCenter24 = NXOpen.Point3d(-19.733062749899151, -48.547819151740704, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(27.189021118469071, 60.684773939675758, 0.0)
    viewCenter25 = NXOpen.Point3d(-27.189021118469025, -60.684773939675829, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(43.446373952192879, 75.855967424594752, 0.0)
    viewCenter26 = NXOpen.Point3d(-43.446373952192758, -75.855967424594752, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(208.03455269447181, 154.82150395262272, 0.0)
    viewCenter27 = NXOpen.Point3d(-208.03455269447164, -154.82150395262263, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint27, viewCenter27)
    
    scaleAboutPoint28 = NXOpen.Point3d(258.9482721696977, 196.26417668675819, 0.0)
    viewCenter28 = NXOpen.Point3d(-258.94827216969765, -196.26417668675819, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(322.31669183913226, 248.06751760442756, 0.0)
    viewCenter29 = NXOpen.Point3d(-322.31669183913198, -248.06751760442756, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint29, viewCenter29)
    
    scaleAboutPoint30 = NXOpen.Point3d(385.78776013654084, 296.39791327563495, 0.0)
    viewCenter30 = NXOpen.Point3d(-385.78776013654056, -296.39791327563495, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(497.20429175025362, 391.8825224225115, 0.0)
    viewCenter31 = NXOpen.Point3d(-497.20429175025345, -391.88252242251161, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(398.6188386333215, 315.2168284042466, 0.0)
    viewCenter32 = NXOpen.Point3d(-398.61883863332122, -315.21682840424671, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(318.89507090665722, 252.85778690989224, 0.0)
    viewCenter33 = NXOpen.Point3d(-318.89507090665694, -252.85778690989235, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(256.21097542371791, 203.92860757550179, 0.0)
    viewCenter34 = NXOpen.Point3d(-256.21097542371763, -203.92860757550184, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(205.40674781833107, 165.33272345718532, 0.0)
    viewCenter35 = NXOpen.Point3d(-205.4067478183307, -165.33272345718538, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(158.36904053541267, 137.87216250151505, 0.0)
    viewCenter36 = NXOpen.Point3d(-158.36904053541232, -137.87216250151513, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(126.13463405475356, 110.29773000121209, 0.0)
    viewCenter37 = NXOpen.Point3d(-126.13463405475323, -110.29773000121213, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint37, viewCenter37)
    
    scaleAboutPoint38 = NXOpen.Point3d(86.332149530809104, 74.559583685698612, 0.0)
    viewCenter38 = NXOpen.Point3d(-86.332149530808749, -74.559583685698669, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(106.79399016635796, 91.797983673181562, 0.0)
    viewCenter39 = NXOpen.Point3d(-106.79399016635763, -91.797983673181619, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint39, viewCenter39)
    
    scaleAboutPoint40 = NXOpen.Point3d(129.63837388960783, 109.84224382268101, 0.0)
    viewCenter40 = NXOpen.Point3d(-129.63837388960741, -109.84224382268107, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(159.85812996522574, 135.11296738156736, 0.0)
    viewCenter41 = NXOpen.Point3d(-159.85812996522532, -135.11296738156742, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint41, viewCenter41)
    
    scaleAboutPoint42 = NXOpen.Point3d(197.08536571055222, 166.70137183017528, 0.0)
    viewCenter42 = NXOpen.Point3d(-197.08536571055197, -166.70137183017536, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(213.50914618643165, 84.51403703212911, 0.0)
    viewCenter43 = NXOpen.Point3d(-213.50914618643131, -84.51403703212911, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint43, viewCenter43)
    
    scaleAboutPoint44 = NXOpen.Point3d(266.03102749992058, 102.22092535768654, 0.0)
    viewCenter44 = NXOpen.Point3d(-266.0310274999203, -102.22092535768654, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint44, viewCenter44)
    
    scaleAboutPoint45 = NXOpen.Point3d(332.53878437490073, 127.77615669710816, 0.0)
    viewCenter45 = NXOpen.Point3d(-332.53878437490056, -127.77615669710816, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint45, viewCenter45)
    
    scaleAboutPoint46 = NXOpen.Point3d(415.67348046862571, 159.72019587138522, 0.0)
    viewCenter46 = NXOpen.Point3d(-415.67348046862571, -159.72019587138522, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint46, viewCenter46)
    
    scaleAboutPoint47 = NXOpen.Point3d(522.93327727765222, 199.6502448392315, 0.0)
    viewCenter47 = NXOpen.Point3d(-522.93327727765222, -199.6502448392315, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint47, viewCenter47)
    
    scaleAboutPoint48 = NXOpen.Point3d(795.67723100153955, 562.82155841185022, 0.0)
    viewCenter48 = NXOpen.Point3d(-795.67723100153955, -562.82155841185022, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint48, viewCenter48)
    
    scaleAboutPoint49 = NXOpen.Point3d(636.54178480123164, 450.25724672948007, 0.0)
    viewCenter49 = NXOpen.Point3d(-636.54178480123164, -450.25724672948036, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint49, viewCenter49)
    
    scaleAboutPoint50 = NXOpen.Point3d(507.89685716423725, 356.1960853533401, 0.0)
    viewCenter50 = NXOpen.Point3d(-507.89685716423725, -356.19608535334032, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint50, viewCenter50)
    
    scaleAboutPoint51 = NXOpen.Point3d(352.85465866147018, 152.36905714927104, 0.0)
    viewCenter51 = NXOpen.Point3d(-352.85465866147018, -152.36905714927138, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint51, viewCenter51)
    
    scaleAboutPoint52 = NXOpen.Point3d(279.71751122981999, 109.0641672226361, 0.0)
    viewCenter52 = NXOpen.Point3d(-279.71751122981999, -109.06416722263639, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint52, viewCenter52)
    
    scaleAboutPoint53 = NXOpen.Point3d(221.72103642437111, 80.408091913159168, 0.0)
    viewCenter53 = NXOpen.Point3d(-221.72103642437111, -80.408091913159396, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint53, viewCenter53)
    
    scaleAboutPoint54 = NXOpen.Point3d(175.73445109190897, 59.39933938776354, 0.0)
    viewCenter54 = NXOpen.Point3d(-175.73445109190902, -59.399339387763725, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint54, viewCenter54)
    
    scaleAboutPoint55 = NXOpen.Point3d(109.4918698391955, 44.453699154713277, 0.0)
    viewCenter55 = NXOpen.Point3d(-109.49186983919557, -44.45369915471354, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint55, viewCenter55)
    
    scaleAboutPoint56 = NXOpen.Point3d(79.184520267706276, 39.417073142110304, 0.0)
    viewCenter56 = NXOpen.Point3d(-79.184520267706276, -39.417073142110539, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint56, viewCenter56)
    
    scaleAboutPoint57 = NXOpen.Point3d(52.415947929419765, 42.745625985221842, 0.0)
    viewCenter57 = NXOpen.Point3d(-52.415947929419744, -42.745625985222127, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint57, viewCenter57)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner3 = workPart.ComponentAssembly.Positioner
    
    componentPositioner3.ClearNetwork()
    
    componentPositioner3.PrimaryArrangement = arrangement1
    
    componentPositioner3.BeginAssemblyConstraints()
    
    allowInterpartPositioning2 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression9 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression10 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression11 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit1)
    
    expression12 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit2)
    
    expression13 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression14 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression15 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression16 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    network3 = componentPositioner3.EstablishNetwork()
    
    componentNetwork3 = network3
    componentNetwork3.MoveObjectsState = True
    
    componentNetwork3.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork3.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId17, "Assembly Constraints Dialog")
    
    componentNetwork3.MoveObjectsState = True
    
    componentNetwork3.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    component3 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT s_link1 1")
    face3 = component3.FindObject("PROTO#.Features|EXTRUDE(4)|FACE 170 {(4.5,3,1.4) EXTRUDE(2)}")
    line3 = workPart.Lines.CreateFaceAxis(face3, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    objects3 = [NXOpen.TaggedObject.Null] * 1 
    objects3[0] = line3
    nErrs8 = theSession.UpdateManager.AddObjectsToDeleteList(objects3)
    
    scaleAboutPoint58 = NXOpen.Point3d(-130.50730136865144, -54.153802887507574, 0.0)
    viewCenter58 = NXOpen.Point3d(130.5073013686515, 54.153802887507304, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint58, viewCenter58)
    
    scaleAboutPoint59 = NXOpen.Point3d(-103.86766665628755, -45.116957105451455, 0.0)
    viewCenter59 = NXOpen.Point3d(103.86766665628758, 45.116957105451178, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint59, viewCenter59)
    
    scaleAboutPoint60 = NXOpen.Point3d(-83.094133325030029, -37.241671153446241, 0.0)
    viewCenter60 = NXOpen.Point3d(83.094133325030043, 37.241671153445985, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint60, viewCenter60)
    
    scaleAboutPoint61 = NXOpen.Point3d(-66.590117206932533, -31.056252938750557, 0.0)
    viewCenter61 = NXOpen.Point3d(66.59011720693259, 31.056252938750305, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint61, viewCenter61)
    
    scaleAboutPoint62 = NXOpen.Point3d(-53.455790640599623, -33.019513290885975, 0.0)
    viewCenter62 = NXOpen.Point3d(53.455790640599673, 33.019513290885726, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint62, viewCenter62)
    
    scaleAboutPoint63 = NXOpen.Point3d(-42.83811126250113, -26.415610632708809, 0.0)
    viewCenter63 = NXOpen.Point3d(42.838111262501194, 26.415610632708557, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint63, viewCenter63)
    
    face4 = component2.FindObject("PROTO#.Features|EXTRUDE(6)|FACE 140 {(7,60.85,17.5000000000134) EXTRUDE(2)}")
    line4 = workPart.Lines.CreateFaceAxis(face4, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint2 = componentPositioner3.CreateConstraint(True)
    
    componentConstraint2 = constraint2
    componentConstraint2.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    edge3 = component3.FindObject("PROTO#.Features|EXTRUDE(4)|EDGE * 170 EXTRUDE(2) 130 {(2.25,4.2990381056767,2.8)(4.5,3,2.8)(2.25,1.7009618943233,2.8) EXTRUDE(2)}")
    constraintReference3 = componentConstraint2.CreateConstraintReference(component3, edge3, False, False, False)
    
    helpPoint3 = NXOpen.Point3d(113.90685752547463, 229.19270720840848, 144.03993142358425)
    constraintReference3.HelpPoint = helpPoint3
    
    edge4 = component2.FindObject("PROTO#.Features|EXTRUDE(4)|EDGE * 350 EXTRUDE(6) 140 {(8.2990381056883,61.6,16.7500000000067)(7,61.6,14.4999999999866)(5.7009618943117,61.6,16.7500000000067) EXTRUDE(2)}")
    constraintReference4 = componentConstraint2.CreateConstraintReference(component2, edge4, False, False, False)
    
    helpPoint4 = NXOpen.Point3d(15.677585078582753, 91.085759151630839, 42.175680131197645)
    constraintReference4.HelpPoint = helpPoint4
    
    constraintReference4.SetFixHint(True)
    
    objects4 = [NXOpen.TaggedObject.Null] * 1 
    objects4[0] = line4
    nErrs9 = theSession.UpdateManager.AddObjectsToDeleteList(objects4)
    
    componentNetwork3.Solve()
    
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Reverse Last Constraint")
    
    componentConstraint2.FlipAlignment()
    
    componentNetwork3.Solve()
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    theSession.DeleteUndoMark(markId21, None)
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs10 = theSession.UpdateManager.DoUpdate(markId18)
    
    componentNetwork3.Solve()
    
    componentPositioner3.ClearNetwork()
    
    nErrs11 = theSession.UpdateManager.AddToDeleteList(componentNetwork3)
    
    componentPositioner3.DeleteNonPersistentConstraints()
    
    nErrs12 = theSession.UpdateManager.DoUpdate(markId18)
    
    theSession.DeleteUndoMark(markId22, None)
    
    theSession.SetUndoMarkName(markId17, "Assembly Constraints")
    
    componentPositioner3.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner3.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId18, None)
    
    theSession.DeleteUndoMark(markId20, None)
    
    theSession.DeleteUndoMark(markId19, None)
    
    theSession.DeleteUndoMark(markId16, None)
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    scaleAboutPoint64 = NXOpen.Point3d(-18.340296005352084, 5.2022955015180328, 0.0)
    viewCenter64 = NXOpen.Point3d(18.340296005352172, -5.2022955015182735, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint64, viewCenter64)
    
    scaleAboutPoint65 = NXOpen.Point3d(-22.925370006690123, 6.4293906268761205, 0.0)
    viewCenter65 = NXOpen.Point3d(22.925370006690212, -6.4293906268763719, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint65, viewCenter65)
    
    scaleAboutPoint66 = NXOpen.Point3d(-28.656712508362656, 8.0367382835951844, 0.0)
    viewCenter66 = NXOpen.Point3d(28.656712508362748, -8.0367382835954437, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint66, viewCenter66)
    
    scaleAboutPoint67 = NXOpen.Point3d(-35.820890635453338, 10.045922854494018, 0.0)
    viewCenter67 = NXOpen.Point3d(35.820890635453395, -10.045922854494261, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint67, viewCenter67)
    
    scaleAboutPoint68 = NXOpen.Point3d(-44.776113294316666, 12.557403568117545, 0.0)
    viewCenter68 = NXOpen.Point3d(44.776113294316744, -12.557403568117778, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint68, viewCenter68)
    
    scaleAboutPoint69 = NXOpen.Point3d(-41.977606213421879, 13.544056705612505, 0.0)
    viewCenter69 = NXOpen.Point3d(41.977606213421943, -13.54405670561275, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint69, viewCenter69)
    
    scaleAboutPoint70 = NXOpen.Point3d(-48.659938826455935, 16.257352833723651, 0.0)
    viewCenter70 = NXOpen.Point3d(48.659938826455978, -16.257352833723882, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint70, viewCenter70)
    
    scaleAboutPoint71 = NXOpen.Point3d(-52.415947929419701, 25.086777217556406, 0.0)
    viewCenter71 = NXOpen.Point3d(52.415947929419723, -25.086777217556623, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint71, viewCenter71)
    
    scaleAboutPoint72 = NXOpen.Point3d(-42.829715741258454, 20.293661123475758, 0.0)
    viewCenter72 = NXOpen.Point3d(42.829715741258497, -20.293661123475985, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint72, viewCenter72)
    
    scaleAboutPoint73 = NXOpen.Point3d(-34.263772593006721, 16.234928898780577, 0.0)
    viewCenter73 = NXOpen.Point3d(34.263772593006848, -16.234928898780822, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint73, viewCenter73)
    
    scaleAboutPoint74 = NXOpen.Point3d(-32.146953134381157, 4.6641784681578722, 0.0)
    viewCenter74 = NXOpen.Point3d(32.146953134381306, -4.6641784681581164, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint74, viewCenter74)
    
    scaleAboutPoint75 = NXOpen.Point3d(-25.717562507504919, 3.2721005868922477, 0.0)
    viewCenter75 = NXOpen.Point3d(25.717562507505054, -3.2721005868925022, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint75, viewCenter75)
    
    scaleAboutPoint76 = NXOpen.Point3d(-20.665898443530715, 2.43398359446017, 0.0)
    viewCenter76 = NXOpen.Point3d(20.66589844353085, -2.4339835944604284, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint76, viewCenter76)
    
    scaleAboutPoint77 = NXOpen.Point3d(-16.532718754824575, 1.9471868755681041, 0.0)
    viewCenter77 = NXOpen.Point3d(16.532718754824675, -1.9471868755683672, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint77, viewCenter77)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner4 = workPart.ComponentAssembly.Positioner
    
    componentPositioner4.ClearNetwork()
    
    componentPositioner4.PrimaryArrangement = arrangement1
    
    componentPositioner4.BeginAssemblyConstraints()
    
    allowInterpartPositioning3 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression17 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression18 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression19 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit1)
    
    expression20 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit2)
    
    expression21 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression22 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression23 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression24 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    network4 = componentPositioner4.EstablishNetwork()
    
    componentNetwork4 = network4
    componentNetwork4.MoveObjectsState = True
    
    componentNetwork4.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork4.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId24, "Assembly Constraints Dialog")
    
    componentNetwork4.MoveObjectsState = True
    
    componentNetwork4.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    scaleAboutPoint78 = NXOpen.Point3d(-13.520090003945416, 6.6718705019468816, 0.0)
    viewCenter78 = NXOpen.Point3d(13.520090003945528, -6.6718705019471374, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint78, viewCenter78)
    
    scaleAboutPoint79 = NXOpen.Point3d(-16.900112504931791, 8.339838127433632, 0.0)
    viewCenter79 = NXOpen.Point3d(16.900112504931879, -8.3398381274338877, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint79, viewCenter79)
    
    scaleAboutPoint80 = NXOpen.Point3d(-21.125140631164747, 10.42479765929207, 0.0)
    viewCenter80 = NXOpen.Point3d(21.125140631164847, -10.424797659292329, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint80, viewCenter80)
    
    scaleAboutPoint81 = NXOpen.Point3d(-26.406425788955957, 13.030997074115124, 0.0)
    viewCenter81 = NXOpen.Point3d(26.406425788956035, -13.030997074115369, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint81, viewCenter81)
    
    scaleAboutPoint82 = NXOpen.Point3d(-35.878295908907553, 39.537882091616041, 0.0)
    viewCenter82 = NXOpen.Point3d(35.878295908907631, -39.537882091616304, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint82, viewCenter82)
    
    scaleAboutPoint83 = NXOpen.Point3d(-44.847869886134461, 49.601744094064621, 0.0)
    viewCenter83 = NXOpen.Point3d(44.847869886134553, -49.601744094064863, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint83, viewCenter83)
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = 0.63121905864762995
    rotMatrix1.Xy = 0.77560460287442845
    rotMatrix1.Xz = 0.0
    rotMatrix1.Yx = -0.082543633326781718
    rotMatrix1.Yy = 0.06717741789152569
    rotMatrix1.Yz = 0.99432074459031639
    rotMatrix1.Zx = 0.77119974623777843
    rotMatrix1.Zy = -0.62763420439410988
    rotMatrix1.Zz = 0.1064248884300983
    translation1 = NXOpen.Point3d(-169.77511664563988, -34.299406949050606, 33.544608394951489)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 1.1799148276388216)
    
    scaleAboutPoint84 = NXOpen.Point3d(-52.696247116207964, 70.074796697084992, 0.0)
    viewCenter84 = NXOpen.Point3d(52.696247116208056, -70.074796697085262, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint84, viewCenter84)
    
    scaleAboutPoint85 = NXOpen.Point3d(-65.870308895259953, 87.313196684567927, 0.0)
    viewCenter85 = NXOpen.Point3d(65.870308895260067, -87.313196684568211, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint85, viewCenter85)
    
    scaleAboutPoint86 = NXOpen.Point3d(-82.337886119074994, 108.79112187222452, 0.0)
    viewCenter86 = NXOpen.Point3d(82.337886119075051, -108.79112187222476, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint86, viewCenter86)
    
    scaleAboutPoint87 = NXOpen.Point3d(-102.04642269013019, 144.74825192741633, 0.0)
    viewCenter87 = NXOpen.Point3d(102.04642269013026, -144.74825192741656, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint87, viewCenter87)
    
    scaleAboutPoint88 = NXOpen.Point3d(-127.55802836266267, 180.9353149092704, 0.0)
    viewCenter88 = NXOpen.Point3d(127.55802836266277, -180.93531490927069, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint88, viewCenter88)
    
    scaleAboutPoint89 = NXOpen.Point3d(-159.44753545332836, 226.85346782308298, 0.0)
    viewCenter89 = NXOpen.Point3d(159.44753545332858, -226.85346782308332, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint89, viewCenter89)
    
    scaleAboutPoint90 = NXOpen.Point3d(-199.30941931666047, 284.42224001197246, 0.0)
    viewCenter90 = NXOpen.Point3d(199.30941931666064, -284.42224001197275, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint90, viewCenter90)
    
    scaleAboutPoint91 = NXOpen.Point3d(-159.44753545332841, 227.53779200957791, 0.0)
    viewCenter91 = NXOpen.Point3d(159.44753545332841, -227.53779200957825, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint91, viewCenter91)
    
    scaleAboutPoint92 = NXOpen.Point3d(-127.5580283626627, 182.57769295685824, 0.0)
    viewCenter92 = NXOpen.Point3d(127.5580283626628, -182.57769295685864, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint92, viewCenter92)
    
    scaleAboutPoint93 = NXOpen.Point3d(-102.04642269013007, 146.06215436548655, 0.0)
    viewCenter93 = NXOpen.Point3d(102.04642269013026, -146.06215436548692, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint93, viewCenter93)
    
    scaleAboutPoint94 = NXOpen.Point3d(-81.286764168618646, 116.84972349238915, 0.0)
    viewCenter94 = NXOpen.Point3d(81.286764168618774, -116.8497234923896, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint94, viewCenter94)
    
    scaleAboutPoint95 = NXOpen.Point3d(-64.749112148106576, 93.479778793911294, 0.0)
    viewCenter95 = NXOpen.Point3d(64.749112148106676, -93.479778793911706, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint95, viewCenter95)
    
    scaleAboutPoint96 = NXOpen.Point3d(-51.350811019623926, 74.783823035128989, 0.0)
    viewCenter96 = NXOpen.Point3d(51.350811019623961, -74.783823035129402, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint96, viewCenter96)
    
    scaleAboutPoint97 = NXOpen.Point3d(-40.721865856610052, 59.109492509925012, 0.0)
    viewCenter97 = NXOpen.Point3d(40.721865856610108, -59.109492509925396, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint97, viewCenter97)
    
    scaleAboutPoint98 = NXOpen.Point3d(-32.290466318016776, 45.995975355219308, 0.0)
    viewCenter98 = NXOpen.Point3d(32.290466318016847, -45.995975355219663, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint98, viewCenter98)
    
    scaleAboutPoint99 = NXOpen.Point3d(-27.095289070406938, 34.500569346005342, 0.0)
    viewCenter99 = NXOpen.Point3d(27.095289070407034, -34.50056934600569, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint99, viewCenter99)
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = 0.64144528439250603
    rotMatrix2.Xy = 0.76671218235204841
    rotMatrix2.Xz = -0.026464628536520297
    rotMatrix2.Yx = 0.25882823392910748
    rotMatrix2.Yy = -0.18380880399041452
    rotMatrix2.Yz = 0.94827330917660679
    rotMatrix2.Zx = 0.72218826662564684
    rotMatrix2.Zy = -0.61511523555230885
    rotMatrix2.Zz = -0.31635005063959026
    translation2 = NXOpen.Point3d(-136.33450905083845, -56.624815361750962, 80.776705690297703)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation2, 2.880651434665094)
    
    scaleAboutPoint100 = NXOpen.Point3d(-20.665898443530715, 34.7646336038949, 0.0)
    viewCenter100 = NXOpen.Point3d(20.665898443530793, -34.764633603895234, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint100, viewCenter100)
    
    scaleAboutPoint101 = NXOpen.Point3d(-25.832373054413395, 43.340981457960169, 0.0)
    viewCenter101 = NXOpen.Point3d(25.832373054413456, -43.340981457960474, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint101, viewCenter101)
    
    scaleAboutPoint102 = NXOpen.Point3d(-32.290466318016769, 54.032713638814585, 0.0)
    viewCenter102 = NXOpen.Point3d(32.29046631801679, -54.03271363881489, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint102, viewCenter102)
    
    scaleAboutPoint103 = NXOpen.Point3d(-35.698904429362969, 55.701054398578762, 0.0)
    viewCenter103 = NXOpen.Point3d(35.698904429363033, -55.701054398579117, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint103, viewCenter103)
    
    scaleAboutPoint104 = NXOpen.Point3d(-43.278194440119712, 67.38392450391683, 0.0)
    viewCenter104 = NXOpen.Point3d(43.278194440119748, -67.383924503917157, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint104, viewCenter104)
    
    scaleAboutPoint105 = NXOpen.Point3d(-54.097743050149653, 83.949606443107683, 0.0)
    viewCenter105 = NXOpen.Point3d(54.097743050149653, -83.949606443108038, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint105, viewCenter105)
    
    scaleAboutPoint106 = NXOpen.Point3d(-66.22068287874535, 102.13401618600126, 0.0)
    viewCenter106 = NXOpen.Point3d(66.22068287874535, -102.13401618600162, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint106, viewCenter106)
    
    scaleAboutPoint107 = NXOpen.Point3d(-53.86999996088408, -95.695894239456905, 0.0)
    viewCenter107 = NXOpen.Point3d(53.869999960884158, 95.695894239456578, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint107, viewCenter107)
    
    scaleAboutPoint108 = NXOpen.Point3d(-67.337499951105144, -119.61986779932109, 0.0)
    viewCenter108 = NXOpen.Point3d(67.337499951105244, 119.61986779932072, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint108, viewCenter108)
    
    scaleAboutPoint109 = NXOpen.Point3d(-84.856199125376421, -146.10321381667646, 0.0)
    viewCenter109 = NXOpen.Point3d(84.856199125376421, 146.10321381667612, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint109, viewCenter109)
    
    scaleAboutPoint110 = NXOpen.Point3d(-106.07024890672066, -173.21955970653974, 0.0)
    viewCenter110 = NXOpen.Point3d(106.07024890672038, 173.21955970653931, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint110, viewCenter110)
    
    scaleAboutPoint111 = NXOpen.Point3d(-132.07456799352954, 220.01022595813296, 0.0)
    viewCenter111 = NXOpen.Point3d(132.07456799352931, -220.01022595813342, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint111, viewCenter111)
    
    scaleAboutPoint112 = NXOpen.Point3d(-103.4698169980397, 174.91326206811436, 0.0)
    viewCenter112 = NXOpen.Point3d(103.46981699803948, -174.91326206811482, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint112, viewCenter112)
    
    scaleAboutPoint113 = NXOpen.Point3d(-81.899918639718365, 139.49264217513468, 0.0)
    viewCenter113 = NXOpen.Point3d(81.899918639717995, -139.49264217513513, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint113, viewCenter113)
    
    scaleAboutPoint114 = NXOpen.Point3d(-64.819186944803846, 111.5941137401077, 0.0)
    viewCenter114 = NXOpen.Point3d(64.819186944803491, -111.59411374010816, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint114, viewCenter114)
    
    scaleAboutPoint115 = NXOpen.Point3d(-53.256845489784773, 20.601990228942785, 0.0)
    viewCenter115 = NXOpen.Point3d(53.256845489784439, -20.601990228943215, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint115, viewCenter115)
    
    scaleAboutPoint116 = NXOpen.Point3d(-42.605476391827857, 15.360395436000836, 0.0)
    viewCenter116 = NXOpen.Point3d(42.605476391827537, -15.360395436001275, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint116, viewCenter116)
    
    scaleAboutPoint117 = NXOpen.Point3d(-34.084381113462342, 12.108924869256061, 0.0)
    viewCenter117 = NXOpen.Point3d(34.084381113462037, -12.108924869256519, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint117, viewCenter117)
    
    component4 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT platform 1")
    face5 = component4.FindObject("PROTO#.Features|EXTRUDE(14)|FACE 170 1 {(60,64.04,-4.5) EXTRUDE(2)}")
    line5 = workPart.Lines.CreateFaceAxis(face5, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    scaleAboutPoint118 = NXOpen.Point3d(-28.272097176219287, 9.4001135281335433, 0.0)
    viewCenter118 = NXOpen.Point3d(28.272097176218981, -9.4001135281339963, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint118, viewCenter118)
    
    scaleAboutPoint119 = NXOpen.Point3d(-22.96210938170098, -6.0275537126966894, 0.0)
    viewCenter119 = NXOpen.Point3d(22.962109381700667, 6.0275537126962293, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint119, viewCenter119)
    
    scaleAboutPoint120 = NXOpen.Point3d(-27.554531258041148, -12.700916751753496, 0.0)
    viewCenter120 = NXOpen.Point3d(27.554531258040793, 12.700916751753043, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint120, viewCenter120)
    
    scaleAboutPoint121 = NXOpen.Point3d(-34.263772593006856, -16.952494816959053, 0.0)
    viewCenter121 = NXOpen.Point3d(34.263772593006529, 16.952494816958577, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint121, viewCenter121)
    
    scaleAboutPoint122 = NXOpen.Point3d(-42.829715741258525, -22.984533316644107, 0.0)
    viewCenter122 = NXOpen.Point3d(42.829715741258198, 22.984533316643649, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint122, viewCenter122)
    
    scaleAboutPoint123 = NXOpen.Point3d(-56.340136544456534, -11.912715438504682, 0.0)
    viewCenter123 = NXOpen.Point3d(56.340136544456151, 11.912715438504204, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint123, viewCenter123)
    
    scaleAboutPoint124 = NXOpen.Point3d(-45.072109235565264, -9.3059330013731429, 0.0)
    viewCenter124 = NXOpen.Point3d(45.072109235564859, 9.3059330013726065, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint124, viewCenter124)
    
    scaleAboutPoint125 = NXOpen.Point3d(-36.057687388452266, -7.2653549215540316, 0.0)
    viewCenter125 = NXOpen.Point3d(36.057687388451818, 7.2653549215535111, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint125, viewCenter125)
    
    scaleAboutPoint126 = NXOpen.Point3d(-29.133176278033176, -5.3817443863363836, 0.0)
    viewCenter126 = NXOpen.Point3d(29.133176278032686, 5.3817443863358694, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint126, viewCenter126)
    
    scaleAboutPoint127 = NXOpen.Point3d(-23.88059375696908, -1.435131836356542, 0.0)
    viewCenter127 = NXOpen.Point3d(23.88059375696859, 1.4351318363560428, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint127, viewCenter127)
    
    scaleAboutPoint128 = NXOpen.Point3d(-19.104475005575335, -1.1481054690852959, 0.0)
    viewCenter128 = NXOpen.Point3d(19.104475005574802, 1.148105469084779, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint128, viewCenter128)
    
    face6 = component4.FindObject("PROTO#.Features|EXTRUDE(14)|FACE 170 {(60,56.04,-4.5) EXTRUDE(2)}")
    line6 = workPart.Lines.CreateFaceAxis(face6, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    scaleAboutPoint129 = NXOpen.Point3d(-17.340985005060702, 0.84500562524633482, 0.0)
    viewCenter129 = NXOpen.Point3d(17.340985005060197, -0.84500562524684864, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint129, viewCenter129)
    
    scaleAboutPoint130 = NXOpen.Point3d(-13.872788004048619, 0.61722150017985189, 0.0)
    viewCenter130 = NXOpen.Point3d(13.872788004048108, -0.61722150018037814, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint130, viewCenter130)
    
    scaleAboutPoint131 = NXOpen.Point3d(-11.098230403238937, 0.49377720014383741, 0.0)
    viewCenter131 = NXOpen.Point3d(11.098230403238439, -0.49377720014435067, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint131, viewCenter131)
    
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint3 = componentPositioner4.CreateConstraint(True)
    
    componentConstraint3 = constraint3
    componentConstraint3.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    edge5 = component2.FindObject("PROTO#.Features|EXTRUDE(10)|EDGE * 150 EXTRUDE(12) 140 {(64.2990381056782,60,55.2499999999991)(63,60,57.5000000000018)(61.7009618943218,60,55.2499999999991) EXTRUDE(2)}")
    constraintReference5 = componentConstraint3.CreateConstraintReference(component2, edge5, False, False, False)
    
    helpPoint5 = NXOpen.Point3d(74.209248924807355, 89.485758144312342, 83.713942870975174)
    constraintReference5.HelpPoint = helpPoint5
    
    edge6 = component4.FindObject("PROTO#.Features|EXTRUDE(14)|EDGE * 170 EXTRUDE(12) 250 {(61.2990381056767,55.04,-5.25)(60,55.04,-7.5)(58.7009618943233,55.04,-5.25) EXTRUDE(2)}")
    constraintReference6 = componentConstraint3.CreateConstraintReference(component4, edge6, False, False, False)
    
    helpPoint6 = NXOpen.Point3d(19.484409252280216, 121.54014594679285, 177.38775160726939)
    constraintReference6.HelpPoint = helpPoint6
    
    constraintReference6.SetFixHint(True)
    
    objects5 = [NXOpen.TaggedObject.Null] * 1 
    objects5[0] = line6
    nErrs13 = theSession.UpdateManager.AddObjectsToDeleteList(objects5)
    
    objects6 = [NXOpen.TaggedObject.Null] * 1 
    objects6[0] = line5
    nErrs14 = theSession.UpdateManager.AddObjectsToDeleteList(objects6)
    
    componentNetwork4.Solve()
    
    face7 = component2.FindObject("PROTO#.Features|EXTRUDE(12)|FACE 140 {(63,62.95,57.5000000000018) EXTRUDE(2)}")
    line7 = workPart.Lines.CreateFaceAxis(face7, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line8 = workPart.Lines.CreateFaceAxis(face6, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Reverse Last Constraint")
    
    componentConstraint3.FlipAlignment()
    
    objects7 = [NXOpen.TaggedObject.Null] * 1 
    objects7[0] = line8
    nErrs15 = theSession.UpdateManager.AddObjectsToDeleteList(objects7)
    
    objects8 = [NXOpen.TaggedObject.Null] * 1 
    objects8[0] = line7
    nErrs16 = theSession.UpdateManager.AddObjectsToDeleteList(objects8)
    
    componentNetwork4.Solve()
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Reverse Last Constraint")
    
    componentConstraint3.FlipAlignment()
    
    componentNetwork4.Solve()
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled1, undoUnavailable1 = theSession.UndoLastNVisibleMarks(1)
    
    scaleAboutPoint132 = NXOpen.Point3d(-8.6528576025253319, -0.80885408023629513, 0.0)
    viewCenter132 = NXOpen.Point3d(8.6528576025248203, 0.80885408023578509, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint132, viewCenter132)
    
    scaleAboutPoint133 = NXOpen.Point3d(-10.816072003156602, -1.0110676002953047, 0.0)
    viewCenter133 = NXOpen.Point3d(10.816072003156089, 1.0110676002947916, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint133, viewCenter133)
    
    scaleAboutPoint134 = NXOpen.Point3d(-13.520090003945684, -1.2638345003690661, 0.0)
    viewCenter134 = NXOpen.Point3d(13.520090003945183, 1.2638345003685547, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint134, viewCenter134)
    
    scaleAboutPoint135 = NXOpen.Point3d(-16.900112504932039, -1.5797931254612767, 0.0)
    viewCenter135 = NXOpen.Point3d(16.900112504931556, 1.5797931254607505, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint135, viewCenter135)
    
    scaleAboutPoint136 = NXOpen.Point3d(-19.655565630736138, -2.5258320319873357, 0.0)
    viewCenter136 = NXOpen.Point3d(19.655565630735637, 2.5258320319868348, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint136, viewCenter136)
    
    scaleAboutPoint137 = NXOpen.Point3d(-24.569457038420097, -3.1572900399841015, 0.0)
    viewCenter137 = NXOpen.Point3d(24.569457038419625, 3.1572900399836024, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint137, viewCenter137)
    
    scaleAboutPoint138 = NXOpen.Point3d(-30.568308114389435, -4.0901257336157117, 0.0)
    viewCenter138 = NXOpen.Point3d(30.568308114388945, 4.0901257336151984, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint138, viewCenter138)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled2, undoUnavailable2 = theSession.UndoLastNVisibleMarks(1)
    
    objects9 = [NXOpen.TaggedObject.Null] * 1 
    objects9[0] = line8
    nErrs17 = theSession.UpdateManager.AddObjectsToDeleteList(objects9)
    
    objects10 = [NXOpen.TaggedObject.Null] * 1 
    objects10[0] = line7
    nErrs18 = theSession.UpdateManager.AddObjectsToDeleteList(objects10)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled3, undoUnavailable3 = theSession.UndoLastNVisibleMarks(1)
    
    objects11 = [NXOpen.TaggedObject.Null] * 1 
    objects11[0] = line6
    nErrs19 = theSession.UpdateManager.AddObjectsToDeleteList(objects11)
    
    objects12 = [NXOpen.TaggedObject.Null] * 1 
    objects12[0] = line5
    nErrs20 = theSession.UpdateManager.AddObjectsToDeleteList(objects12)
    
    line9 = workPart.Lines.CreateFaceAxis(face6, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    scaleAboutPoint139 = NXOpen.Point3d(-40.183691417976661, -2.7805679329405866, 0.0)
    viewCenter139 = NXOpen.Point3d(40.183691417976171, 2.7805679329400665, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint139, viewCenter139)
    
    scaleAboutPoint140 = NXOpen.Point3d(-32.14695313438137, -2.511480713623774, 0.0)
    viewCenter140 = NXOpen.Point3d(32.146953134380887, 2.5114807136232598, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint140, viewCenter140)
    
    scaleAboutPoint141 = NXOpen.Point3d(-25.602751960596631, -2.35361621162459, 0.0)
    viewCenter141 = NXOpen.Point3d(25.602751960596162, 2.3536162116240615, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint141, viewCenter141)
    
    scaleAboutPoint142 = NXOpen.Point3d(-20.390353130950544, -1.9747414068265323, 0.0)
    viewCenter142 = NXOpen.Point3d(20.390353130950107, 1.9747414068260076, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint142, viewCenter142)
    
    scaleAboutPoint143 = NXOpen.Point3d(-16.238803754739028, -1.6532718754827211, 0.0)
    viewCenter143 = NXOpen.Point3d(16.238803754738594, 1.6532718754821949, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint143, viewCenter143)
    
    scaleAboutPoint144 = NXOpen.Point3d(-12.991043003791269, -1.3226175003862217, 0.0)
    viewCenter144 = NXOpen.Point3d(12.991043003790837, 1.3226175003857106, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint144, viewCenter144)
    
    scaleAboutPoint145 = NXOpen.Point3d(-10.392834403033062, -1.0580940003090293, 0.0)
    viewCenter145 = NXOpen.Point3d(10.392834403032609, 1.0580940003085162, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint145, viewCenter145)
    
    scaleAboutPoint146 = NXOpen.Point3d(-8.3142675224265066, -0.84647520024727474, 0.0)
    viewCenter146 = NXOpen.Point3d(8.3142675224260252, 0.8464752002467647, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint146, viewCenter146)
    
    scaleAboutPoint147 = NXOpen.Point3d(-6.651414017941268, -0.67718016019787064, 0.0)
    viewCenter147 = NXOpen.Point3d(6.6514140179407546, 0.67718016019735749, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint147, viewCenter147)
    
    scaleAboutPoint148 = NXOpen.Point3d(-5.4174412815811683, -0.46951157773726704, 0.0)
    viewCenter148 = NXOpen.Point3d(5.4174412815806567, 0.46951157773675589, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint148, viewCenter148)
    
    scaleAboutPoint149 = NXOpen.Point3d(-4.3339530252649867, -0.35634724874424462, 0.0)
    viewCenter149 = NXOpen.Point3d(4.3339530252644742, 0.35634724874373219, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint149, viewCenter149)
    
    scaleAboutPoint150 = NXOpen.Point3d(-3.4671624202120412, -0.28507779899544577, 0.0)
    viewCenter150 = NXOpen.Point3d(3.4671624202115301, 0.28507779899493468, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint150, viewCenter150)
    
    objects13 = [NXOpen.TaggedObject.Null] * 1 
    objects13[0] = line9
    nErrs21 = theSession.UpdateManager.AddObjectsToDeleteList(objects13)
    
    scaleAboutPoint151 = NXOpen.Point3d(-2.4778654096449477, -0.89375742387707158, 0.0)
    viewCenter151 = NXOpen.Point3d(2.4778654096444348, 0.89375742387655976, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint151, viewCenter151)
    
    scaleAboutPoint152 = NXOpen.Point3d(-3.0665125405431302, -1.2712928874112448, 0.0)
    viewCenter152 = NXOpen.Point3d(3.0665125405426181, 1.2712928874107337, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint152, viewCenter152)
    
    scaleAboutPoint153 = NXOpen.Point3d(-3.7175685950051212, -1.993618391622036, 0.0)
    viewCenter153 = NXOpen.Point3d(3.7175685950046091, 1.9936183916215251, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint153, viewCenter153)
    
    scaleAboutPoint154 = NXOpen.Point3d(-4.5988057101422832, -2.7087206407907174, 0.0)
    viewCenter154 = NXOpen.Point3d(4.5988057101417716, 2.708720640790204, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint154, viewCenter154)
    
    scaleAboutPoint155 = NXOpen.Point3d(-5.7184102416690088, -3.5664821770410304, 0.0)
    viewCenter155 = NXOpen.Point3d(5.7184102416684954, 3.5664821770405175, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint155, viewCenter155)
    
    scaleAboutPoint156 = NXOpen.Point3d(-7.0727705620642416, -4.6838294413670969, 0.0)
    viewCenter156 = NXOpen.Point3d(7.0727705620637282, 4.6838294413665862, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint156, viewCenter156)
    
    scaleAboutPoint157 = NXOpen.Point3d(-3.9972440011667372, -13.002799603794744, 0.0)
    viewCenter157 = NXOpen.Point3d(3.9972440011662242, 13.00279960379423, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint157, viewCenter157)
    
    scaleAboutPoint158 = NXOpen.Point3d(-4.6438570013554266, -17.4879425051036, 0.0)
    viewCenter158 = NXOpen.Point3d(4.643857001354915, 17.487942505103089, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint158, viewCenter158)
    
    scaleAboutPoint159 = NXOpen.Point3d(-5.4374275015870213, -23.329503131808277, 0.0)
    viewCenter159 = NXOpen.Point3d(5.437427501586507, 23.329503131807776, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint159, viewCenter159)
    
    scaleAboutPoint160 = NXOpen.Point3d(-6.429390626876482, -29.988514852501513, 0.0)
    viewCenter160 = NXOpen.Point3d(6.429390626875958, 29.988514852501005, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint160, viewCenter160)
    
    scaleAboutPoint161 = NXOpen.Point3d(-7.6923066428700508, -38.863370128528878, 0.0)
    viewCenter161 = NXOpen.Point3d(7.6923066428695224, 38.863370128528373, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint161, viewCenter161)
    
    scaleAboutPoint162 = NXOpen.Point3d(-9.4718701199518573, -51.449476333373639, 0.0)
    viewCenter162 = NXOpen.Point3d(9.4718701199513173, 51.449476333373148, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint162, viewCenter162)
    
    scaleAboutPoint163 = NXOpen.Point3d(-12.019229129484302, -68.796632405330413, 0.0)
    viewCenter163 = NXOpen.Point3d(12.019229129483813, 68.796632405329916, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint163, viewCenter163)
    
    scaleAboutPoint164 = NXOpen.Point3d(-15.024036411855267, -85.995790506662985, 0.0)
    viewCenter164 = NXOpen.Point3d(15.024036411854789, 85.995790506662487, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint164, viewCenter164)
    
    scaleAboutPoint165 = NXOpen.Point3d(-18.780045514819037, -107.49473813332867, 0.0)
    viewCenter165 = NXOpen.Point3d(18.780045514818557, 107.49473813332816, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint165, viewCenter165)
    
    scaleAboutPoint166 = NXOpen.Point3d(-23.825430877009168, -134.36842266666079, 0.0)
    viewCenter166 = NXOpen.Point3d(23.825430877008692, 134.36842266666025, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint166, viewCenter166)
    
    scaleAboutPoint167 = NXOpen.Point3d(-30.21975607561814, -167.96052833332598, 0.0)
    viewCenter167 = NXOpen.Point3d(30.219756075617692, 167.96052833332539, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint167, viewCenter167)
    
    scaleAboutPoint168 = NXOpen.Point3d(-38.322154443718659, -209.95066041665734, 0.0)
    viewCenter168 = NXOpen.Point3d(38.322154443718098, 209.95066041665675, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint168, viewCenter168)
    
    scaleAboutPoint169 = NXOpen.Point3d(-33.531885138253827, -237.80265480700263, 0.0)
    viewCenter169 = NXOpen.Point3d(33.531885138253358, 237.80265480700206, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint169, viewCenter169)
    
    scaleAboutPoint170 = NXOpen.Point3d(-21.898373967839362, -208.85574171826531, 0.0)
    viewCenter170 = NXOpen.Point3d(21.898373967838801, 208.85574171826474, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint170, viewCenter170)
    
    scaleAboutPoint171 = NXOpen.Point3d(-16.204796736201146, -175.84394296174796, 0.0)
    viewCenter171 = NXOpen.Point3d(16.204796736200699, 175.84394296174744, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint171, viewCenter171)
    
    scaleAboutPoint172 = NXOpen.Point3d(-55.35908939069742, 31.708845505430705, 0.0)
    viewCenter172 = NXOpen.Point3d(55.359089390696944, -31.708845505431213, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint172, viewCenter172)
    
    scaleAboutPoint173 = NXOpen.Point3d(-43.166074765404559, 30.692760953323017, 0.0)
    viewCenter173 = NXOpen.Point3d(43.166074765404183, -30.692760953323472, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint173, viewCenter173)
    
    scaleAboutPoint174 = NXOpen.Point3d(-33.411663065170373, 28.590517052410455, 0.0)
    viewCenter174 = NXOpen.Point3d(33.411663065169918, -28.590517052410913, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint174, viewCenter174)
    
    scaleAboutPoint175 = NXOpen.Point3d(-41.764578831462963, 35.738146315513134, 0.0)
    viewCenter175 = NXOpen.Point3d(41.764578831462437, -35.738146315513589, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint175, viewCenter175)
    
    scaleAboutPoint176 = NXOpen.Point3d(-52.205723539328645, 44.67268289439145, 0.0)
    viewCenter176 = NXOpen.Point3d(52.205723539328048, -44.672682894391926, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint176, viewCenter176)
    
    scaleAboutPoint177 = NXOpen.Point3d(-65.257154424160731, 55.840853617989389, 0.0)
    viewCenter177 = NXOpen.Point3d(65.257154424160134, -55.840853617989843, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint177, viewCenter177)
    
    scaleAboutPoint178 = NXOpen.Point3d(-81.571443030200811, 70.348526371682766, 0.0)
    viewCenter178 = NXOpen.Point3d(81.571443030200243, -70.348526371683235, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint178, viewCenter178)
    
    scaleAboutPoint179 = NXOpen.Point3d(-101.96430378775091, 89.304306337593445, 0.0)
    viewCenter179 = NXOpen.Point3d(101.96430378775038, -89.304306337593914, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint179, viewCenter179)
    
    scaleAboutPoint180 = NXOpen.Point3d(-123.17835356909502, 155.25604981104627, 0.0)
    viewCenter180 = NXOpen.Point3d(123.17835356909437, -155.25604981104669, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint180, viewCenter180)
    
    scaleAboutPoint181 = NXOpen.Point3d(-97.174034482286217, 127.62646078131176, 0.0)
    viewCenter181 = NXOpen.Point3d(97.174034482285506, -127.62646078131229, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint181, viewCenter181)
    
    scaleAboutPoint182 = NXOpen.Point3d(-46.534044681658308, -128.92667673565273, 0.0)
    viewCenter182 = NXOpen.Point3d(46.534044681657747, 128.92667673565222, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint182, viewCenter182)
    
    scaleAboutPoint183 = NXOpen.Point3d(-58.167555852072766, -167.31726359802065, 0.0)
    viewCenter183 = NXOpen.Point3d(58.167555852072297, 167.31726359802005, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint183, viewCenter183)
    
    scaleAboutPoint184 = NXOpen.Point3d(-78.697281446921835, -275.01278244766661, 0.0)
    viewCenter184 = NXOpen.Point3d(78.697281446921465, 275.01278244766604, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint184, viewCenter184)
    
    scaleAboutPoint185 = NXOpen.Point3d(-62.957825157537577, -222.74752270411327, 0.0)
    viewCenter185 = NXOpen.Point3d(62.957825157537116, 222.74752270411267, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint185, viewCenter185)
    
    scaleAboutPoint186 = NXOpen.Point3d(-49.271341427638177, -180.93531490927055, 0.0)
    viewCenter186 = NXOpen.Point3d(49.271341427637616, 180.93531490926998, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint186, viewCenter186)
    
    scaleAboutPoint187 = NXOpen.Point3d(-38.979105662753781, -146.93808932420038, 0.0)
    viewCenter187 = NXOpen.Point3d(38.979105662753334, 146.93808932419981, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint187, viewCenter187)
    
    scaleAboutPoint188 = NXOpen.Point3d(-30.482536563232213, -118.25121942633123, 0.0)
    viewCenter188 = NXOpen.Point3d(30.482536563231736, 118.25121942633066, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint188, viewCenter188)
    
    scaleAboutPoint189 = NXOpen.Point3d(-24.105730063797498, -95.161573914641735, 0.0)
    viewCenter189 = NXOpen.Point3d(24.105730063796994, 95.161573914641139, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint189, viewCenter189)
    
    scaleAboutPoint190 = NXOpen.Point3d(-25.114807136235502, -44.511510861988697, 0.0)
    viewCenter190 = NXOpen.Point3d(25.114807136235004, 44.511510861988086, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint190, viewCenter190)
    
    scaleAboutPoint191 = NXOpen.Point3d(-20.091845708988465, -34.353468332779251, 0.0)
    viewCenter191 = NXOpen.Point3d(20.091845708988007, 34.35346833277864, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint191, viewCenter191)
    
    scaleAboutPoint192 = NXOpen.Point3d(-15.929963383555162, -27.052235115316574, 0.0)
    viewCenter192 = NXOpen.Point3d(15.929963383554711, 27.052235115315963, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint192, viewCenter192)
    
    line10 = workPart.Lines.CreateFaceAxis(face7, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint4 = componentPositioner4.CreateConstraint(True)
    
    componentConstraint4 = constraint4
    componentConstraint4.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    edge7 = component4.FindObject("PROTO#.Features|EXTRUDE(14)|EDGE * 170 EXTRUDE(12) 270 {(61.2990381056767,57.04,-6.75)(60,57.04,-4.5)(58.7009618943233,57.04,-6.75) EXTRUDE(2)}")
    constraintReference7 = componentConstraint4.CreateConstraintReference(component4, edge7, False, False, False)
    
    helpPoint7 = NXOpen.Point3d(16.666029701107959, 123.54014627461838, 178.28079449576177)
    constraintReference7.HelpPoint = helpPoint7
    
    constraintReference8 = componentConstraint4.CreateConstraintReference(component2, edge5, False, False, False)
    
    helpPoint8 = NXOpen.Point3d(72.32270603831175, 89.485758144312342, 84.337806061387695)
    constraintReference8.HelpPoint = helpPoint8
    
    constraintReference8.SetFixHint(True)
    
    objects14 = [NXOpen.TaggedObject.Null] * 1 
    objects14[0] = line10
    nErrs22 = theSession.UpdateManager.AddObjectsToDeleteList(objects14)
    
    componentNetwork4.Solve()
    
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    theSession.DeleteUndoMark(markId30, None)
    
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs23 = theSession.UpdateManager.DoUpdate(markId25)
    
    componentNetwork4.Solve()
    
    componentPositioner4.ClearNetwork()
    
    nErrs24 = theSession.UpdateManager.AddToDeleteList(componentNetwork4)
    
    componentPositioner4.DeleteNonPersistentConstraints()
    
    nErrs25 = theSession.UpdateManager.DoUpdate(markId25)
    
    theSession.DeleteUndoMark(markId31, None)
    
    theSession.SetUndoMarkName(markId24, "Assembly Constraints")
    
    componentPositioner4.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner4.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId25, None)
    
    theSession.DeleteUndoMark(markId29, None)
    
    theSession.DeleteUndoMark(markId23, None)
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    scaleAboutPoint193 = NXOpen.Point3d(3.2146953134378728, -17.049366215913178, 0.0)
    viewCenter193 = NXOpen.Point3d(-3.2146953134383427, 17.049366215912542, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint193, viewCenter193)
    
    rotMatrix3 = NXOpen.Matrix3x3()
    
    rotMatrix3.Xx = 0.64144528439250603
    rotMatrix3.Xy = 0.76671218235204841
    rotMatrix3.Xz = -0.026464628536520297
    rotMatrix3.Yx = -0.2091124227056895
    rotMatrix3.Yy = 0.20792929234530075
    rotMatrix3.Yz = 0.95552990746231437
    rotMatrix3.Zx = 0.73811919213686195
    rotMatrix3.Zy = -0.60738607064843131
    rotMatrix3.Zz = 0.29370430603156716
    translation3 = NXOpen.Point3d(-127.79008665900838, -105.05567246890644, 16.072668249891542)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix3, translation3, 2.8806514346651007)
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    scaleAboutPoint194 = NXOpen.Point3d(2.663604688277033, -19.058550786811981, 0.0)
    viewCenter194 = NXOpen.Point3d(-2.6636046882775029, 19.058550786811356, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint194, viewCenter194)
    
    scaleAboutPoint195 = NXOpen.Point3d(3.214695313437872, -24.052809577331903, 0.0)
    viewCenter195 = NXOpen.Point3d(-3.2146953134383418, 24.052809577331278, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint195, viewCenter195)
    
    scaleAboutPoint196 = NXOpen.Point3d(3.8748559581617923, -30.496551522571679, 0.0)
    viewCenter196 = NXOpen.Point3d(-3.8748559581622448, 30.496551522571082, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint196, viewCenter196)
    
    scaleAboutPoint197 = NXOpen.Point3d(14.530709843107328, -64.491236896261555, 0.0)
    viewCenter197 = NXOpen.Point3d(-14.530709843107772, 64.491236896260958, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint197, viewCenter197)
    
    scaleAboutPoint198 = NXOpen.Point3d(19.957302099329588, -83.977636361786935, 0.0)
    viewCenter198 = NXOpen.Point3d(-19.957302099330008, 83.977636361786324, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint198, viewCenter198)
    
    scaleAboutPoint199 = NXOpen.Point3d(27.189021118468766, -106.37354138617529, 0.0)
    viewCenter199 = NXOpen.Point3d(-27.189021118469174, 106.37354138617469, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint199, viewCenter199)
    
    scaleAboutPoint200 = NXOpen.Point3d(-50.103479638416026, 32.409593472401546, 0.0)
    viewCenter200 = NXOpen.Point3d(50.103479638415543, -32.409593472402143, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint200, viewCenter200)
    
    scaleAboutPoint201 = NXOpen.Point3d(-63.06731702737671, 42.263861757929128, 0.0)
    viewCenter201 = NXOpen.Point3d(63.067317027376262, -42.263861757929647, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint201, viewCenter201)
    
    scaleAboutPoint202 = NXOpen.Point3d(-78.834146284220793, 52.829827197411454, 0.0)
    viewCenter202 = NXOpen.Point3d(78.834146284220367, -52.829827197411966, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint202, viewCenter202)
    
    scaleAboutPoint203 = NXOpen.Point3d(-96.48971029579107, 61.24701469129964, 0.0)
    viewCenter203 = NXOpen.Point3d(96.489710295790601, -61.247014691300109, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint203, viewCenter203)
    
    scaleAboutPoint204 = NXOpen.Point3d(-36.782425024104974, -72.281742198531518, 0.0)
    viewCenter204 = NXOpen.Point3d(36.782425024104391, 72.281742198531006, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint204, viewCenter204)
    
    scaleAboutPoint205 = NXOpen.Point3d(-29.425940019283981, -74.933498421199559, 0.0)
    viewCenter205 = NXOpen.Point3d(29.425940019283516, 74.933498421198976, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint205, viewCenter205)
    
    scaleAboutPoint206 = NXOpen.Point3d(-22.993292666231287, -61.041717435351629, 0.0)
    viewCenter206 = NXOpen.Point3d(22.993292666230818, 61.041717435351067, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint206, viewCenter206)
    
    scaleAboutPoint207 = NXOpen.Point3d(-17.956666653628272, -49.709308906994927, 0.0)
    viewCenter207 = NXOpen.Point3d(17.956666653627749, 49.70930890699433, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint207, viewCenter207)
    
    scaleAboutPoint208 = NXOpen.Point3d(-14.014959339417302, -39.767447125596, 0.0)
    viewCenter208 = NXOpen.Point3d(14.014959339416706, 39.767447125595375, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint208, viewCenter208)
    
    scaleAboutPoint209 = NXOpen.Point3d(-11.211967471533892, -31.81395770047688, 0.0)
    viewCenter209 = NXOpen.Point3d(11.211967471533296, 31.813957700476259, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint209, viewCenter209)
    
    scaleAboutPoint210 = NXOpen.Point3d(-8.9695739772271139, -25.002687461520221, 0.0)
    viewCenter210 = NXOpen.Point3d(8.969573977226597, 25.00268746151961, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint210, viewCenter210)
    
    rotMatrix4 = NXOpen.Matrix3x3()
    
    rotMatrix4.Xx = 0.63263107055464562
    rotMatrix4.Xy = 0.7739239491910811
    rotMatrix4.Xz = -0.028629520383049847
    rotMatrix4.Yx = 0.0073753155586270677
    rotMatrix4.Yy = 0.030945129013556394
    rotMatrix4.Yz = 0.99949387377349341
    rotMatrix4.Zx = 0.77441819018492375
    rotMatrix4.Zy = -0.63252203112525218
    rotMatrix4.Zz = 0.013868916752634665
    translation4 = NXOpen.Point3d(-154.06354848888398, -61.600044529855197, 37.128045475305612)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix4, translation4, 1.4748935345485323)
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    scaleAboutPoint211 = NXOpen.Point3d(97.409573392683555, 62.159147662181937, 0.0)
    viewCenter211 = NXOpen.Point3d(-97.409573392684138, -62.159147662182562, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint211, viewCenter211)
    
    scaleAboutPoint212 = NXOpen.Point3d(77.927658714146801, 49.727318129745463, 0.0)
    viewCenter212 = NXOpen.Point3d(-77.927658714147384, -49.727318129746124, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint212, viewCenter212)
    
    scaleAboutPoint213 = NXOpen.Point3d(62.342126971317363, 39.78185450379631, 0.0)
    viewCenter213 = NXOpen.Point3d(-62.342126971317953, -39.781854503796936, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint213, viewCenter213)
    
    scaleAboutPoint214 = NXOpen.Point3d(50.14924688963432, 29.161878914759711, 0.0)
    viewCenter214 = NXOpen.Point3d(-50.149246889634789, -29.161878914760337, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint214, viewCenter214)
    
    scaleAboutPoint215 = NXOpen.Point3d(40.486791261814631, 22.300800631507531, 0.0)
    viewCenter215 = NXOpen.Point3d(-40.486791261815085, -22.300800631508128, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint215, viewCenter215)
    
    scaleAboutPoint216 = NXOpen.Point3d(32.565782009503138, 17.781857505188832, 0.0)
    viewCenter216 = NXOpen.Point3d(-32.565782009503586, -17.781857505189397, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint216, viewCenter216)
    
    scaleAboutPoint217 = NXOpen.Point3d(26.287757607671079, 14.131433204123558, 0.0)
    viewCenter217 = NXOpen.Point3d(-26.28775760767153, -14.131433204124127, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint217, viewCenter217)
    
    scaleAboutPoint218 = NXOpen.Point3d(21.669765126323426, 11.493252163353693, 0.0)
    viewCenter218 = NXOpen.Point3d(-21.669765126323917, -11.493252163354231, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint218, viewCenter218)
    
    scaleAboutPoint219 = NXOpen.Point3d(17.365908997067521, 9.1946017306829138, 0.0)
    viewCenter219 = NXOpen.Point3d(-17.365908997067944, -9.1946017306834396, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint219, viewCenter219)
    
    scaleAboutPoint220 = NXOpen.Point3d(14.061269815303154, 7.3556813845462781, 0.0)
    viewCenter220 = NXOpen.Point3d(-14.06126981530358, -7.3556813845468039, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint220, viewCenter220)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner5 = workPart.ComponentAssembly.Positioner
    
    componentPositioner5.ClearNetwork()
    
    componentPositioner5.PrimaryArrangement = arrangement1
    
    componentPositioner5.BeginAssemblyConstraints()
    
    allowInterpartPositioning4 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression25 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression26 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression27 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit1)
    
    expression28 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit2)
    
    expression29 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression30 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression31 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression32 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    network5 = componentPositioner5.EstablishNetwork()
    
    componentNetwork5 = network5
    componentNetwork5.MoveObjectsState = True
    
    componentNetwork5.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork5.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId33, "Assembly Constraints Dialog")
    
    componentNetwork5.MoveObjectsState = True
    
    componentNetwork5.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    component5 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT y_link 1")
    face8 = component5.FindObject("PROTO#.Features|EXTRUDE(6)|FACE 140 1 {(5.3,3,1.5000000000248) EXTRUDE(2)}")
    line11 = workPart.Lines.CreateFaceAxis(face8, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    objects15 = [NXOpen.TaggedObject.Null] * 1 
    objects15[0] = line11
    nErrs26 = theSession.UpdateManager.AddObjectsToDeleteList(objects15)
    
    scaleAboutPoint221 = NXOpen.Point3d(-5.4511498051109504, -3.3419593328155126, 0.0)
    viewCenter221 = NXOpen.Point3d(5.4511498051105827, 3.3419593328150001, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint221, viewCenter221)
    
    scaleAboutPoint222 = NXOpen.Point3d(-6.8380147731956784, -4.3700693004755351, 0.0)
    viewCenter222 = NXOpen.Point3d(6.8380147731952823, 4.3700693004750235, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint222, viewCenter222)
    
    scaleAboutPoint223 = NXOpen.Point3d(-8.6980029465384696, -5.8237493776997482, 0.0)
    viewCenter223 = NXOpen.Point3d(8.6980029465380468, 5.8237493776992375, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint223, viewCenter223)
    
    scaleAboutPoint224 = NXOpen.Point3d(-10.985367043205995, -7.4301712021685242, 0.0)
    viewCenter224 = NXOpen.Point3d(10.985367043205507, 7.4301712021680144, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint224, viewCenter224)
    
    scaleAboutPoint225 = NXOpen.Point3d(-14.296025604172131, -9.710951602834097, 0.0)
    viewCenter225 = NXOpen.Point3d(14.296025604171586, 9.7109516028335836, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint225, viewCenter225)
    
    scaleAboutPoint226 = NXOpen.Point3d(2.5276690007373603, 18.016989505257456, 0.0)
    viewCenter226 = NXOpen.Point3d(-2.5276690007378715, -18.016989505257982, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint226, viewCenter226)
    
    scaleAboutPoint227 = NXOpen.Point3d(3.1595862509218016, 22.300800631507581, 0.0)
    viewCenter227 = NXOpen.Point3d(-3.1595862509222528, -22.300800631508078, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint227, viewCenter227)
    
    scaleAboutPoint228 = NXOpen.Point3d(3.857634376125501, 27.23306172669691, 0.0)
    viewCenter228 = NXOpen.Point3d(-3.8576343761259708, -27.233061726697411, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint228, viewCenter228)
    
    scaleAboutPoint229 = NXOpen.Point3d(-20.206656255896952, 9.4718701199513298, 0.0)
    viewCenter229 = NXOpen.Point3d(20.206656255896483, -9.4718701199518378, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint229, viewCenter229)
    
    scaleAboutPoint230 = NXOpen.Point3d(-31.859926767110114, 10.117679446311648, 0.0)
    viewCenter230 = NXOpen.Point3d(31.859926767109648, -10.117679446312199, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint230, viewCenter230)
    
    scaleAboutPoint231 = NXOpen.Point3d(-43.053955090689271, 11.391358951077859, 0.0)
    viewCenter231 = NXOpen.Point3d(43.053955090688753, -11.391358951078393, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint231, viewCenter231)
    
    scaleAboutPoint232 = NXOpen.Point3d(-76.241378806428713, -12.893762592263894, 0.0)
    viewCenter232 = NXOpen.Point3d(76.241378806428173, 12.893762592263359, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint232, viewCenter232)
    
    scaleAboutPoint233 = NXOpen.Point3d(-146.31617550351362, -29.010965832593413, 0.0)
    viewCenter233 = NXOpen.Point3d(146.31617550351316, 29.010965832592909, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint233, viewCenter233)
    
    scaleAboutPoint234 = NXOpen.Point3d(-250.86777217556437, -69.19886173837159, 0.0)
    viewCenter234 = NXOpen.Point3d(250.86777217556377, 69.198861738371093, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint234, viewCenter234)
    
    scaleAboutPoint235 = NXOpen.Point3d(-201.25481611402824, -52.275798336025595, 0.0)
    viewCenter235 = NXOpen.Point3d(201.25481611402768, 52.275798336025098, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint235, viewCenter235)
    
    scaleAboutPoint236 = NXOpen.Point3d(40.587322246951281, -78.820131324881388, 0.0)
    viewCenter236 = NXOpen.Point3d(-40.587322246951892, 78.820131324880862, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint236, viewCenter236)
    
    scaleAboutPoint237 = NXOpen.Point3d(61.665821093434381, -99.366061716466675, 0.0)
    viewCenter237 = NXOpen.Point3d(-61.665821093434957, 99.366061716466149, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint237, viewCenter237)
    
    scaleAboutPoint238 = NXOpen.Point3d(-144.7044551794807, -95.126536516293058, 0.0)
    viewCenter238 = NXOpen.Point3d(144.70445517948008, 95.126536516292518, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint238, viewCenter238)
    
    scaleAboutPoint239 = NXOpen.Point3d(-114.64236739643124, -75.820930026246174, 0.0)
    viewCenter239 = NXOpen.Point3d(114.64236739643067, 75.820930026245648, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint239, viewCenter239)
    
    scaleAboutPoint240 = NXOpen.Point3d(-90.816936519422384, -60.208265322135645, 0.0)
    viewCenter240 = NXOpen.Point3d(90.816936519421773, 60.208265322135112, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint240, viewCenter240)
    
    scaleAboutPoint241 = NXOpen.Point3d(-71.218417379181616, -46.731480421352273, 0.0)
    viewCenter241 = NXOpen.Point3d(71.218417379181119, 46.731480421351733, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint241, viewCenter241)
    
    scaleAboutPoint242 = NXOpen.Point3d(-51.234206557920153, -16.288746342644266, 0.0)
    viewCenter242 = NXOpen.Point3d(51.234206557919663, 16.288746342643726, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint242, viewCenter242)
    
    scaleAboutPoint243 = NXOpen.Point3d(-41.561417980878694, -12.916186527206966, 0.0)
    viewCenter243 = NXOpen.Point3d(41.561417980878204, 12.916186527206436, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint243, viewCenter243)
    
    scaleAboutPoint244 = NXOpen.Point3d(-33.892073447390636, -10.332949221765629, 0.0)
    viewCenter244 = NXOpen.Point3d(33.892073447390104, 10.332949221765089, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint244, viewCenter244)
    
    face9 = component1.FindObject("PROTO#.Features|EXTRUDE(4)|FACE 160 {(4.5,12,1.4) EXTRUDE(2)}")
    line12 = workPart.Lines.CreateFaceAxis(face9, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint5 = componentPositioner5.CreateConstraint(True)
    
    componentConstraint5 = constraint5
    componentConstraint5.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    edge8 = component5.FindObject("PROTO#.Features|EXTRUDE(4)|EDGE * 160 EXTRUDE(6) 140 {(4.8,1.7009618943448,2.2500000000124)(4.8,3,4.4999999999752)(4.8,4.2990381056552,2.2500000000124) EXTRUDE(2)}")
    constraintReference9 = componentConstraint5.CreateConstraintReference(component5, edge8, False, False, False)
    
    helpPoint9 = NXOpen.Point3d(128.89798491966852, 227.32631889373806, 112.82813984494639)
    constraintReference9.HelpPoint = helpPoint9
    
    edge9 = component1.FindObject("PROTO#.Features|EXTRUDE(4)|EDGE * 160 EXTRUDE(2) 130 {(2.25,13.2990381056767,2.8)(4.5,12,2.8)(2.25,10.7009618943233,2.8) EXTRUDE(2)}")
    constraintReference10 = componentConstraint5.CreateConstraintReference(component1, edge9, False, False, False)
    
    helpPoint10 = NXOpen.Point3d(74.40187208260663, 34.519524773788241, 51.40542850951438)
    constraintReference10.HelpPoint = helpPoint10
    
    constraintReference10.SetFixHint(True)
    
    objects16 = [NXOpen.TaggedObject.Null] * 1 
    objects16[0] = line12
    nErrs27 = theSession.UpdateManager.AddObjectsToDeleteList(objects16)
    
    componentNetwork5.Solve()
    
    line13 = workPart.Lines.CreateFaceAxis(face8, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    objects17 = [NXOpen.TaggedObject.Null] * 1 
    objects17[0] = line13
    nErrs28 = theSession.UpdateManager.AddObjectsToDeleteList(objects17)
    
    theSession.DeleteUndoMark(markId36, None)
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs29 = theSession.UpdateManager.DoUpdate(markId34)
    
    componentNetwork5.Solve()
    
    componentPositioner5.ClearNetwork()
    
    nErrs30 = theSession.UpdateManager.AddToDeleteList(componentNetwork5)
    
    componentPositioner5.DeleteNonPersistentConstraints()
    
    nErrs31 = theSession.UpdateManager.DoUpdate(markId34)
    
    theSession.DeleteUndoMark(markId37, None)
    
    theSession.SetUndoMarkName(markId33, "Assembly Constraints")
    
    componentPositioner5.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner5.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId34, None)
    
    theSession.DeleteUndoMark(markId35, None)
    
    theSession.DeleteUndoMark(markId32, None)
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner6 = workPart.ComponentAssembly.Positioner
    
    componentPositioner6.ClearNetwork()
    
    componentPositioner6.PrimaryArrangement = arrangement1
    
    componentPositioner6.BeginAssemblyConstraints()
    
    allowInterpartPositioning5 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression33 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression34 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression35 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit1)
    
    expression36 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit2)
    
    expression37 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression38 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression39 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression40 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    network6 = componentPositioner6.EstablishNetwork()
    
    componentNetwork6 = network6
    componentNetwork6.MoveObjectsState = True
    
    componentNetwork6.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork6.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId39, "Assembly Constraints Dialog")
    
    componentNetwork6.MoveObjectsState = True
    
    componentNetwork6.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    face10 = component5.FindObject("PROTO#.Features|EXTRUDE(10)|FACE 140 {(2.9,47,1.5000000000037) EXTRUDE(2)}")
    line14 = workPart.Lines.CreateFaceAxis(face10, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    objects18 = [NXOpen.TaggedObject.Null] * 1 
    objects18[0] = line14
    nErrs32 = theSession.UpdateManager.AddObjectsToDeleteList(objects18)
    
    face11 = component4.FindObject("PROTO#.Features|EXTRUDE(14)|FACE 160 {(7,56.04,-4.5) EXTRUDE(2)}")
    line15 = workPart.Lines.CreateFaceAxis(face11, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    face12 = component4.FindObject("PROTO#.Features|EXTRUDE(10)|FACE 140 1 {(64,7,-7.4999999999974) EXTRUDE(2)}")
    line16 = workPart.Lines.CreateFaceAxis(face12, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint6 = componentPositioner6.CreateConstraint(True)
    
    componentConstraint6 = constraint6
    componentConstraint6.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    edge10 = component5.FindObject("PROTO#.Features|EXTRUDE(10)|EDGE * 140 EXTRUDE(8) 160 {(4.3,45.7009618943266,2.2500000000019)(4.3,47,4.4999999999963)(4.3,48.2990381056734,2.2500000000019) EXTRUDE(2)}")
    constraintReference11 = componentConstraint6.CreateConstraintReference(component5, edge10, False, False, False)
    
    helpPoint11 = NXOpen.Point3d(73.901872328475719, 78.478973556719239, 51.739982165792647)
    constraintReference11.HelpPoint = helpPoint11
    
    edge11 = component4.FindObject("PROTO#.Features|EXTRUDE(8)|EDGE * 160 EXTRUDE(10) 140 {(63,5.7009618943256,-6.7499999999987)(63,7,-4.5000000000026)(63,8.2990381056744,-6.7499999999987) EXTRUDE(2)}")
    constraintReference12 = componentConstraint6.CreateConstraintReference(component4, edge11, False, False, False)
    
    helpPoint12 = NXOpen.Point3d(75.901873195723368, 40.881939205282187, 82.661676034808721)
    constraintReference12.HelpPoint = helpPoint12
    
    constraintReference12.SetFixHint(True)
    
    objects19 = [NXOpen.TaggedObject.Null] * 1 
    objects19[0] = line16
    nErrs33 = theSession.UpdateManager.AddObjectsToDeleteList(objects19)
    
    objects20 = [NXOpen.TaggedObject.Null] * 1 
    objects20[0] = line15
    nErrs34 = theSession.UpdateManager.AddObjectsToDeleteList(objects20)
    
    componentNetwork6.Solve()
    
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    theSession.DeleteUndoMark(markId42, None)
    
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs35 = theSession.UpdateManager.DoUpdate(markId40)
    
    componentNetwork6.Solve()
    
    componentPositioner6.ClearNetwork()
    
    nErrs36 = theSession.UpdateManager.AddToDeleteList(componentNetwork6)
    
    componentPositioner6.DeleteNonPersistentConstraints()
    
    nErrs37 = theSession.UpdateManager.DoUpdate(markId40)
    
    theSession.DeleteUndoMark(markId43, None)
    
    theSession.SetUndoMarkName(markId39, "Assembly Constraints")
    
    componentPositioner6.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner6.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId40, None)
    
    theSession.DeleteUndoMark(markId41, None)
    
    theSession.DeleteUndoMark(markId38, None)
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    scaleAboutPoint245 = NXOpen.Point3d(-17.855336255210787, 12.381169378612794, 0.0)
    viewCenter245 = NXOpen.Point3d(17.855336255210286, -12.38116937861334, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint245, viewCenter245)
    
    scaleAboutPoint246 = NXOpen.Point3d(-22.319170319013413, 15.476461723266073, 0.0)
    viewCenter246 = NXOpen.Point3d(22.319170319012933, -15.476461723266606, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint246, viewCenter246)
    
    scaleAboutPoint247 = NXOpen.Point3d(-7.2330644552360051, 15.901260746827527, 0.0)
    viewCenter247 = NXOpen.Point3d(7.2330644552354952, -15.901260746828067, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint247, viewCenter247)
    
    scaleAboutPoint248 = NXOpen.Point3d(-7.3191723654173737, 19.589549566263212, 0.0)
    viewCenter248 = NXOpen.Point3d(7.3191723654168843, -19.589549566263763, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint248, viewCenter248)
    
    scaleAboutPoint249 = NXOpen.Point3d(-7.8932250999599027, 24.128153998740018, 0.0)
    viewCenter249 = NXOpen.Point3d(7.8932250999593982, -24.128153998740554, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint249, viewCenter249)
    
    scaleAboutPoint250 = NXOpen.Point3d(-7.6241378806430795, 29.935953148994447, 0.0)
    viewCenter250 = NXOpen.Point3d(7.6241378806426017, -29.935953148994965, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint250, viewCenter250)
    
    scaleAboutPoint251 = NXOpen.Point3d(-0.84089756036530605, 39.382035743761456, 0.0)
    viewCenter251 = NXOpen.Point3d(0.84089756036478025, -39.38203574376201, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint251, viewCenter251)
    
    scaleAboutPoint252 = NXOpen.Point3d(1.7518699174268451, 49.928292646672759, 0.0)
    viewCenter252 = NXOpen.Point3d(-1.7518699174273829, -49.928292646673299, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint252, viewCenter252)
    
    scaleAboutPoint253 = NXOpen.Point3d(150.22284541937555, 91.754186925245321, 0.0)
    viewCenter253 = NXOpen.Point3d(-150.22284541937606, -91.754186925245875, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint253, viewCenter253)
    
    scaleAboutPoint254 = NXOpen.Point3d(119.82790235201503, 73.403349540196203, 0.0)
    viewCenter254 = NXOpen.Point3d(-119.82790235201551, -73.403349540196771, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint254, viewCenter254)
    
    scaleAboutPoint255 = NXOpen.Point3d(95.582022694823607, 59.002978818945252, 0.0)
    viewCenter255 = NXOpen.Point3d(-95.58202269482409, -59.002978818945799, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint255, viewCenter255)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner7 = workPart.ComponentAssembly.Positioner
    
    componentPositioner7.ClearNetwork()
    
    componentPositioner7.PrimaryArrangement = arrangement1
    
    componentPositioner7.BeginAssemblyConstraints()
    
    allowInterpartPositioning6 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression41 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression42 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression43 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit1)
    
    expression44 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit2)
    
    expression45 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression46 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression47 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression48 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    network7 = componentPositioner7.EstablishNetwork()
    
    componentNetwork7 = network7
    componentNetwork7.MoveObjectsState = True
    
    componentNetwork7.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork7.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId45, "Assembly Constraints Dialog")
    
    componentNetwork7.MoveObjectsState = True
    
    componentNetwork7.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    scaleAboutPoint256 = NXOpen.Point3d(94.629005459743283, 26.123884208673033, 0.0)
    viewCenter256 = NXOpen.Point3d(-94.629005459743738, -26.123884208673548, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint256, viewCenter256)
    
    scaleAboutPoint257 = NXOpen.Point3d(74.806246970071982, 21.078498846482891, 0.0)
    viewCenter257 = NXOpen.Point3d(-74.806246970072408, -21.078498846483441, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint257, viewCenter257)
    
    component6 = workPart.ComponentAssembly.RootComponent.FindObject("COMPONENT y_link1 1")
    face13 = component6.FindObject("PROTO#.Features|EXTRUDE(10)|FACE 140 {(2.9,47,1.5000000000037) EXTRUDE(2)}")
    line17 = workPart.Lines.CreateFaceAxis(face13, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    scaleAboutPoint258 = NXOpen.Point3d(59.988510759693099, 19.733062749898842, 0.0)
    viewCenter258 = NXOpen.Point3d(-59.988510759693568, -19.733062749899428, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint258, viewCenter258)
    
    scaleAboutPoint259 = NXOpen.Point3d(47.990808607754452, 15.786450199919026, 0.0)
    viewCenter259 = NXOpen.Point3d(-47.990808607754921, -15.786450199919594, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint259, viewCenter259)
    
    scaleAboutPoint260 = NXOpen.Point3d(38.392646886203515, 12.629160159935173, 0.0)
    viewCenter260 = NXOpen.Point3d(-38.392646886203984, -12.629160159935729, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint260, viewCenter260)
    
    objects21 = [NXOpen.TaggedObject.Null] * 1 
    objects21[0] = line17
    nErrs38 = theSession.UpdateManager.AddObjectsToDeleteList(objects21)
    
    scaleAboutPoint261 = NXOpen.Point3d(53.492530015609972, 0.62456937518197586, 0.0)
    viewCenter261 = NXOpen.Point3d(-53.49253001561042, -0.62456937518255229, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint261, viewCenter261)
    
    scaleAboutPoint262 = NXOpen.Point3d(66.957510957039318, 0.87256015650436181, 0.0)
    viewCenter262 = NXOpen.Point3d(-66.957510957039787, -0.87256015650491792, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint262, viewCenter262)
    
    scaleAboutPoint263 = NXOpen.Point3d(83.696888696299212, 1.0907001956305111, 0.0)
    viewCenter263 = NXOpen.Point3d(-83.696888696299681, -1.0907001956310789, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint263, viewCenter263)
    
    scaleAboutPoint264 = NXOpen.Point3d(104.62111087037405, 1.3633752445382121, 0.0)
    viewCenter264 = NXOpen.Point3d(-104.62111087037452, -1.363375244538775, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint264, viewCenter264)
    
    scaleAboutPoint265 = NXOpen.Point3d(130.77638858796769, 1.7042190556728265, 0.0)
    viewCenter265 = NXOpen.Point3d(-130.77638858796814, -1.7042190556734076, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint265, viewCenter265)
    
    scaleAboutPoint266 = NXOpen.Point3d(-74.671703360414, 13.342241291124678, 0.0)
    viewCenter266 = NXOpen.Point3d(74.671703360413545, -13.342241291125271, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint266, viewCenter266)
    
    scaleAboutPoint267 = NXOpen.Point3d(-58.840405290608558, 9.776835635177008, 0.0)
    viewCenter267 = NXOpen.Point3d(58.840405290608068, -9.7768356351775889, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint267, viewCenter267)
    
    scaleAboutPoint268 = NXOpen.Point3d(-46.354758314308746, 7.1039025899633836, 0.0)
    viewCenter268 = NXOpen.Point3d(46.354758314308285, -7.1039025899639956, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint268, viewCenter268)
    
    scaleAboutPoint269 = NXOpen.Point3d(-36.050511729270511, 4.9942587905196225, 0.0)
    viewCenter269 = NXOpen.Point3d(36.050511729270042, -4.9942587905202194, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint269, viewCenter269)
    
    scaleAboutPoint270 = NXOpen.Point3d(-24.247987507076306, 4.2709523449960605, 0.0)
    viewCenter270 = NXOpen.Point3d(24.247987507075802, -4.2709523449966484, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint270, viewCenter270)
    
    scaleAboutPoint271 = NXOpen.Point3d(1.910447500557261, 2.0206656255893716, 0.0)
    viewCenter271 = NXOpen.Point3d(-1.9104475005577433, -2.0206656255899729, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint271, viewCenter271)
    
    scaleAboutPoint272 = NXOpen.Point3d(2.3880593756966233, 2.5258320319868006, 0.0)
    viewCenter272 = NXOpen.Point3d(-2.3880593756970931, -2.5258320319873877, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint272, viewCenter272)
    
    scaleAboutPoint273 = NXOpen.Point3d(2.9850742196208571, 3.1572900399835593, 0.0)
    viewCenter273 = NXOpen.Point3d(-2.9850742196213269, -3.1572900399841664, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint273, viewCenter273)
    
    scaleAboutPoint274 = NXOpen.Point3d(3.7313427745260954, 3.9466125499795219, 0.0)
    viewCenter274 = NXOpen.Point3d(-3.7313427745265848, -3.9466125499801339, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint274, viewCenter274)
    
    scaleAboutPoint275 = NXOpen.Point3d(98.665313749495382, -9.776835635177612, 0.0)
    viewCenter275 = NXOpen.Point3d(-98.66531374949588, 9.776835635176985, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint275, viewCenter275)
    
    scaleAboutPoint276 = NXOpen.Point3d(124.22859958459195, -12.669523242833257, 0.0)
    viewCenter276 = NXOpen.Point3d(-124.22859958459249, 12.669523242832645, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint276, viewCenter276)
    
    scaleAboutPoint277 = NXOpen.Point3d(155.28574948074001, -15.836904053541497, 0.0)
    viewCenter277 = NXOpen.Point3d(-155.28574948074049, 15.836904053540875, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint277, viewCenter277)
    
    scaleAboutPoint278 = NXOpen.Point3d(-86.892747904385644, -40.11782110908144, 0.0)
    viewCenter278 = NXOpen.Point3d(86.892747904385132, 40.117821109080815, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint278, viewCenter278)
    
    scaleAboutPoint279 = NXOpen.Point3d(-109.92983731855232, -49.709308906994934, 0.0)
    viewCenter279 = NXOpen.Point3d(109.92983731855188, 49.709308906994337, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint279, viewCenter279)
    
    scaleAboutPoint280 = NXOpen.Point3d(110.03932918839109, -29.83653453118103, 0.0)
    viewCenter280 = NXOpen.Point3d(-110.03932918839151, 29.836534531180376, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint280, viewCenter280)
    
    scaleAboutPoint281 = NXOpen.Point3d(119.56512186440111, -17.737682913949971, 0.0)
    viewCenter281 = NXOpen.Point3d(-119.56512186440145, 17.737682913949339, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint281, viewCenter281)
    
    scaleAboutPoint282 = NXOpen.Point3d(96.352845458491629, -13.839772347674632, 0.0)
    viewCenter282 = NXOpen.Point3d(-96.352845458491998, 13.839772347673946, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint282, viewCenter282)
    
    scaleAboutPoint283 = NXOpen.Point3d(77.082276366793323, -11.071817878139781, 0.0)
    viewCenter283 = NXOpen.Point3d(-77.082276366793636, 11.071817878139086, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint283, viewCenter283)
    
    scaleAboutPoint284 = NXOpen.Point3d(-43.726673138981191, -11.324087146249248, 0.0)
    viewCenter284 = NXOpen.Point3d(43.726673138980864, 11.324087146248598, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint284, viewCenter284)
    
    scaleAboutPoint285 = NXOpen.Point3d(-36.23707886799675, -9.2386611965440331, 0.0)
    viewCenter285 = NXOpen.Point3d(36.237078867996416, 9.2386611965433456, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint285, viewCenter285)
    
    scaleAboutPoint286 = NXOpen.Point3d(-30.424794930753738, -7.8214685081421917, 0.0)
    viewCenter286 = NXOpen.Point3d(30.424794930753421, 7.8214685081414821, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint286, viewCenter286)
    
    scaleAboutPoint287 = NXOpen.Point3d(-25.373130866779572, -6.4867959003308382, 0.0)
    viewCenter287 = NXOpen.Point3d(25.37313086677926, 6.4867959003301241, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint287, viewCenter287)
    
    face14 = component4.FindObject("PROTO#.Features|EXTRUDE(14)|FACE 160 1 {(7,64.04,-4.5) EXTRUDE(2)}")
    line18 = workPart.Lines.CreateFaceAxis(face14, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    scaleAboutPoint288 = NXOpen.Point3d(-23.053957819227783, -5.7405273454255443, 0.0)
    viewCenter288 = NXOpen.Point3d(23.05395781922747, 5.7405273454248551, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint288, viewCenter288)
    
    scaleAboutPoint289 = NXOpen.Point3d(-18.516645005403689, -4.6659006263619425, 0.0)
    viewCenter289 = NXOpen.Point3d(18.516645005403401, 4.6659006263612595, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint289, viewCenter289)
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint7 = componentPositioner7.CreateConstraint(True)
    
    componentConstraint7 = constraint7
    componentConstraint7.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    edge12 = component6.FindObject("PROTO#.Features|EXTRUDE(10)|EDGE * 140 EXTRUDE(8) 160 {(4.3,45.7009618943266,2.2500000000019)(4.3,47,4.4999999999963)(4.3,48.2990381056734,2.2500000000019) EXTRUDE(2)}")
    constraintReference13 = componentConstraint7.CreateConstraintReference(component6, edge12, False, False, False)
    
    helpPoint13 = NXOpen.Point3d(139.5736159396815, 262.13384720627778, 77.683139958446631)
    constraintReference13.HelpPoint = helpPoint13
    
    edge13 = component4.FindObject("PROTO#.Features|EXTRUDE(14)|EDGE * 160 EXTRUDE(12) 290 {(8.2990381056767,63.04,-5.25)(7,63.04,-7.5)(5.7009618943233,63.04,-5.25) EXTRUDE(2)}")
    constraintReference14 = componentConstraint7.CreateConstraintReference(component4, edge13, False, False, False)
    
    helpPoint14 = NXOpen.Point3d(18.589881500408669, 95.485762665920674, 83.699732833088078)
    constraintReference14.HelpPoint = helpPoint14
    
    constraintReference14.SetFixHint(True)
    
    objects22 = [NXOpen.TaggedObject.Null] * 1 
    objects22[0] = line18
    nErrs39 = theSession.UpdateManager.AddObjectsToDeleteList(objects22)
    
    componentNetwork7.Solve()
    
    line19 = workPart.Lines.CreateFaceAxis(face13, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    line20 = workPart.Lines.CreateFaceAxis(face14, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Reverse Last Constraint")
    
    componentConstraint7.FlipAlignment()
    
    objects23 = [NXOpen.TaggedObject.Null] * 1 
    objects23[0] = line20
    nErrs40 = theSession.UpdateManager.AddObjectsToDeleteList(objects23)
    
    objects24 = [NXOpen.TaggedObject.Null] * 1 
    objects24[0] = line19
    nErrs41 = theSession.UpdateManager.AddObjectsToDeleteList(objects24)
    
    componentNetwork7.Solve()
    
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    theSession.DeleteUndoMark(markId49, None)
    
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs42 = theSession.UpdateManager.DoUpdate(markId46)
    
    componentNetwork7.Solve()
    
    componentPositioner7.ClearNetwork()
    
    nErrs43 = theSession.UpdateManager.AddToDeleteList(componentNetwork7)
    
    componentPositioner7.DeleteNonPersistentConstraints()
    
    nErrs44 = theSession.UpdateManager.DoUpdate(markId46)
    
    theSession.DeleteUndoMark(markId50, None)
    
    theSession.SetUndoMarkName(markId45, "Assembly Constraints")
    
    componentPositioner7.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner7.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId46, None)
    
    theSession.DeleteUndoMark(markId48, None)
    
    theSession.DeleteUndoMark(markId47, None)
    
    theSession.DeleteUndoMark(markId44, None)
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    rotMatrix5 = NXOpen.Matrix3x3()
    
    rotMatrix5.Xx = 0.46380463338339195
    rotMatrix5.Xy = 0.88560123326344076
    rotMatrix5.Xz = -0.024407328702034447
    rotMatrix5.Yx = 0.075856383346071657
    rotMatrix5.Yy = -0.0122485976024021
    rotMatrix5.Yz = 0.99704352009449781
    rotMatrix5.Zx = 0.88268401546518904
    rotMatrix5.Zy = -0.4642848559871901
    rotMatrix5.Zz = -0.072859462962628296
    translation5 = NXOpen.Point3d(-98.552442874440104, -88.62538776339143, 21.685500786485179)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix5, translation5, 4.5010178666642258)
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    scaleAboutPoint290 = NXOpen.Point3d(-12.226864003568204, -10.669114503113809, 0.0)
    viewCenter290 = NXOpen.Point3d(12.226864003567902, 10.669114503113127, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint290, viewCenter290)
    
    scaleAboutPoint291 = NXOpen.Point3d(-9.5933856027996995, -9.1936612026832378, 0.0)
    viewCenter291 = NXOpen.Point3d(9.5933856027994029, 9.1936612026825575, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint291, viewCenter291)
    
    scaleAboutPoint292 = NXOpen.Point3d(-11.991732003499582, -11.49207650335396, 0.0)
    viewCenter292 = NXOpen.Point3d(11.991732003499282, 11.49207650335328, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint292, viewCenter292)
    
    scaleAboutPoint293 = NXOpen.Point3d(-14.989665004374439, -14.365095629192362, 0.0)
    viewCenter293 = NXOpen.Point3d(14.989665004374132, 14.36509562919168, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint293, viewCenter293)
    
    scaleAboutPoint294 = NXOpen.Point3d(-18.737081255468002, -17.956369536490367, 0.0)
    viewCenter294 = NXOpen.Point3d(18.737081255467704, 17.956369536489685, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint294, viewCenter294)
    
    scaleAboutPoint295 = NXOpen.Point3d(-20.321466802805354, -30.711821298025171, 0.0)
    viewCenter295 = NXOpen.Point3d(20.321466802805059, 30.711821298024486, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint295, viewCenter295)
    
    scaleAboutPoint296 = NXOpen.Point3d(-25.401833503506662, -38.533289806166998, 0.0)
    viewCenter296 = NXOpen.Point3d(25.401833503506371, 38.533289806166323, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint296, viewCenter296)
    
    scaleAboutPoint297 = NXOpen.Point3d(-31.752291879383296, -48.16661225770865, 0.0)
    viewCenter297 = NXOpen.Point3d(31.752291879382991, 48.166612257707975, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint297, viewCenter297)
    
    scaleAboutPoint298 = NXOpen.Point3d(-37.896450053783703, -79.94132807203485, 0.0)
    viewCenter298 = NXOpen.Point3d(37.896450053783397, 79.941328072034153, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint298, viewCenter298)
    
    scaleAboutPoint299 = NXOpen.Point3d(-30.675943002116082, -66.285151691706901, 0.0)
    viewCenter299 = NXOpen.Point3d(30.675943002115776, 66.285151691706218, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint299, viewCenter299)
    
    scaleAboutPoint300 = NXOpen.Point3d(-25.114807136235388, -54.606766373357523, 0.0)
    viewCenter300 = NXOpen.Point3d(25.114807136235083, 54.606766373356834, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint300, viewCenter300)
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner8 = workPart.ComponentAssembly.Positioner
    
    componentPositioner8.ClearNetwork()
    
    componentPositioner8.PrimaryArrangement = arrangement1
    
    componentPositioner8.BeginAssemblyConstraints()
    
    allowInterpartPositioning7 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression49 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression50 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression51 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit1)
    
    expression52 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit2)
    
    expression53 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression54 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression55 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression56 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    network8 = componentPositioner8.EstablishNetwork()
    
    componentNetwork8 = network8
    componentNetwork8.MoveObjectsState = True
    
    componentNetwork8.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork8.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId52, "Assembly Constraints Dialog")
    
    componentNetwork8.MoveObjectsState = True
    
    componentNetwork8.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    scaleAboutPoint301 = NXOpen.Point3d(-35.246837900910869, -34.270948252188759, 0.0)
    viewCenter301 = NXOpen.Point3d(35.246837900910556, 34.270948252188091, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint301, viewCenter301)
    
    scaleAboutPoint302 = NXOpen.Point3d(-28.197470320728716, -27.416758601751081, 0.0)
    viewCenter302 = NXOpen.Point3d(28.197470320728417, 27.416758601750416, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint302, viewCenter302)
    
    scaleAboutPoint303 = NXOpen.Point3d(-22.557976256583007, -21.933406881400927, 0.0)
    viewCenter303 = NXOpen.Point3d(22.557976256582695, 21.933406881400238, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint303, viewCenter303)
    
    rotMatrix6 = NXOpen.Matrix3x3()
    
    rotMatrix6.Xx = 0.57710507638577402
    rotMatrix6.Xy = 0.8160269363111341
    rotMatrix6.Xz = -0.032400154697674731
    rotMatrix6.Yx = 0.027789868844627409
    rotMatrix6.Yy = 0.020028095660338197
    rotMatrix6.Yz = 0.99941312707699503
    rotMatrix6.Zx = 0.8161969455954653
    rotMatrix6.Zy = -0.57766678509230796
    rotMatrix6.Zz = -0.011118965857848525
    translation6 = NXOpen.Point3d(-93.0546922948147, -72.516890378981088, 31.523430111316234)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix6, translation6, 4.5010178666642293)
    
    face15 = component6.FindObject("PROTO#.Features|EXTRUDE(6)|FACE 140 {(0.5,3,1.5000000000248) EXTRUDE(2)}")
    line21 = workPart.Lines.CreateFaceAxis(face15, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    objects25 = [NXOpen.TaggedObject.Null] * 1 
    objects25[0] = line21
    nErrs45 = theSession.UpdateManager.AddObjectsToDeleteList(objects25)
    
    scaleAboutPoint304 = NXOpen.Point3d(-14.872099004340127, -17.194027505017885, 0.0)
    viewCenter304 = NXOpen.Point3d(14.872099004339805, 17.194027505017207, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint304, viewCenter304)
    
    rotMatrix7 = NXOpen.Matrix3x3()
    
    rotMatrix7.Xx = 0.71371812219012054
    rotMatrix7.Xy = 0.69972057667684462
    rotMatrix7.Xz = -0.03158411994073506
    rotMatrix7.Yx = -0.006263882093383139
    rotMatrix7.Yy = 0.051466669448698085
    rotMatrix7.Yz = 0.99865506843803564
    rotMatrix7.Zx = 0.70040502984953401
    rotMatrix7.Zy = -0.71256038095790875
    rotMatrix7.Zz = 0.041115661864922284
    translation7 = NXOpen.Point3d(-87.501473611361817, -69.901973412698169, 46.615795013485645)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix7, translation7, 5.6262723333302862)
    
    scaleAboutPoint305 = NXOpen.Point3d(-20.080272805859973, -12.955773203781087, 0.0)
    viewCenter305 = NXOpen.Point3d(20.080272805859661, 12.955773203780398, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint305, viewCenter305)
    
    scaleAboutPoint306 = NXOpen.Point3d(-16.064218244688011, -10.364618563024944, 0.0)
    viewCenter306 = NXOpen.Point3d(16.064218244687698, 10.364618563024248, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint306, viewCenter306)
    
    scaleAboutPoint307 = NXOpen.Point3d(-20.080272805859966, -12.955773203781089, 0.0)
    viewCenter307 = NXOpen.Point3d(20.080272805859664, 12.955773203780407, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint307, viewCenter307)
    
    scaleAboutPoint308 = NXOpen.Point3d(-25.100341007324921, -16.194716504726273, 0.0)
    viewCenter308 = NXOpen.Point3d(25.100341007324616, 16.194716504725591, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint308, viewCenter308)
    
    componentPositioner8.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner8.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId53, None)
    
    theSession.UndoToMark(markId52, None)
    
    theSession.DeleteUndoMark(markId52, None)
    
    theSession.DeleteUndoMark(markId51, None)
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    # ----------------------------------------------
    #   Menu: Assemblies->Component Position->Assembly Constraints...
    # ----------------------------------------------
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Constraints with Positioning Task")
    
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    componentPositioner9 = workPart.ComponentAssembly.Positioner
    
    componentPositioner9.ClearNetwork()
    
    componentPositioner9.PrimaryArrangement = arrangement1
    
    componentPositioner9.BeginAssemblyConstraints()
    
    allowInterpartPositioning8 = theSession.Preferences.Assemblies.InterpartPositioning
    
    expression57 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", NXOpen.Unit.Null)
    
    expression58 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression59 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit1)
    
    expression60 = workPart.Expressions.CreateSystemExpressionWithUnits("0.0", unit2)
    
    expression61 = workPart.Expressions.CreateSystemExpressionWithUnits("1", NXOpen.Unit.Null)
    
    expression62 = workPart.Expressions.CreateSystemExpressionWithUnits("1.0", unit1)
    
    expression63 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression64 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit2)
    
    network9 = componentPositioner9.EstablishNetwork()
    
    componentNetwork9 = network9
    componentNetwork9.MoveObjectsState = True
    
    componentNetwork9.DisplayComponent = NXOpen.Assemblies.Component.Null
    
    componentNetwork9.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    theSession.SetUndoMarkName(markId55, "Assembly Constraints Dialog")
    
    componentNetwork9.MoveObjectsState = True
    
    componentNetwork9.NetworkArrangementsMode = NXOpen.Positioning.ComponentNetwork.ArrangementsMode.Existing
    
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints Update")
    
    line22 = workPart.Lines.CreateFaceAxis(face15, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    objects26 = [NXOpen.TaggedObject.Null] * 1 
    objects26[0] = line22
    nErrs46 = theSession.UpdateManager.AddObjectsToDeleteList(objects26)
    
    rotMatrix8 = NXOpen.Matrix3x3()
    
    rotMatrix8.Xx = 0.5675404477227155
    rotMatrix8.Xy = 0.82244852030086324
    rotMatrix8.Xz = -0.038422280692568395
    rotMatrix8.Yx = -0.016030636185496397
    rotMatrix8.Yy = 0.057695243265533103
    rotMatrix8.Yz = 0.99820552874045843
    rotMatrix8.Zx = 0.82318944290010554
    rotMatrix8.Zy = -0.56590607909744961
    rotMatrix8.Zz = 0.04592875720463465
    translation8 = NXOpen.Point3d(-101.02827702614447, -77.16512179196215, 26.500801623084875)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix8, translation8, 3.6008142933313754)
    
    face16 = component3.FindObject("PROTO#.Features|EXTRUDE(4)|FACE 160 {(4.5,12,1.4) EXTRUDE(2)}")
    line23 = workPart.Lines.CreateFaceAxis(face16, NXOpen.SmartObject.UpdateOption.AfterModeling)
    
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Create Constraint")
    
    constraint8 = componentPositioner9.CreateConstraint(True)
    
    componentConstraint8 = constraint8
    componentConstraint8.ConstraintType = NXOpen.Positioning.Constraint.Type.Concentric
    
    edge14 = component6.FindObject("PROTO#.Features|EXTRUDE(4)|EDGE * 140 EXTRUDE(6) 140 {(1,1.7009618943448,3.7499999999876)(1,3,1.5000000000248)(1,4.2990381056552,3.7499999999876) EXTRUDE(2)}")
    constraintReference15 = componentConstraint8.CreateConstraintReference(component6, edge14, False, False, False)
    
    helpPoint15 = NXOpen.Point3d(-18.036477530383614, 92.185759532914261, 57.954844742055805)
    constraintReference15.HelpPoint = helpPoint15
    
    edge15 = component3.FindObject("PROTO#.Features|EXTRUDE(4)|EDGE * 160 EXTRUDE(2) 130 {(2.25,13.2990381056767,2.8)(4.5,12,2.8)(2.25,10.7009618943233,2.8) EXTRUDE(2)}")
    constraintReference16 = componentConstraint8.CreateConstraintReference(component3, edge15, False, False, False)
    
    helpPoint16 = NXOpen.Point3d(10.952499172206414, 91.085759585254621, 49.476079423973708)
    constraintReference16.HelpPoint = helpPoint16
    
    constraintReference16.SetFixHint(True)
    
    objects27 = [NXOpen.TaggedObject.Null] * 1 
    objects27[0] = line23
    nErrs47 = theSession.UpdateManager.AddObjectsToDeleteList(objects27)
    
    componentNetwork9.Solve()
    
    scaleAboutPoint309 = NXOpen.Point3d(-21.455795006261379, -22.741673131636801, 0.0)
    viewCenter309 = NXOpen.Point3d(21.455795006261052, 22.741673131636119, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint309, viewCenter309)
    
    scaleAboutPoint310 = NXOpen.Point3d(-25.809410945031857, -29.529272664867538, 0.0)
    viewCenter310 = NXOpen.Point3d(25.809410945031512, 29.529272664866866, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint310, viewCenter310)
    
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    theSession.DeleteUndoMark(markId58, None)
    
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Assembly Constraints")
    
    nErrs48 = theSession.UpdateManager.DoUpdate(markId56)
    
    componentNetwork9.Solve()
    
    componentPositioner9.ClearNetwork()
    
    nErrs49 = theSession.UpdateManager.AddToDeleteList(componentNetwork9)
    
    componentPositioner9.DeleteNonPersistentConstraints()
    
    nErrs50 = theSession.UpdateManager.DoUpdate(markId56)
    
    theSession.DeleteUndoMark(markId59, None)
    
    theSession.SetUndoMarkName(markId55, "Assembly Constraints")
    
    componentPositioner9.PrimaryArrangement = NXOpen.Assemblies.Arrangement.Null
    
    componentPositioner9.EndAssemblyConstraints()
    
    theSession.DeleteUndoMark(markId56, None)
    
    theSession.DeleteUndoMark(markId57, None)
    
    theSession.DeleteUndoMark(markId54, None)
    
    theSession.CleanUpFacetedFacesAndEdges()
    
    scaleAboutPoint311 = NXOpen.Point3d(-18.140066411543799, -21.067735357710795, 0.0)
    viewCenter311 = NXOpen.Point3d(18.140066411543447, 21.067735357710127, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint311, viewCenter311)
    
    scaleAboutPoint312 = NXOpen.Point3d(-20.809411627166508, -26.47818238077404, 0.0)
    viewCenter312 = NXOpen.Point3d(20.809411627166138, 26.478182380773379, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint312, viewCenter312)
    
    scaleAboutPoint313 = NXOpen.Point3d(-24.93541565669085, -33.097727975967473, 0.0)
    viewCenter313 = NXOpen.Point3d(24.935415656690513, 33.097727975966819, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint313, viewCenter313)
    
    scaleAboutPoint314 = NXOpen.Point3d(-30.496551522571515, -41.372159969959263, 0.0)
    viewCenter314 = NXOpen.Point3d(30.496551522571192, 41.372159969958588, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint314, viewCenter314)
    
    scaleAboutPoint315 = NXOpen.Point3d(-5.3256845489786055, -98.805463342890079, 0.0)
    viewCenter315 = NXOpen.Point3d(5.3256845489782947, 98.805463342889411, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint315, viewCenter315)
    
    scaleAboutPoint316 = NXOpen.Point3d(-4.7090263380442208, -79.941328072034779, 0.0)
    viewCenter316 = NXOpen.Point3d(4.7090263380439534, 79.941328072034139, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint316, viewCenter316)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()